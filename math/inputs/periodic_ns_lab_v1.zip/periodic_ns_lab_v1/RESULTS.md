# Executed results — periodic NS phase lab v1

## Execution and interpretation

There are 24 completed simulations. N is collocation nodes per spatial
coordinate, not the maximum retained wave number. The mean-zero unforced
problem uses nu=1/28 and the initial family in `proof_notes.md`. Time and all
quantities are dimensionless. Integrations use floating point; the initial
phase identities and Taylor coefficients are separately verified in exact
rational algebra.

The test report is `results/test_report.txt`: 19 tests passed.
The production-run manifest is `results/execution_manifest.json`.

## Main comparison at the finest tested grid, 48³

| Initial state | Initial Z derivative | Z(2) | S(2) | E(2) |
|---|---:|---:|---:|---:|
| Phase 0 | 0.125 | 2.229748879 | 1.393234374 | 0.749862632 |
| Phase pi/3 | -6.93889390391e-17 | 2.254754179 | 1.563082857 | 0.756653652 |
| Phase pi / sign-reversed field | -0.375 | 2.027904627 | 1.423060928 | 0.785501926 |

The phase pi/3 run has zero initial Z derivative exactly (the displayed
floating-point residual is roundoff). Its Z(2) is
1.121440% greater than the phase-zero run.
No global phase optimization was performed or certified.

The sign-reversed run first decreases from Z=1.25 to a sampled minimum
Z=1.196297289 at t=0.30, then rises to Z=2.027904627 by t=2. The minimum is
sampled every 0.02 and is not a root-isolated exact turning point.

## Spatial refinement of the finite-horizon comparison

| Nodes per axis | Phase 0 Z(2) | Phase pi/3 Z(2) |
|---:|---:|---:|
| 24 | 2.229671494 | 2.254801837 |
| 32 | 2.229756500 | 2.254766338 |
| 48 | 2.229748879 | 2.254754179 |

The ordering persists at all three tested resolutions. This is convergence
evidence, not a rigorous bound on the unresolved Fourier tail.

For phase zero, comparing 32³ to 48³ at t=2 gives relative enstrophy difference
3.42e-6, BUT relative velocity-field L² difference 2.37e-3 (about 0.237%).
Thus excellent agreement of a single aggregate is not equally accurate
agreement of the field. Full values are in `results/convergence.csv`.

At 48³, the outer retained band contains about 0.0110% of Z and 0.334% of D
for phase zero at t=2. These are fractions of RESOLVED outer-band quantities,
not upper bounds on missing modes. Higher derivatives require stricter
resolution checks than energy or enstrophy alone.

## Time-step refinement

At fixed 24³ resolution through t=1, relative final-field differences from
our dt=0.0025 reference were:

| Step cap | Relative field L² difference |
|---:|---:|
| 0.02 | 2.359226e-08 |
| 0.01 | 1.459122e-09 |
| 0.005 | 8.554264e-11 |

This is consistent with fourth-order RK4 refinement for this fixed
finite-dimensional problem. It does not eliminate spatial discretization error.

## Constraint and balance checks

The maximum divergence L² residual over the three finest-grid main runs was
4.238e-17.

The maximum difference between physical and spectral stretching evaluations
was 6.67e-16 or smaller. Energy was nonincreasing at all sampled times in all
completed production cases. The initial direct ordered-triad convolution and
FFT nonlinearity agreed to 5.65e-17 or better.

These are consistency checks on the implementation, not standalone certificates
of approximation to the continuum equation. In particular, a nearly zero
semidiscrete residual is compatible with a non-negligible spatial error.

## Exact mathematical outputs

For u=A*(sin y, sin z, cos x-cos(x+y+phi)):

    S(0)=A³ cos(phi)/4,
    Z'(0)=A³ cos(phi)/4 - (7/2)nu A²,
    Z''(0)=(5/4)A⁴ - (5/2)nu A³ cos(phi) + 11nu²A².

For initially empty high shells |k|²>2:

    E_hi(t)=(7A⁴/48)t²+O(t³),
    Z_hi(t)=(9A⁴/16)t²+O(t³).

The high-shell leading coefficients hold for every phase and do not depend on
viscosity. They are exact local identities, not extrapolations from the plots.

## Remaining limits

No continuum tail certificate, cutoff-independent stretching bound, validated
interval arithmetic, infinite-time result, or singularity construction was
established. Gridpoint vorticity maxima are not certified continuous suprema.
A nine-point exploratory phase scan plus pi/3 tests does not establish the
best phase, much less an optimum among arbitrary divergence-free initial data.
This lab instead supplies explicit benchmark identities and reproducible
finite-time evidence to test candidate estimates/closures against.
