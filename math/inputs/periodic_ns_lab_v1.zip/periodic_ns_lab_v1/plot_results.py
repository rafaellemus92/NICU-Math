#!/usr/bin/env python3
"""Plot completed local CSV outputs. All plots use Matplotlib default colors."""
from pathlib import Path
import argparse
import csv
import numpy as np
import matplotlib.pyplot as plt


def load(path):
    with path.open() as f:
        return [{k:float(v) for k,v in row.items()} for row in csv.DictReader(f)]


def plot_results(root:Path,show:bool=False):
    plots=root/'plots';plots.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(figsize=(9.2,5.4))
    for label,name,style in [('plus_N48',r'$\phi=0$: maximal initial growth','-'),
                             ('phase_pi3_N48',r'$\phi=\pi/3$: zero initial growth','-.'),
                             ('minus_N48',r'$-v$ (equivalent to $\phi=\pi$)','--')]:
        rows=load(root/label/'diagnostics.csv')
        ax.plot([r['t'] for r in rows],[r['enstrophy'] for r in rows],style,lw=2,label=name)
    ax.set(xlabel='Time (dimensionless)',ylabel=r'Enstrophy $Z(t)$',
           title='Same initial Fourier spectrum; different evolution\n'
                 r'Unforced periodic Navier–Stokes, $\nu=1/28$, $48^3$ grid')
    ax.grid(True,alpha=0.25);ax.legend(loc='upper left',fontsize=10)
    fig.tight_layout()
    fig.savefig(plots/'enstrophy_comparison.png',dpi=180)
    fig.savefig(plots/'enstrophy_comparison.svg')
    if show:plt.show()
    plt.close(fig)
    phase=[]
    for p in sorted(root.glob('phase_[0-9][0-9]/summary.json')):
        import json
        phase.append(json.loads(p.read_text()))
    fig,ax=plt.subplots(figsize=(8.8,5.0))
    ax.plot([p['phase'] for p in phase],[p['final_Z'] for p in phase],'o-',label='Nine-point phase scan')
    import json
    extra=json.loads((root/'phase_pi3_N24/summary.json').read_text())
    ax.plot([extra['phase']],[extra['final_Z']],'x',ms=9,mew=2,label=r'Additional test: $\pi/3$')
    ax.set(xlabel=r'Initial relative phase $\phi$ (radians)',ylabel=r'Enstrophy $Z(2)$',
           title='Finite-horizon phase scan (24³ grid)\nNot a proof of the optimal phase')
    ax.set_xticks([0,np.pi/4,np.pi/2,3*np.pi/4,np.pi],[r'$0$',r'$\pi/4$',r'$\pi/2$',r'$3\pi/4$',r'$\pi$'])
    ax.grid(True,alpha=.25);ax.legend();fig.tight_layout()
    fig.savefig(plots/'phase_scan.png',dpi=180);plt.close(fig)
    with (root/'convergence.csv').open() as f:all_rows=list(csv.DictReader(f))
    rows=[r for r in all_rows if r['comparison']=='space' and r['case']=='plus']
    fig,ax=plt.subplots(figsize=(8.8,5.0))
    ax.semilogy([int(r['n']) for r in rows],[float(r['relative_field_L2']) for r in rows],'o-',label='Relative velocity-field L² difference')
    ax.semilogy([int(r['n']) for r in rows],[float(r['relative_Z_error']) for r in rows],'s-',label='Relative enstrophy difference')
    ax.set(xlabel='Collocation nodes per axis',ylabel='Difference relative to the 48³ run',
           title='Aggregate agreement is not the same as field accuracy\n'
                 'Phase 0 at t = 2; reference is numerical, not exact')
    ax.set_xticks([16,24,32]);ax.grid(True,alpha=.25);ax.legend();fig.tight_layout()
    fig.savefig(plots/'resolution_comparison.png',dpi=180);plt.close(fig)
    return plots


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--results',type=Path,default=Path('results'))
    ap.add_argument('--show',action='store_true')
    a=ap.parse_args(); print(f'Plots saved in {plot_results(a.results,a.show)}')

if __name__=='__main__':main()
