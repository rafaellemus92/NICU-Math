# Periodic Navier–Stokes phase lab — v1

A reproducible mathematical research prototype built from the earlier
`periodic_ns_phase_audit.zip`. This is **not** a global regularity or blowup
proof, not a certified PDE enclosure, and not a physiological simulator.

## What was actually executed

- 24 completed finite-time simulations; output is included in `results/`.
- 19 passing tests; report in `results/test_report.txt`.
- Exact rational verification of the original plus/minus initial fields.
- Exact phase-parametric Fourier calculations (valid for every phase, not a
  sampled numerical fit).
- Spatial comparisons at 16³, 24³, 32³ and 48³ nodes.
- A fixed-24³ time-step refinement test through t=1, with caps 0.02, 0.01,
  0.005 and 0.0025.
- A nine-phase exploratory scan, then extra checks at phase pi/3 on 24³,
  32³ and 48³ grids. Production time evolution runs to t=2.

All coordinates, velocities, time and viscosity here are dimensionless. The
viscosity is nu=1/28 unless a unit test explicitly uses something else. There is
no external force. No phase is reset or optimized while the flow evolves.

## Quick start

Python 3.11+ is required (the code was run on Python 3.13.5 with NumPy 2.3.5).

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python exact_initial_check.py
python exact_dynamics_check.py
python exact_phase_family.py
python ns_solver.py --n 24 --phase 0 --t-end 2 --dt 0.01 --out my_results/phase0
python ns_solver.py --n 24 --phase 1.0471975511965976 --t-end 2 --dt 0.01 --out my_results/phase60
python plot_results.py
```

The three `exact_*.py` checkers need only Python's standard library. The solver
needs NumPy; plots use Matplotlib; tests use pytest. This was written as a fresh
implementation, not copied from an external simulation repository.

### Full reproduction

```bash
python run_experiments.py --stage all --out reproduced_results
python plot_results.py --results reproduced_results
```

The entire suite took roughly four minutes of completed integration time in
the working environment, plus tests, exact algebra, postprocessing and aborted
attempts. Runtime depends on hardware. This is a serial CPU prototype, not a
production parallel DNS code.

Stages may be run separately:

```bash
python run_experiments.py --stage baseline --grids 16 24 32
python run_experiments.py --stage time
python run_experiments.py --stage phase
python run_experiments.py --stage refine
python run_experiments.py --stage summarize
```

For environments that interrupt long commands, `advance_checkpoint.py`
advances a single trajectory in bounded segments and checks its parameters
before resuming:

```bash
python advance_checkpoint.py --n 48 --sign 1 --until 0.5 --out chunked
python advance_checkpoint.py --n 48 --sign 1 --until 1.0 --out chunked
python advance_checkpoint.py --n 48 --sign 1 --until 1.5 --out chunked
python advance_checkpoint.py --n 48 --sign 1 --until 2.0 --out chunked
```

This is an autonomous equation: splitting into segments does not change the
problem. A test checks segmented versus uninterrupted evolution. Fresh chunked
runs should use a separate output directory. Only completed cases are included
in the aggregate run summary. Some long commands during development hit the
execution time limit; completed cases were preserved and interrupted cases
were subsequently completed via separate calls/checkpoints. No timed-out case
is reported as a completed simulation.

## Model and discretization

We solve the unforced 3D incompressible equations on [0,2*pi]³ with periodic
boundaries and zero mean:

    u_t + (u.grad)u = -grad p + nu Laplacian u,
    div u = 0.

The state is a complex128 Fourier array with three components. Normalization is
`u(x)=sum_k uhat(k) exp(i k.x)`, so spatial averages use Parseval without grid
volume factors. The Leray projection removes the pressure gradient. The
nonlinearity is evaluated in rotational form, `P(u cross curl(u))`.

At N³ collocation nodes the strict retained cutoff is

    max_j |k_j| <= K, K=floor((N-1)/3), hence 3K<N.

This is a **cube** of modes. At N=16,24,32,48 the respective K values are
5,7,10,15. Strict 2/3 truncation removes quadratic aliasing into retained modes;
it does not remove spatial truncation error. Time integration uses classical
RK4, with practical advective and viscous step caps. Those caps are safeguards,
not a rigorous stability theorem for arbitrary inputs.

For this cube, the finite-dimensional energy bound gives Z<=3K²E, not K²E.
The latter bound applies to a spherical |k|<=K cutoff. Every fixed Galerkin
system has bounded energy and cannot demonstrate continuum blowup by itself.

## The initial family

    u_phi = (sin y, sin z, cos x - cos(x+y+phi)).

All members have the same magnitude at every individual wave vector. Changing
phi changes phases only, not the initial energy spectrum or the polarizations.
The old -u example is translation-equivalent to phi=pi. That relationship is
checked after time evolution as well as at t=0.

`proof_notes.md` contains the exact family identities, Taylor coefficients and
limitations. `RESULTS.md` describes measured outcomes. The central numerical
finding is that phi=pi/3, with zero initial net enstrophy growth, exceeds phi=0
at t=2 in the tested resolutions, although phi=0 maximizes initial growth.
This is not a proof of the globally optimal phase or of the continuum ordering.

## Data dictionary

`diagnostics.csv` contains:

- `energy` = E = (1/2)<|u|²>.
- `enstrophy` = Z = (1/2)<|curl u|²>.
- `D` = <|grad curl u|²>.
- `stretching` = S = <omega_i (partial_j u_i) omega_j>.
- `dzdt` = S - nu D, computed from the semidiscrete equation.
- `dedt` = -2 nu Z.
- `stretch_to_viscous` = S/(nu D); this can be negative.
- `divergence_l2`, `imaginary_linf`: constraint/realness diagnostics.
- `nonlinear_energy_balance`: net nonlinear energy input, theoretically zero.
- `enstrophy_balance_disagreement`: difference between spectral and physical
  evaluations of S, NOT a continuum discretization-error bound.
- `vorticity_grid_max`: maximum only at the collocation nodes; NOT a rigorous
  continuous L-infinity norm and NOT a certified blowup/continuation diagnostic.
- `outer_band_enstrophy_fraction` and `outer_band_D_fraction`: fractions in
  retained modes with max_j |k_j|>=0.8K; these are NOT bounds on unrepresented
  modes beyond the cutoff.
- Positive/negative parts of the stretching density, sampled on the grid.

`shell_transfer.csv` uses exact integer |k|² shells (no rounded-radius bins).
Transfers are diagnostic; all retained interactions remain in the solver.
`energy_flux_out` is minus the cumulative nonlinear energy input to modes up
to that shell. `initial_triad_audit.json` independently checks an ordered
Fourier convolution against the FFT implementation on the same low-pass field.
A low-pass snapshot is not claimed to be a closed subsystem of the full flow.

`final_state.npz` stores normalized Fourier coefficients for further analysis.
`convergence.csv` compares final states after zero-padding smaller Fourier
arrays into the larger array. The high-resolution run is a reference, not a
certified exact solution. Small aggregate errors need not imply small field or
higher-derivative errors.

## Source distinction and references

The source Shared Air document explicitly describes its cells as phase
oscillators, not resolved fluid fields. This lab is a separate Navier–Stokes
model; it does not silently replace or validate Shared Air's equations.

The numerical formulation is established mathematics, not a claimed invention:

1. C. Fefferman, *Existence and smoothness of the Navier–Stokes equation*, Clay
   Mathematics Institute. https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf
2. M. Mortensen, *Massively parallel implementation in Python of a pseudo-spectral
   DNS code for turbulent flows* (2016), equations 1–10 and RK4 discussion.
   https://arxiv.org/abs/1607.00850
3. D. Ayala and B. Protas, *Extreme Vortex States and the Growth of Enstrophy in
   3D Incompressible Flows*. https://arxiv.org/abs/1605.05742

This package does not rely on any announced resolution of a Millennium problem
and makes no judgment about that separate proof. Its explicit finite-family
calculations are worked derivations; no literature-novelty claim is made.
