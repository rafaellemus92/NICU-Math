# Exact initial-time results and the remaining proof problem

## 1. Setting

Take the unforced incompressible Navier–Stokes equation on [0,2*pi]³ with
normalized spatial average <.>. Let omega=curl u,

    E=(1/2)<|u|²>, Z=(1/2)<|omega|²>,
    D=<|grad omega|²>, S=<omega_i (partial_j u_i) omega_j>.

For smooth local solutions,

    E'=-2 nu Z,          Z'=S-nu D.

These follow by integration by parts and incompressibility. All initial fields
below are finite trigonometric polynomials, so their time derivatives at zero
are well defined for the local smooth solution. The computations use the full
PDE at t=0, not a low-mode time-evolution closure.

## 2. All four phases reduce to one relational phase

Fix the four plane waves and their vector polarizations, and write

    u=(sin(y+a), sin(z+b), cos(x+c)-cos(x+y+d)).

A spatial translation removes a, b and c. The remaining phase is

    phi=d-a-c.

It is invariant under translation because (1,1,0)=(1,0,0)+(0,1,0). Thus it is
not an arbitrary coordinate origin. A representative of every such phase
configuration is

    u_phi=(sin y, sin z, cos x-cos(x+y+phi)).

Every member is divergence-free, zero-mean and smooth. Every member has the
same Fourier energy at each wave vector, with no overlapping modes as phi is
changed. For u=A*u_phi, A>0, direct spatial averaging gives

    E(0)=A², Z(0)=5A²/4, D(0)=7A²/2,
    S(0)=A³ cos(phi)/4.

Consequently,

    Z'(0)=A³ cos(phi)/4 - 7 nu A²/2.

Within this fixed-spectrum/polarization family, the exact largest and smallest
initial stretching values are +/-A³/4. Initial growth occurs precisely when

    cos(phi)>14 nu/A.

For A=1 and nu=1/28, the growth sector is cos(phi)>1/2, i.e. the open interval
(-pi/3,pi/3) modulo 2*pi. At phi=pi/3 or -pi/3 the initial derivative is zero.
Phi=0 maximizes initial growth. The old global-sign-reversed example is a
translate of phi=pi and has the same scalar diagnostics throughout evolution.

This proves non-closure from the energy spectrum alone at the initial instant.
It does not prevent bounds based on spectra or prove different long-time fates.

## 3. How the phase identities were checked exactly

`exact_phase_family.py` represents terms exp(i(k.x + m*phi)) with a four-index
integer key (kx,ky,kz,m) and rational complex coefficients. Derivatives,
Laplacians and Leray projection use ONLY the three physical wave numbers.
Spatial averaging retains (0,0,0,m), yielding an exact Fourier polynomial in
phi. No phase sampling or floating-point fit is used in the assertions.

The computed coefficients of S are 1/8 at m=1 and m=-1; this is cos(phi)/4.
The same program proves the following second-derivative formula for A=1 and
arbitrary viscosity by computing all three coefficients of a polynomial in nu:

    Z''(0) = 5/4 - (5/2)nu cos(phi) + 11 nu².

With amplitude restored,

    Z''(0) = (5/4)A⁴ - (5/2)nu A³ cos(phi) + 11 nu² A².

At nu=1/28 and A=1 this becomes

    Z''(0)=991/784 - (5/56)cos(phi).

Hence for the original plus and minus fields,

    Z_plus(t) = 5/4 + t/8 + (921/1568)t² + O(t³),
    Z_minus(t)= 5/4 - 3t/8 + (1061/1568)t² + O(t³).

The positive initial curvature is not a proof that an initially decreasing
solution must turn upward at a specified later time. That later behavior is
measured in the simulations, separately from this Taylor identity.

## 4. Exact creation of higher-frequency modes

Let P_hi retain |k|²>2, above every initially populated wave vector, and define

    E_hi(t)=(1/2) sum_(|k|²>2) |uhat(k,t)|²,
    Z_hi(t)=(1/2) sum_(|k|²>2) |k|² |uhat(k,t)|².

Since P_hi u(0)=0, local time expansion gives

    P_hi u(t)=t P_hi u_t(0)+O(t²),
    E_hi(t)=(t²/2)||P_hi u_t(0)||²+O(t³).

The viscosity term has no support in this initially empty region, so

    P_hi u_t(0) = A² P_hi B(u_phi,u_phi),
    B(v,w)=-P[(v.grad)w].

Exact rational phase-polynomial convolution gives, for every phi,

    E_hi(t)=(7 A⁴/48)t²+O(t³),
    Z_hi(t)=(9 A⁴/16)t²+O(t³).

These leading coefficients are independent of phase and viscosity. This is
not a claim that later high-frequency transfer is independent of phase. The
remainder depends on the actual solution, and subsequent interactions alter
both magnitudes and phases.

For the original plus/minus fields, including ALL initially empty modes (also
empty modes on already occupied |k|² shells) gives different coefficients:

    E_new(t)=(11/24)t²+O(t³),
    Z_new(t)=(19/16)t²+O(t³),       [A=1].

Do not confuse “new wave vectors” with “higher shells.”

The important consequence is precise: a negative TOTAL initial enstrophy
slope does not imply absence of new high-frequency mode generation. Losses in
already populated modes can outweigh the newly created high-mode contribution.

## 5. Reproducible numerical observation, not a theorem of the full PDE

At nu=1/28, the 48³ calculations through t=2 give approximately

    phi=0:    Z(2)=2.229748879,
    phi=pi/3: Z(2)=2.254754179,
    phi=pi:   Z(2)=2.027904627.

Thus an initial phase with ZERO initial enstrophy derivative exceeds the
maximal-initial-growth phase at this finite horizon in the resolved experiments.
The pi/3 versus zero comparison is also present at 24³ and 32³.

The computations do not certify the PDE approximation or prove the global
optimal phase. They suggest studying finite-horizon phase optimization, rather
than assuming that maximizing instantaneous stretching also maximizes the
later enstrophy. This distinction is aligned with established work on enstrophy
growth/optimization; no claim of first discovery is made.

## 6. Why the main proof problem remains a cutoff-uniform estimate

For a cube of retained modes max_j|k_j|<=K, the exact Galerkin energy identity
implies

    Z_K(t) <= 3 K² E_K(0).

This bounds each fixed finite-dimensional system but worsens as K grows. Its
finite-dimensional dynamics cannot by themselves establish continuum blowup,
and smooth finite-time integrations cannot establish regularity for every
smooth initial datum and all time.

An example of a sufficient regularity target from our earlier discussion is

    S <= (1-delta)nu D + a(t)Z,   delta>0,

with a finite, independently controlled integral of a(t) on every finite
interval, uniform as K increases. Then Gronwall bounds Z. We have NOT proved
such an estimate. Defining a(t) from the measured stretching and assuming its
integrability would just restate the desired conclusion.

A useful next research task is to derive/evaluate which phase-polarization
combinations in interacting triads control this inequality, with a tail bound
that does not deteriorate as resolution increases. The present exact family
and conservation tests are benchmarks against which proposed closures can be
falsified, not an assertion that such a global estimate has already been found.
