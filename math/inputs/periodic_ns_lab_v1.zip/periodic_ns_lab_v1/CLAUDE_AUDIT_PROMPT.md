# Independent audit of the periodic NS phase lab

Audit the attached ZIP as an adversarial mathematical and numerical reviewer.
Use the actual code and saved outputs. Do not infer correctness from small
residuals, attractive plots, or the fact that ChatGPT wrote the package.

This is a separate unforced periodic Navier–Stokes model, not the Shared Air
phase-oscillator model. Do not introduce forcing, change the initial spectra,
or replace the PDE by a fitted oscillator model without labeling a new problem.

First run the three exact checkers and the tests. Independently derive
S(0)=cos(phi)/4, Z''(0)=5/4-(5/2)nu cos(phi)+11nu², and the high-shell energy
coefficient 7/48 for u=(sin y,sin z,cos x-cos(x+y+phi)). “High shell” means
|k|²>2, not just initially empty modes. Verify normalization and all factors 1/2.

Then audit Leray projection, Hermitian symmetry, mean conservation, strict
3K<N dealiasing, the cubic spectral/physical balance, and the componentwise
rather than spherical cutoff. Reproduce a Beltrami exact-decay case and compare
the rotational and advective nonlinearities. Check that segmented runs match
uninterrupted runs at the same time steps.

Independently compare phase 0 and phase pi/3 at t=2 on progressively larger
grids and smaller time steps. The claimed pi/3 advantage is about 1.12% at 48³.
Do not call it a continuum theorem without a certified error bound. The claim
is not that pi/3 is the optimal phase, and no initial phase remains imposed
after t=0. Track the initially shrinking sign-reversed case turning upward.

Attempt one further rigorous result: derive bounds on the interval over which
the phase-dependent stretching can reverse, or a controlled remainder for a
finite-time Taylor expansion of this fixed family. Keep that result separate
from any statement about all smooth data or a cutoff-uniform continuum bound.

Report PASS / FAIL / UNPROVEN separately for algebra, implementation,
finite-resolution observations, continuum claims and novelty. Provide exact
counterexamples for errors, numerical parameters for all new runs, and a
list of work that timed out or was not executed. Never call a fixed Galerkin
simulation a finite-time blowup proof: its energy bounds the finite ODE.
