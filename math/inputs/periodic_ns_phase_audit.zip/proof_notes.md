# Periodic Navier–Stokes: a phase-sensitive proof exercise

## Scope

This note proves an elementary statement about instantaneous evolution under the
actual unforced three-dimensional incompressible Navier–Stokes equations. It does
not prove global regularity or finite-time singularity formation. No claim of
literature novelty is made.

The construction was checked in two independent ways: exact trigonometric
integration in SymPy and the attached standard-library sparse-Fourier checker.
The latter is self-contained and uses rational complex coefficients, with no
floating-point calculations, sampling, or time stepping.

## 1. Setting and notation

Use the torus with period 2*pi in each coordinate, and normalized spatial average

    <g> = (2*pi)^(-3) integral_[0,2*pi]^3 g(x) dx.

Consider smooth local solutions of

    partial_t u + (u dot grad)u = -grad p + nu Delta u,
    div u = 0,  nu > 0.

The force is identically zero. The period-2*pi torus is equivalent to the unit
periodic torus in the Clay formulation: if u is a solution here, then

    U(x,t) = 2*pi*u(2*pi*x, (2*pi)^2*t)
    P(x,t) = (2*pi)^2*p(2*pi*x, (2*pi)^2*t)

is unit-periodic and solves the equations with the same viscosity.

Write omega = curl u. Define

    E = (1/2)<|u|^2>,
    Z = (1/2)<|omega|^2>,
    D = <|grad omega|^2>,
    S = <omega dot ((omega dot grad)u)>.

The exact balances for smooth solutions are

    dE/dt = -nu<|grad u|^2>,
    dZ/dt = S - nu D.

To derive the second identity, curl the equation, take its scalar product with
omega, and integrate. The transport term integrates to zero by incompressibility
and periodicity. Integration by parts turns the Laplacian term into -nu D.
The remaining cubic term is S, the integrated vortex-stretching term.

## 2. An explicit three-dimensional field

Let

    v(x,y,z) = (sin y, sin z, cos x - cos(x+y)).

Every component is independent of its own coordinate, so div v = 0. All
components have mean zero. The field depends on all three spatial coordinates.
Its vorticity is

    omega = (sin(x+y)-cos z, sin x-sin(x+y), -cos y).

Orthogonality of trigonometric functions gives

    <|v|^2> = 2,
    <|omega|^2> = 5/2,
    <|grad omega|^2> = 7/2,
    <|grad v|^2> = 5/2.

For the stretching calculation, abbreviate

    a = sin(x+y), b = sin x, c = cos y, d = cos z.

The velocity Jacobian is

    [  0    c   0 ]
    [  0    0   d ]
    [ -b+a  a   0 ].

Therefore the stretching density simplifies to

    omega^T (grad v) omega = c*(b-a)*(a-3*d).

The terms containing d have zero z-average. The remaining mean is 1/4:
<sin^2(x+y) cos y> = 0, while
<sin(x+y) sin x cos y> = 1/4. Hence S[v] = 1/4.

## 3. The two initial conditions

For any amplitude A>0, choose

    u_+(0) = A v,
    u_-(0) = -A v.

Both are smooth, divergence-free periodic initial data. Their quantities are

    E_+ = E_- = A^2,
    Z_+ = Z_- = 5 A^2/4,
    D_+ = D_- = 7 A^2/2,
    S_+ = A^3/4,  S_- = -A^3/4.

The quadratic quantities are invariant under a global sign change; the cubic
stretching term reverses sign. Consequently

    dZ_+/dt at t=0 = A^3/4 - 7 nu A^2/2,
    dZ_-/dt at t=0 = -A^3/4 - 7 nu A^2/2.

For A>14 nu, the first derivative is positive and the second is negative.
In the particular normalization A=1, nu=1/28:

    E = 1, Z = 5/4, D = 7/2,
    dZ_+/dt = 1/8,
    dZ_-/dt = -3/8.

At every individual Fourier wave vector k the two velocities have identical
coefficient magnitudes, because u_hat_- (k) = -u_hat_+ (k). Thus this is stronger
than equality merely of total energy or of shell-averaged spectra.

### Consequence (exact non-closure)

There is no universal function Phi such that

    dZ/dt = Phi(E,Z,D,nu)

for every smooth periodic Navier–Stokes solution at every time. The displayed
initial data have the same arguments and different derivatives. The same
obstruction holds for an exact evolution rule based solely on Fourier energies
|u_hat(k)|^2, even if all wave vectors are supplied.

This does not preclude useful upper or lower bounds expressed with these
quantities. It also does not prove that one solution later blows up and the
other remains smooth. It concerns their exact instantaneous derivatives.

## 4. Why Fourier coupling retains information spectra discard

On the period-2*pi torus, eliminating pressure with the Leray projector gives,
for k != 0,

    d/dt u_hat(k) + nu |k|^2 u_hat(k)
      = -i P_k sum_(p+q=k) (u_hat(p) dot q) u_hat(q),
    P_k = I - k tensor k / |k|^2.

The quadratic convolution couples modes. Their energy transfer involves cubic
products with u_hat(k)*. Such products depend on relative phases and vector
polarizations, not just magnitudes. In v, the wave vectors (1,0,0), (0,1,0), and
(1,1,0) form a resonant interaction. The additional (0,0,1) mode adds genuine
z-dependence without changing the integrated stretching of that interaction.

## 5. The finite-cutoff obstruction

For an exact unforced Fourier–Galerkin system supported on |k|<=K, with
orthogonal projection of the nonlinearity, the energy identity still holds.
Thus E_K(t)<=E_K(0). Since there are finitely many coefficients and each is
bounded by energy, the polynomial ODE cannot blow up in finite time. Moreover

    Z_K(t) <= K^2 E_K(0).

The estimate deteriorates as K grows. A computation on a fixed grid is therefore
not by itself a continuum singularity proof. Conversely, smooth evolution on a
large fixed grid is not a global regularity proof. Any computer-assisted
argument requires additional estimates controlling the unresolved modes and
the passage to the continuum.

## 6. A precise sufficient estimate to investigate for the unforced problem

Suppose one can establish, for every solution under consideration,

    S(t) <= (1-delta) nu D(t) + a(t) Z(t),
    delta>0, a(t)>=0,

and an a priori bound on integral_0^T a(t) dt for every finite T, depending only
on controlled data and not on a spectral cutoff or an assumed smoothness norm.
Then

    dZ/dt <= a(t) Z(t),
    Z(t) <= Z(0) exp(integral_0^t a(s) ds).

This supplies an H1 bound and, with standard strong-solution continuation,
would provide a regularity route. The needed uniform estimate is NOT proved
here. Setting a(t)=S_+(t)/Z(t) without independently bounding its integral does
not advance the argument; that would merely restate the unknown.

A complementary breakdown attempt would have to show concentration or
superlinear growth sustained by the full evolution, not just a positive
initial derivative. Adding an external force changes the statement being
studied and must always be reported explicitly.

## 7. B and D: separate quantifiers and forcing

In Fefferman's official formulation, B asks for global smooth periodic solutions
for every admissible smooth divergence-free datum, with f=0. D asks for a
periodic datum and an admissible smooth force for which there is no global
smooth periodic solution. D permits f=0, but does not require it. A forced
counterexample is not itself an unforced counterexample to B.

Current-source context checked on 16 October 2026: OpenAI's September 2026
manuscript claims alternatives C and D, with a smooth compactly supported force.
Clay's 11 September announcement acknowledges the apparent resolution and says
its evaluation process will proceed. This note does not independently certify
that 166-page construction.

## 8. Conditional periodization lemma for D

Assume a whole-space solution u,p,f has common spatial support contained in a
compact subset of the interior of a unit cube, uniformly in time before its
putative singular time. Assume the force is smooth through that time and has
the required temporal decay. Define periodic fields by summing their integer
translates. Different translates have disjoint supports. Therefore all linear
derivatives commute with summation, and the nonlinear term satisfies

    (U dot grad)U = sum_k (u(x+k) dot grad)u(x+k).

There are no cross terms between different translates. Divergence, smoothness
before the singular time, and any existing localized blowup transfer to the
torus. Suitable Navier–Stokes scaling first fits a common compact support into
a fundamental cube, without changing viscosity. The recent manuscript uses
this transfer in Section 10.5; this is not a new construction of its core.
Simply cutting off an arbitrary field would not suffice: it may violate
incompressibility, pressure relations, or smoothness of the induced force.

## References and attribution

* Charles L. Fefferman, official Clay problem statement:
  https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf
* OpenAI, announcement, 8 September 2026:
  https://openai.com/index/navier-stokes-solution/
* OpenAI, Finite Time Blowup for Navier–Stokes, especially Theorem 1.1,
  Section 2, and Section 10.5:
  https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf
* Clay Mathematics Institute, 11 September 2026 announcement:
  https://www.claymath.org/news/navier-stokes-announcement/
* Yongji Wang et al., Discovery of Unstable Singularities (2025):
  https://arxiv.org/abs/2509.14185
* Diego Ayala and Bartosz Protas, Extreme Vortex States and the Growth of
  Enstrophy in 3D Incompressible Flows (2016):
  https://arxiv.org/abs/1605.05742

The explicit field and computations in Sections 2–3 are worked out in this
note; the phase-sensitive nature of nonlinear spectral transfer is established
mathematics, not claimed here as a new general discovery.
