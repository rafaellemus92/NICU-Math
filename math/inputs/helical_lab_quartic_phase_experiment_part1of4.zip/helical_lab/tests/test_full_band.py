"""Full-resolved ordered helical stretching and shell-splitting tests."""
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from helical import helical_basis, stretching_physical, TriadTable
from phase2.full_band import COMPONENTS, FullBandDiagnostics, analyze_full_band
from solver import NS


class FullBandTests(unittest.TestCase):
    def random_field(self, N=16, seed=129):
        ns = NS(N)
        uh = ns.g.proj(ns.g.fwd(np.random.default_rng(seed).normal(size=(3, N, N, N))))
        return ns, uh

    def test_reconstruct_and_full_physical_stretching(self):
        for N in (13, 16, 24):
            ns, uh = self.random_field(N)
            diag = FullBandDiagnostics(N, 2.0)
            components = diag.component_spectra(uh)
            np.testing.assert_allclose(components.sum(axis=0), uh, atol=3e-17, rtol=0)
            # Each split is itself a real, divergence-free field.
            for part in components:
                np.testing.assert_allclose(ns.g.fwd(ns.g.inv(part)), part, atol=2e-17, rtol=0)
                self.assertLess(np.max(np.abs(ns.g.div_h(part))), 2e-16)
            d = diag.analyze(uh)
            self.assertAlmostEqual(d["S_total"], stretching_physical(uh), delta=2e-13)
            for key in ("S_closure_error", "S_shell_closure_error", "S_scale_closure_error", "S_plus_closure_error"):
                self.assertLess(abs(d[key]), 2e-13)
            self.assertAlmostEqual(d["S_homochiral"] + d["S_heterochiral"], d["S_total"], delta=2e-15)
            self.assertEqual(len([k for k in d if k.startswith("S_") and k.count("_") == 3
                                  and k.split("_")[1] in COMPONENTS]), 64)
            self.assertGreater(abs(d["S_high_legs_3"]), 1e-6)
            self.assertAlmostEqual(sum(d[f"S_plus_legs_{n}"] for n in range(4)), d["S_total"], delta=2e-15)
            self.assertAlmostEqual(d["S_plus_legs_0"], d["S_mmm"], delta=2e-15)
            self.assertAlmostEqual(d["S_plus_legs_3"], d["S_ppp"], delta=2e-15)
            self.assertAlmostEqual(d["S_plus_legs_1"], d["S_pmm"] + d["S_mpm"] + d["S_mmp"], delta=2e-15)

    def test_shell_sums_match_independent_two_component_calculation(self):
        _, uh = self.random_field()
        diag = FullBandDiagnostics(16, 2.5)
        two_tensor = diag.ordered_channels(diag.helical_components(uh))
        d = diag.analyze(uh)
        for a, sa in enumerate("pm"):
            for b, sb in enumerate("pm"):
                for c, sc in enumerate("pm"):
                    self.assertAlmostEqual(d[f"S_{sa}{sb}{sc}"], two_tensor[a, b, c], delta=2e-15)
        low = uh * diag.low
        high = uh * diag.high
        self.assertAlmostEqual(d["S_high_legs_0"], stretching_physical(low), delta=2e-15)
        self.assertAlmostEqual(d["S_high_legs_3"], stretching_physical(high), delta=2e-15)
        self.assertGreater(abs(d["S_high_legs_1"]) + abs(d["S_high_legs_2"]), 1e-6)

    def test_translation_invariance_of_every_block(self):
        _, uh = self.random_field()
        diag = FullBandDiagnostics(16, 2)
        angle = np.einsum("...j,j->...", diag.modes, [.374, -.818, 1.27])
        a, b = diag.analyze(uh), diag.analyze(uh * np.exp(1j * angle))
        for key in a:
            if key.startswith("S_") or "block_" in key:
                self.assertAlmostEqual(a[key], b[key], delta=5e-13, msg=key)

    def test_gauge_free_projectors_equal_orthonormal_basis_projection(self):
        _, uh = self.random_field()
        diag = FullBandDiagnostics(16)
        basis = helical_basis(diag.modes)
        theta = np.random.default_rng(65).uniform(-np.pi, np.pi, size=basis.shape[:-1])
        gauged = basis * np.exp(1j * theta[..., None])
        velocity = np.moveaxis(uh, 0, -1)
        c = np.einsum("...si,...i->...s", gauged.conj(), velocity)
        projected = np.moveaxis(c[..., :, None] * gauged, (-2, -1), (0, 1))
        np.testing.assert_allclose(diag.helical_components(uh), projected, atol=3e-17, rtol=0)
        np.testing.assert_allclose(diag.ordered_channels(projected),
                                   diag.ordered_channels(diag.helical_components(uh)),
                                   atol=2e-15, rtol=0)

    def test_initial_family_and_scale_support(self):
        ns = NS(18)
        for phi in (0, .37, np.pi / 2, np.pi, 4.7):
            uh = ns.init_family(phi, a=.8, b=1.2, c=.9, d=.7)
            d = analyze_full_band(uh, k0=2)
            self.assertAlmostEqual(d["S_total"], .8 * .9 * .7 * np.cos(phi) / 4, delta=2e-15)
            self.assertAlmostEqual(d["S_high_legs_0"], d["S_total"], delta=2e-15)
            for n in (1, 2, 3):
                self.assertLess(abs(d[f"S_high_legs_{n}"]), 2e-15)

    def test_homochiral_matches_explicit_full_support_triad_sum(self):
        ns, uh = self.random_field()
        mask = np.max(np.abs(FullBandDiagnostics(16).modes), axis=-1) <= 2
        uh = uh * mask
        direct = analyze_full_band(uh, k0=1.5)
        triads, _ = TriadTable(2).analyze(uh)
        for cls in ("homochiral", "heterochiral"):
            self.assertAlmostEqual(direct[f"S_{cls}"], triads[f"S_{cls}"], delta=2e-15)

    def test_block_l1_is_coarse_activity_not_triad_activity(self):
        _, uh = self.random_field()
        d = analyze_full_band(uh)
        self.assertGreaterEqual(d["shell_block_L1"] + 1e-15, d["sign_block_L1"])
        self.assertGreaterEqual(d["sign_block_L1"] + 1e-15, abs(d["S_total"]))
        for label in ("shell", "sign"):
            self.assertAlmostEqual(d[f"{label}_block_positive_sum"] + d[f"{label}_block_negative_sum"],
                                   d["S_total"], delta=2e-15)
            self.assertGreaterEqual(d[f"{label}_block_cancellation_fraction"], -2e-15)
            self.assertLessEqual(d[f"{label}_block_cancellation_fraction"], 1)

    def test_empty_shells_and_zero_field(self):
        _, uh = self.random_field()
        for k0, occupied in ((0, 3), (100, 0)):
            d = analyze_full_band(uh, k0=k0)
            for n in range(4):
                self.assertAlmostEqual(d[f"S_high_legs_{n}"], d["S_total"] if n == occupied else 0,
                                       delta=2e-15)
        d = analyze_full_band(np.zeros_like(uh))
        self.assertEqual(d["S_total"], 0)
        self.assertEqual(d["shell_block_L1"], 0)
        self.assertTrue(np.isnan(d["shell_block_signed_alignment"]))

    def test_mean_velocity_does_not_change_stretching(self):
        _, uh = self.random_field()
        before = analyze_full_band(uh)
        uh[:, 0, 0, 0] = [2, -1, .5]
        after = analyze_full_band(uh)
        for key in before:
            if key.startswith("S_"):
                self.assertAlmostEqual(before[key], after[key], delta=2e-15)
        self.assertGreater(after["mean_velocity_norm"], 0)

    def test_invalid_inputs_are_rejected(self):
        _, uh = self.random_field()
        for N, k0 in ((3, 2), (16.5, 2), (16, -1), (16, np.inf)):
            with self.assertRaises(ValueError):
                FullBandDiagnostics(N, k0)
        bad = uh.copy(); bad[0, 6, 0, 0] = 1
        with self.assertRaisesRegex(ValueError, "N > 3\\*K"):
            analyze_full_band(bad)
        bad = uh.copy(); bad[0, 1, 0, 0] += 1; bad[0, -1, 0, 0] += 1
        with self.assertRaisesRegex(ValueError, "divergence-free"):
            analyze_full_band(bad)
        bad = uh.copy(); bad[1, 1, 0, 0] += 1j
        with self.assertRaisesRegex(ValueError, "conjugacy"):
            analyze_full_band(bad)
        bad = uh.copy(); bad[0, 0, 0, 0] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            analyze_full_band(bad)
        with self.assertRaisesRegex(ValueError, "shape"):
            analyze_full_band(uh[0])


if __name__ == "__main__":
    unittest.main()
