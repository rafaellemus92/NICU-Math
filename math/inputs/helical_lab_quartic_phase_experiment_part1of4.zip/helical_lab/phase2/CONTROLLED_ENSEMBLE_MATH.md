# Exact controls in the phase-only ensemble

For canonical nonzero wavevectors k (one from each pair ±k), use orthonormal helical polarizations h± with h±(−k)=conj(h±(k)). Hold a polarization angle δ_k fixed and draw a common spatial phase θ_k for each case:

c+(k) = A_k exp[i(θ_k+δ_k)],
c−(k) = A_k exp[i(θ_k−δ_k)],
cσ(−k) = conj(cσ(k)).

Then û(k) = sqrt(2) A_k exp(iθ_k) [cos(δ_k)e1(k) − sin(δ_k)e2(k)]. The vector in brackets is a fixed real unit transverse vector. Thus varying θ changes neither the polarization direction nor any Cartesian component's Fourier magnitude. This is stronger than holding only the total energy spectrum fixed.

With normalized spatial averages and the sum below over canonical wavevectors only,

E = 2 Σ A_k²,
Z = 2 Σ |k|² A_k²,
D = 4 Σ |k|⁴ A_k²,
H = 0.

Normalize amplitudes to E=1. The two profiles differ in A_k, but every case within a profile has the same complete Cartesian/helical spectral magnitudes and E,Z,D,H. The case index, seed, and phase draws are not prediction features.

For a triad k+p+q=0 the common phases enter through θ_k+θ_p+θ_q, with the signs implied by negative wavevectors. A spatial translation adds k·a to each mode phase but leaves that triad sum unchanged. The interaction diagnostics are therefore translation-invariant.

## Full resolved stretching blocks

Let u = u+ + u− be the helical decomposition, and split each sign into low/high radial bands at |k|=1.5. This gives four real divergence-free component fields. Their trilinear stretching blocks are

T_abc = <curl(u_a) · [(curl(u_b)·∇)u_c]>.

Summing all 4³=64 ordered blocks reconstructs full S exactly at the resolved Galerkin level. Group by the number of positive-helicity legs (0,1,2,3), or the number of high-band legs (0,1,2,3); either four-group sum is S. Retaining the first three groups of each kind avoids two known sum constraints, but is not a claim that the resulting six features are linearly or statistically independent.

The individual blocks are signed sums over many triads. Their absolute-value sum is a block-dependent cancellation diagnostic, not the sum of individual triad amplitudes used in Phase 1.

## Prediction versus algebra

The primary forecast target is Z(0.5)−Z(0). Baseline features include the spectral-profile identity and a flexible cubic function of initial S. The fixed Euler reference is 0.5[S(0)−νD(0)]. Organization features are all measured at t=0. Neither computing Z'(0)=S−νD nor reconstructing S from the blocks is counted as forecasting success.

The fixed train/test split and model fitting rules are documented prospectively. An out-of-sample gain would support these observables for this particular finite-horizon synthetic ensemble. It would not prove deterministic closure or a cutoff-independent Navier–Stokes regularity estimate.
