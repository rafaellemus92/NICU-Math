# An exact local obstruction to phase-blind enstrophy closure

This is a separate, constructive mathematical calculation. It does not change
the 96-case experiment, its frozen plans, its held-out targets, or its negative
primary prediction result. No novelty claim or global-regularity claim is made.

## Result

There are two real, smooth, mean-zero, divergence-free trigonometric-polynomial
initial velocities on the three-dimensional torus with identical **complete
componentwise Fourier magnitudes**, identical E, Z, D, H, and identical initial
stretching S, but different second time derivatives of enstrophy under the same
Navier–Stokes equation and the same fixed viscosity.

Their enstrophy difference satisfies

\[
 Z_+(t)-Z_-(t)=-\frac{101}{12}t^2+o(t^2),\qquad t\downarrow0.
\]

Consequently, those initial summaries do not determine the local future
enstrophy curve. This is an exact obstruction to deterministic closure; it is
not evidence that the organization features tested in the prediction experiment
forecast well.

## 1. Conventions and explicit initial data

Work on \([0,2\pi]^3\), with volume-normalized spatial average \(\langle\cdot\rangle\),
ordinary full Fourier coefficients
\(u(x)=\sum_{k\in\mathbb Z^3}\widehat u(k)e^{ik\cdot x}\), and

\[
 u_t=-P[(u\cdot\nabla)u]+\nu\Delta u,
 \qquad \nabla\cdot u=0.
\]

Here P is the Leray projection. Set \(\omega=\nabla\times u\), and use

\[
 E=\tfrac12\langle |u|^2\rangle,\quad
 Z=\tfrac12\langle |\omega|^2\rangle,\quad
 D=\langle |\nabla\omega|^2\rangle,\quad
 H=\langle u\cdot\omega\rangle,\quad
 S=\langle\omega\cdot(\omega\cdot\nabla)u\rangle.
\]

In particular, \(Z'=S-\nu D\). D has **no** factor of one half.

Let \(s\in\{+1,-1\}\), and define

\[
 u_s(x)=q_1\cos(k_1\cdot x)+q_2\cos(k_2\cdot x)
       +q_3\cos(k_3\cdot x)+s q_4\cos(k_4\cdot x),
\]

with

| j | \(k_j\) | \(q_j\) | \(|k_j|^2\) | \(|q_j|^2\) |
|---|---|---|---:|---:|
| 1 | (1,0,0) | (0,1,−1) | 1 | 2 |
| 2 | (1,1,0) | (−1,1,0) | 2 | 2 |
| 3 | (0,1,1) | (−1,−1,1) | 2 | 3 |
| 4 | (2,2,1) | (−2,1,2) | 9 | 9 |

Every \(k_j\cdot q_j=0\). Thus both fields are real, smooth, mean-zero and
divergence-free. Their only nonzero Fourier vectors are
\(\widehat u_s(\pm k_j)=q_j/2\) for j=1,2,3 and
\(\widehat u_s(\pm k_4)=s q_4/2\).

Writing \(a=x+y\), \(b=y+z\), and \(c=2x+2y+z\), the same fields are

\[
u_s=\big(-\cos a-\cos b-2s\cos c,
\;\cos x+\cos a-\cos b+s\cos c,
\;-\cos x+\cos b+2s\cos c\big).
\]

Flipping s multiplies each component at \(\pm k_4\) by −1 and leaves all other
coefficients unchanged. Thus every Cartesian component's magnitude at every
wavevector is identical. In fact, each mode's Hermitian outer product
\(\widehat u(k)\widehat u(k)^*\), and the magnitudes in any fixed helical basis,
are identical as well.

The difference is genuine relative phase: \(k_4=k_1+k_2+k_3\), so changing only
the fourth cosine sign cannot be achieved by a spatial translation that leaves
the first three Fourier vectors unchanged.

## 2. Exact common initial data

Orthogonality of distinct cosine modes gives

\[
 E=\tfrac14\sum_j|q_j|^2=4,\qquad
 Z=\tfrac14\sum_j|k_j|^2|q_j|^2=\frac{93}{4},\qquad
 D=\tfrac12\sum_j|k_j|^4|q_j|^2=\frac{751}{2}.
\]

Each velocity is even under \(x\mapsto-x\), whereas its vorticity and velocity
gradient are odd. Therefore both helicity and the stretching integrand have odd
parity and

\[
 H=0,\qquad S=0,\qquad Z'(0)=-\frac{751}{2}\nu.
\]

This is important: including S **does** determine the instantaneous enstrophy
derivative through the exact balance. The missing information first appears
here in \(S'(0)\) and \(Z''(0)\), not in \(Z'(0)\).

## 3. Full finite Fourier recurrence

For two finite Fourier fields define

\[
 \widehat {B(a,b)}(k)
 =-i P_k\sum_{p+q=k}[\widehat a(p)\cdot q]\widehat b(q),\qquad
 P_k v=v-k\frac{k\cdot v}{|k|^2}\quad(k\ne0).
\]

Both dots inside this formula are bilinear, with no complex conjugation. Set
\(P_0=I\); the generated zero modes vanish for the divergence-free fields here.
All generated convolution modes are retained. There is no Galerkin cutoff or
time-stepping approximation in this calculation.

For either initial field a let

\[
 n=B(a,a),\qquad \ell=\Delta a.
\]

The actual first and second time derivatives at zero are

\[
 u_t=n+\nu\ell,
\]
\[
 u_{tt}=B(n,a)+B(a,n)
 +\nu\{B(\ell,a)+B(a,\ell)+\Delta n\}
 +\nu^2\Delta\ell.
\]

With the conjugated full Parseval inner product, differentiation of
\(Z=\frac12\|\omega\|_2^2\) yields

\[
 Z''=\|\nabla\times u_t\|_2^2
       +\langle\nabla\times a,\nabla\times u_{tt}\rangle.
\]

There is no extra factor of two on the second term when \(u_{tt}\) means the
actual derivative. If instead \(u=a+t u_1+t^2 u_2+\cdots\), then
\(u_2=u_{tt}/2\) and the second term becomes
\(2\langle\nabla\times a,\nabla\times u_2\rangle\).

### Finite rational certificate for the inviscid terms

Let \(m=B(n,a)+B(a,n)\). Direct evaluation of the displayed recurrence gives:

| Contribution | s=+1 | s=−1 |
|---|---:|---:|
| \(\|\nabla\times n\|_2^2\) | 663/4 | 877/4 |
| \(\langle\nabla\times a,\nabla\times m\rangle\) | −1717/14 | −6691/42 |
| Sum | **1207/28** | **5035/84** |

For a more granular certificate, the following rows give the contribution of
both k and −k to \(\|\nabla\times n\|_2^2\); all other modes vanish:

| Representative k | s=+1 | s=−1 |
|---|---:|---:|
| (0,1,0) | 1/4 | 1/4 |
| (1,−1,−1) | 3/4 | 3/4 |
| (1,0,−1) | 3/4 | 3/4 |
| (1,1,1) | 3/4 | 9/4 |
| (1,2,1) | 3/2 | 53/2 |
| (2,1,0) | 48 | 75 |
| (2,3,2) | 297/4 | 297/4 |
| (3,2,1) | 139/4 | 139/4 |
| (3,3,1) | 19/4 | 19/4 |

The contributions of both k and −k to
\(\langle\nabla\times a,\nabla\times m\rangle\) are:

| Representative k | s=+1 | s=−1 |
|---|---:|---:|
| (1,0,0) | −199/140 | −93/28 |
| (1,1,0) | −2/5 | −22/3 |
| (0,1,1) | −662/85 | −608/51 |
| (2,2,1) | −269019/2380 | −65085/476 |

These tables and the defining coefficients are also saved in
`results/phase2/exact_obstruction.json`. The accompanying script evaluates them
with `fractions.Fraction` Gaussian-rational arithmetic, including all conjugate
modes and Leray denominators. It does not infer the result from floating-point
values or a computer algebra system.

### Viscosity terms

n is odd and \(\ell\) is even. Thus \(\nabla\times n\) is even while
\(\nabla\times\ell\) is odd, and their inner product vanishes. The coefficient
of \(\nu\) in \(u_{tt}\) is odd, so its curl is even and its inner product with
the odd initial vorticity also vanishes. Consequently the coefficient of
\(\nu\) in \(Z''(0)\) is exactly zero.

The two quadratic-viscosity contributions are each

\[
 \|\Delta\omega\|_2^2
 =\tfrac12\sum_j |k_j|^6|q_j|^2=\frac{6603}{2}.
\]

It follows that, for any fixed viscosity,

\[
 \boxed{Z''_+(0)=\frac{1207}{28}+6603\nu^2},\qquad
 \boxed{Z''_-(0)=\frac{5035}{84}+6603\nu^2},
\]

and hence

\[
 \boxed{Z''_+(0)-Z''_-(0)=-\frac{101}{6}}.
\]

As additional exact checks, direct differentiation of the trilinear stretching
expression and D gives

\[
 S'_+(0)=\frac{1207}{28},\qquad S'_-(0)=\frac{5035}{84},\qquad
 D'_+(0)=D'_-(0)=-6603\nu.
\]

Thus differentiating \(Z'=S-\nu D\) independently reproduces the same result.
The script also verifies the first and second inviscid energy derivatives vanish.

At the experiment's viscosity \(\nu=1/28\), the exact values are

\[
 Z'_+(0)=Z'_-(0)=-\frac{751}{56},\quad
 Z''_+(0)=\frac{40399}{784},\quad
 Z''_-(0)=\frac{160789}{2352}.
\]

## 4. Consequence for the PDE, and exact limits of the claim

Smooth periodic divergence-free data have smooth local classical solutions;
this uses the standard local theory, not any proposed global-regularity argument.
For a primary overview, see Charles Fefferman's
[Clay problem description, page 2](https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf).

Fix any \(\nu>0\) and restrict to the common local existence interval of the two
solutions. Their identical initial Z and Z', together with the different exact
second derivatives, imply by Taylor expansion that

\[
 Z_+(t)-Z_-(t)=-\frac{101}{12}t^2+o(t^2).
\]

In particular, their enstrophies differ for every sufficiently small positive t.
No infinite Taylor-series convergence claim is needed; twice continuous time
differentiability is enough.

This rules out:

1. A deterministic rule that recovers the entire local future enstrophy curve
   for all smooth initial fields from their complete initial componentwise
   Fourier magnitudes together with E, Z, D, H and S.
2. A universal autonomous first-order evolution law for the reduced vector
   (E,Z,D,H,S), since the same reduced initial vector has two different S'
   values. The conclusion persists even if the complete initial Fourier
   magnitudes are also supplied to that derivative rule.

It does **not** rule out useful statistical prediction on a restricted
distribution, an inequality or bound rather than a deterministic equality,
closure with additional phase-sensitive information, or closure with memory.
It proves nothing about finite-time singularities, global smoothness, the
particular horizon t=0.5, or the predictive quality of the six organization
features. No claim is made that this type of obstruction is new.

## 5. Discovery, verification and reproduction

This pair was chosen in a small, separate constructive search after the
prediction experiment. It is not a preregistered predictive endpoint.

- The initial proposal used k=(1,0,0),(0,1,0),(0,0,1),(1,1,1), with
  q=(0,1,0),(0,0,1),(1,0,0),(1,−1,0), and flipped the fourth mode. It fails:
  both signs give \(Z''=9/4+57\nu^2\). This failed trial is retained in the JSON.
- The first exact nonorthogonal trial used the final wavevectors but
  q=(0,0,1),(0,0,−1),(0,1,−1),(0,1,−2). It already gives a difference 6/5,
  with E=9/4, Z=13 and D=209. It too is retained as discovery provenance.
- The displayed pair has nonzero entries across all three Cartesian components.
  It was independently suggested by a small numerical polarization search
  reported with seed 67 and then certified here by exact arithmetic. Its literal
  integer vectors, rather than any random-number implementation, define the
  reproducible certificate. The discovery procedure is not evidence for the
  proof; the finite exact recurrence is.

From the package root `helical_lab`, run:

```sh
python -m phase2.exact_obstruction
python -m phase2.exact_obstruction --verify-numpy
python -m unittest discover -s phase2/tests -p 'test_exact_obstruction.py' -v
```

The first command needs only Python's standard library. The optional second
command uses the existing independent NumPy **rotational-form** RHS, constructs
the cosine velocities on the physical grid, and computes a centered directional
derivative of the quadratic RHS. It does not advance a trajectory. Across N=24
and N=32, viscosities 0, 1/28 and 1/5, both signs and directional increments 1 and
0.01, all 24 checks agree with the exact formula to absolute error at most
\(6.3\times10^{-13}\) in the recorded run.

The optional numerical check is corroboration, not a premise of the exact
certificate. The default and optional commands write only
`results/phase2/exact_obstruction.json`; the prediction data and plans are not
read or changed.
