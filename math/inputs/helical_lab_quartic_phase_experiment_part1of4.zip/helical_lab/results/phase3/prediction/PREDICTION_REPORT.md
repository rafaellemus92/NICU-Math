# Phase 3 held-out finite-horizon prediction

The prospective protocol and initial inputs were frozen before integration. All twelve learning-curve models were fitted and saved before held-out targets were extracted. The primary target is delta_Z at T=0.5; the exact Sdot identity is not a prediction endpoint.

## Models and test protocol

M0/baseline: separate unpenalized profile intercepts and profile-specific S,S²,S³. Viscous: M0 plus nu*V and nu*Ddot, with full-NS Ddot. Quartic: viscous plus Q. Curvature: viscous plus Zddot. Euler and second-order Taylor are fixed references.

The 64,128,192 training-case sets are nested, balanced across profiles, and share one final 64-case test set. The 192-case viscous-versus-quartic comparison is primary; smaller learning-curve fits and every other comparison are descriptive. There was no test-based model, feature, grid, or stopping choice.

Quartic and curvature have exactly the same information and linear span because Zddot=Q+nu*V−nu*Ddot. Standardized ridge is not invariant to this coordinate change: their differences reflect penalty parameterization, not additional physical information. The primary comparison adds one penalized column; it is not an equal-parameter-count comparison.

## Training size 64

| Model | Group | n | MAE | RMSE | MSE | alpha |
|---|---|---:|---:|---:|---:|---:|
| baseline | pooled | 64 | 0.0250776463 | 0.0347130901 | 0.00120499863 | 0.0001 |
| baseline | flat | 32 | 0.0335245859 | 0.044135537 | 0.00194794563 | 0.0001 |
| baseline | kminus2 | 32 | 0.0166307067 | 0.0214953861 | 0.000462051625 | 0.0001 |
| viscous | pooled | 64 | 0.0235105785 | 0.0308285763 | 0.000950401116 | 10 |
| viscous | flat | 32 | 0.0286756795 | 0.0367842615 | 0.00135308189 | 10 |
| viscous | kminus2 | 32 | 0.0183454776 | 0.0234034258 | 0.000547720338 | 10 |
| quartic | pooled | 64 | 0.00762377517 | 0.0122412004 | 0.000149846988 | 0.0001 |
| quartic | flat | 32 | 0.0118633332 | 0.0167567135 | 0.000280787446 | 0.0001 |
| quartic | kminus2 | 32 | 0.00338421708 | 0.00434816385 | 1.89065289e-05 | 0.0001 |
| curvature | pooled | 64 | 0.00762378876 | 0.0122410796 | 0.000149844029 | 0.0001 |
| curvature | flat | 32 | 0.0118633245 | 0.0167565187 | 0.00028078092 | 0.0001 |
| curvature | kminus2 | 32 | 0.00338425298 | 0.0043482339 | 1.89071381e-05 | 0.0001 |
| euler_fixed | pooled | 64 | 0.255904455 | 0.278325766 | 0.0774652323 | fixed |
| euler_fixed | flat | 32 | 0.360423453 | 0.362729274 | 0.131572526 | fixed |
| euler_fixed | kminus2 | 32 | 0.151385457 | 0.152833041 | 0.0233579386 | fixed |
| taylor2_fixed | pooled | 64 | 0.0905460538 | 0.10900036 | 0.0118810784 | fixed |
| taylor2_fixed | flat | 32 | 0.149953632 | 0.150869704 | 0.0227616675 | fixed |
| taylor2_fixed | kminus2 | 32 | 0.0311384759 | 0.0316305116 | 0.00100048927 | fixed |

Training-only selected CV MSE and centered design rank:

- baseline: CV MSE 0.00105099931; rank 6/6; constant columns [].
- viscous: CV MSE 0.00116292202; rank 8/8; constant columns [].
- quartic: CV MSE 6.97555614e-05; rank 9/9; constant columns [].
- curvature: CV MSE 6.97579738e-05; rank 9/9; constant columns [].

Viscous-minus-quartic relative held-out improvements (positive is better):

- pooled: MAE 67.5730%; RMSE 60.2927%; MSE 84.2333%.
- flat: MAE 58.6293%; RMSE 54.4460%; MSE 79.2483%.
- kminus2: MAE 81.5529%; RMSE 81.4208%; MSE 96.5481%.

## Training size 128

| Model | Group | n | MAE | RMSE | MSE | alpha |
|---|---|---:|---:|---:|---:|---:|
| baseline | pooled | 64 | 0.0214844122 | 0.0277710679 | 0.000771232211 | 10 |
| baseline | flat | 32 | 0.0270060148 | 0.0335391638 | 0.00112487551 | 10 |
| baseline | kminus2 | 32 | 0.0159628095 | 0.0204349924 | 0.000417588914 | 10 |
| viscous | pooled | 64 | 0.019995063 | 0.0259799864 | 0.000674959691 | 1 |
| viscous | flat | 32 | 0.0254264458 | 0.031376676 | 0.000984495795 | 1 |
| viscous | kminus2 | 32 | 0.0145636802 | 0.0191160558 | 0.000365423588 | 1 |
| quartic | pooled | 64 | 0.00558506962 | 0.00742651168 | 5.51530758e-05 | 0.1 |
| quartic | flat | 32 | 0.00814218362 | 0.00975068472 | 9.50758525e-05 | 0.1 |
| quartic | kminus2 | 32 | 0.00302795561 | 0.00390260158 | 1.52302991e-05 | 0.1 |
| curvature | pooled | 64 | 0.00560836161 | 0.00744473733 | 5.54241139e-05 | 0.1 |
| curvature | flat | 32 | 0.00817386439 | 0.00977009784 | 9.54548118e-05 | 0.1 |
| curvature | kminus2 | 32 | 0.00304285883 | 0.00392344442 | 1.53934161e-05 | 0.1 |
| euler_fixed | pooled | 64 | 0.255904455 | 0.278325766 | 0.0774652323 | fixed |
| euler_fixed | flat | 32 | 0.360423453 | 0.362729274 | 0.131572526 | fixed |
| euler_fixed | kminus2 | 32 | 0.151385457 | 0.152833041 | 0.0233579386 | fixed |
| taylor2_fixed | pooled | 64 | 0.0905460538 | 0.10900036 | 0.0118810784 | fixed |
| taylor2_fixed | flat | 32 | 0.149953632 | 0.150869704 | 0.0227616675 | fixed |
| taylor2_fixed | kminus2 | 32 | 0.0311384759 | 0.0316305116 | 0.00100048927 | fixed |

Training-only selected CV MSE and centered design rank:

- baseline: CV MSE 0.000794059749; rank 6/6; constant columns [].
- viscous: CV MSE 0.000807533776; rank 8/8; constant columns [].
- quartic: CV MSE 4.96470022e-05; rank 9/9; constant columns [].
- curvature: CV MSE 5.00156799e-05; rank 9/9; constant columns [].

Viscous-minus-quartic relative held-out improvements (positive is better):

- pooled: MAE 72.0678%; RMSE 71.4145%; MSE 91.8287%.
- flat: MAE 67.9775%; RMSE 68.9238%; MSE 90.3427%.
- kminus2: MAE 79.2089%; RMSE 79.5847%; MSE 95.8322%.

## Training size 192

| Model | Group | n | MAE | RMSE | MSE | alpha |
|---|---|---:|---:|---:|---:|---:|
| baseline | pooled | 64 | 0.0212612443 | 0.0269244331 | 0.000724925098 | 1 |
| baseline | flat | 32 | 0.0265626331 | 0.0324097152 | 0.00105038964 | 1 |
| baseline | kminus2 | 32 | 0.0159598555 | 0.0199865094 | 0.000399460558 | 1 |
| viscous | pooled | 64 | 0.0208145945 | 0.0263094501 | 0.000692187166 | 1 |
| viscous | flat | 32 | 0.026285997 | 0.0318080721 | 0.00101175345 | 1 |
| viscous | kminus2 | 32 | 0.015343192 | 0.0193033904 | 0.00037262088 | 1 |
| quartic | pooled | 64 | 0.00574725415 | 0.007377523 | 5.44278457e-05 | 0.01 |
| quartic | flat | 32 | 0.00813533894 | 0.00963145401 | 9.27649063e-05 | 0.01 |
| quartic | kminus2 | 32 | 0.00335916935 | 0.00401133208 | 1.6090785e-05 | 0.01 |
| curvature | pooled | 64 | 0.00574877471 | 0.00737877447 | 5.44463127e-05 | 0.01 |
| curvature | flat | 32 | 0.00813766935 | 0.00963281601 | 9.27911443e-05 | 0.01 |
| curvature | kminus2 | 32 | 0.00335988007 | 0.00401266509 | 1.61014811e-05 | 0.01 |
| euler_fixed | pooled | 64 | 0.255904455 | 0.278325766 | 0.0774652323 | fixed |
| euler_fixed | flat | 32 | 0.360423453 | 0.362729274 | 0.131572526 | fixed |
| euler_fixed | kminus2 | 32 | 0.151385457 | 0.152833041 | 0.0233579386 | fixed |
| taylor2_fixed | pooled | 64 | 0.0905460538 | 0.10900036 | 0.0118810784 | fixed |
| taylor2_fixed | flat | 32 | 0.149953632 | 0.150869704 | 0.0227616675 | fixed |
| taylor2_fixed | kminus2 | 32 | 0.0311384759 | 0.0316305116 | 0.00100048927 | fixed |

Training-only selected CV MSE and centered design rank:

- baseline: CV MSE 0.000646188819; rank 6/6; constant columns [].
- viscous: CV MSE 0.000648127336; rank 8/8; constant columns [].
- quartic: CV MSE 5.04498006e-05; rank 9/9; constant columns [].
- curvature: CV MSE 5.04604934e-05; rank 9/9; constant columns [].

Viscous-minus-quartic relative held-out improvements (positive is better):

- pooled: MAE 72.3883%; RMSE 71.9587%; MSE 92.1368%.
- flat: MAE 69.0507%; RMSE 69.7201%; MSE 90.8313%.
- kminus2: MAE 78.1065%; RMSE 79.2195%; MSE 95.6817%.

## Primary paired uncertainty

Viscous-minus-quartic test MSE: 0.00063775932; profile-stratified paired percentile 95% interval [0.000414570432, 0.00090847854], from 2000 bootstrap resamples. Fraction above zero: 1.0000; this is not a p-value.

The interval resamples independent held-out phase realizations conditional on the fitted models and this synthetic distribution. It omits training-set variability, numerical discretization uncertainty, and distribution shift. No additional model comparison has a confirmatory interval.

## Numerical checks and limits

- probe_dt_half: 8 cases; maximum absolute delta_Z difference 1.08322684e-10; corresponding empirical frozen-prediction gain-sensitivity scale 4.27074494e-12.
- probe_n32: 8 cases; maximum absolute delta_Z difference 6.46616171e-06; corresponding empirical frozen-prediction gain-sensitivity scale 2.54935775e-07.

abs(change in viscous-minus-quartic MSE gain) <= 2*mean(abs(pred_quartic-pred_viscous))*epsilon, IF every test target error is bounded by epsilon and predictions are frozen.

Probe differences are empirical comparisons on predeclared cases, not bounds on all test cases or the continuum. The sensitivity calculation fixes fitted predictions and does not include numerical changes in training targets, features, or refitted coefficients.

## Predeclared practical gate

Gate passed; numerical probes available. This does not authorize any replication or paid compute.

- pooled_mse_reduction_at_least_10_percent: True.
- nonnegative_mse_reduction_each_profile: True.
- probe_rms_below_10_percent_of_primary_rmse_reduction: True.

Predeclared resource-allocation screen, not a statistical guarantee or authorization for a new cohort or paid compute. The largest branch RMS is used so both numerical comparisons must pass.

## Reproducibility and conclusion

The quartic model reduces primary pooled held-out MSE. The conditional paired interval lies above zero.

This is a finite two-profile random-phase experiment at one horizon and viscosity. A gain does not establish an information-theoretically minimal closure, universal predictive sufficiency, coercivity, a priori control, or Navier–Stokes global regularity. The total scalar Q is tested here; no quartet-resolved decomposition is tested.

Saved artifacts: all case-level targets/predictions at every training size; fitted parameters and train-only standardizers; every alpha/fold CV score; the primary bootstrap draws; a pre-evaluation fit-lock manifest; input/code hashes and exact identity/rank diagnostics. Phase 2 is imported unchanged.

Protocol SHA256: 946befe5a61314194c1b38ab0f81d9542b3d0d47b16ef08b3244047b4f16db9c
Initial manifest SHA256: 8241c8a613e3eebc1b2ffa4ed824ca545a9d85145b3b2367d90fa497055fda66
Production input SHA256: 6bdf653bc1130cdffddbb83f923a87f2e8823cee5f63c2ec794ed05d99728d77
