#!/usr/bin/env python3
"""Analyze saved solver runs with exact low-band helical stretching triads.

Example: python analyze_triads.py results/runs --diagnostic-k 3
Outputs are one directory per run below results/triads_k3 unless --output is set.
No global dominance claim is inferred from the limited low-band triad census.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from helical import TriadTable, filter_rfft, spectral_diagnostics, stretching_physical


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    with Path(path).open("w", newline="") as f:
        out = csv.DictWriter(f, fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def integrate(y, times, axis=0):
    if len(times) < 2:
        return np.zeros_like(np.take(y, 0, axis=axis))
    return np.trapezoid(y, times, axis=axis)


def phase_track(z, times, relative_floor=1e-6, absolute_floor=1e-14):
    """Phase on active samples, differentiated only on resolved segments.

    Do not bridge masked zeros, near-zero straight chords between samples,
    or phase steps >=pi/2. A flagged chord is a sampling warning, not proof
    of an actual zero; resolve it by saving more frequent snapshots.
    """
    if relative_floor < 0 or absolute_floor < 0:
        raise ValueError("phase amplitude floors must be nonnegative")
    z = np.asarray(z)
    weights = np.abs(z)
    threshold = np.maximum(absolute_floor, relative_floor * weights.max(axis=0))
    valid = weights > threshold[None, :]
    phase = np.where(valid, np.angle(z), np.nan)
    unwrapped = np.full(z.shape, np.nan)
    velocity = np.full(z.shape, np.nan)
    ambiguous = np.zeros(z.shape, dtype=bool)  # incoming time interval for each sample
    if len(times) > 1:
        delta = z[1:] - z[:-1]
        denom = np.abs(delta) ** 2
        frac = np.clip(-np.real(z[:-1].conj() * delta) / np.where(denom > 0, denom, 1), 0, 1)
        chord_minimum = np.abs(z[:-1] + frac * delta)
        phase_step = np.abs(np.angle(z[1:] * z[:-1].conj()))
        ambiguous[1:] = valid[1:] & valid[:-1] & ((chord_minimum <= threshold[None, :]) | (phase_step >= np.pi/2))
    for j in range(z.shape[1]):
        inds = np.flatnonzero(valid[:, j])
        if not len(inds):
            continue
        breaks = (np.diff(inds) > 1) | ambiguous[inds[1:], j]
        groups = np.split(inds, np.flatnonzero(breaks) + 1)
        for group in groups:
            unwrapped[group, j] = np.unwrap(phase[group, j])
            if len(group) >= 3:
                velocity[group, j] = np.gradient(unwrapped[group, j], times[group])
        # The two samples bracketing an unresolved jump cannot support a derivative.
        bad = np.flatnonzero(ambiguous[:, j])
        velocity[bad, j] = np.nan
        velocity[bad-1, j] = np.nan
    return {"weight": weights, "phase": phase, "phase_unwrapped": unwrapped,
            "phase_velocity": velocity, "phase_valid": valid,
            "phase_interval_ambiguous": ambiguous,
            "phase_velocity_valid": np.isfinite(velocity),
            "phase_amplitude_threshold": threshold}


def analyze_run(snapshot_path, output, table, top=20, phase_relative_floor=1e-6):
    if top < 1 or phase_relative_floor < 0:
        raise ValueError("top must be positive and phase_relative_floor nonnegative")
    snapshot_path = Path(snapshot_path)
    with np.load(snapshot_path, allow_pickle=False) as data:
        times = data["times"].astype(float)
        states = data["uh"]
        source_metadata = json.loads(str(data["metadata_json"])) if "metadata_json" in data else {}
        run_parameters = {k: data[k].item() for k in ("N", "K", "nu", "phi", "dt", "T") if k in data}
    if not len(times) or len(times) != len(states) or np.any(np.diff(times) <= 0):
        raise ValueError("snapshot times must be strictly increasing and match states")
    if "K" in run_parameters and states.shape[-3] <= 3 * run_parameters["K"]:
        raise ValueError("N must exceed 3*source K for alias-free full-field cubic quadrature")
    rows, all_terms = [], []
    for time, uh in zip(times, states):
        full = spectral_diagnostics(uh)
        low = spectral_diagnostics(filter_rfft(uh, table.K))
        triad, z = table.analyze(uh)
        S_full = stretching_physical(uh)
        row = {"time": float(time), **full, "S_full": S_full, **triad,
               "S_full_minus_low": S_full - triad["S_low_triads"],
               "E_low": low["E"], "Z_low": low["Z"], "H_low": low["H"],
               "E_low_fraction": low["E"] / full["E"] if full["E"] > 0 else np.nan,
               "Z_low_fraction": low["Z"] / full["Z"] if full["Z"] > 0 else np.nan,
               "S_low_over_full": triad["S_low_triads"] / S_full if abs(S_full) > 1e-12 else np.nan}
        rows.append(row)
        all_terms.append(z)
    all_terms = np.asarray(all_terms)
    integrated_weights = integrate(np.abs(all_terms), times)
    order = np.argsort(-integrated_weights, kind="stable")
    active = integrated_weights > max(1e-14, integrated_weights.max(initial=0) * 1e-12)
    selected = order[active[order]][:top]
    z = all_terms[:, selected]
    global_phase_floor = max(1e-14, np.abs(all_terms).max(initial=0) * 1e-12)
    track = phase_track(z, times, phase_relative_floor, global_phase_floor)
    total_integrated_weight = float(integrated_weights.sum())
    ranks = []
    for rank, gi in enumerate(selected, 1):
        j = rank - 1
        mag = np.abs(z[:, j])
        re = z[:, j].real
        integ = float(integrated_weights[gi])
        resultant = integrate(np.where(track["phase_valid"][:, j], z[:, j], 0), times)
        valid_weight = float(integrate(np.where(track["phase_valid"][:, j], mag, 0), times))
        pos = float(integrate(np.maximum(re, 0), times))
        neg = float(integrate(np.minimum(re, 0), times))
        vel = track["phase_velocity"][:, j]
        vv = np.isfinite(vel)
        sign_valid = track["phase_valid"][:, j] & (np.abs(re) > max(global_phase_floor, np.abs(re).max(initial=0) * phase_relative_floor))
        sign_changes = np.sum((np.sign(re[1:]) != np.sign(re[:-1])) & sign_valid[1:] & sign_valid[:-1])
        ranks.append({"rank": rank, "group_index": int(gi), "class": str(table.classes[gi]),
                      "sign_pattern": str(table.sign_patterns[gi]),
                      **{f"{name}{coord}": int(table.modes[table.mode_indices[gi, v], a])
                         for v, name in enumerate(("k", "p", "q")) for a, coord in enumerate(("x", "y", "z"))},
                      **{f"sigma_{name}": int(table.signs[gi, v]) for v, name in enumerate(("k", "p", "q"))},
                      "coefficient_real": float(table.coefficients[gi].real),
                      "coefficient_imag": float(table.coefficients[gi].imag),
                      "integrated_abs_weight": integ,
                      "fraction_lowband_integrated_abs_weight": integ / total_integrated_weight if total_integrated_weight > 0 else np.nan,
                      "integrated_signed_stretching": float(integrate(re, times)),
                      "integrated_positive_stretching": pos,
                      "integrated_negative_stretching": neg,
                      "weighted_cos_phase": float(integrate(re, times)) / integ if integ > 0 else np.nan,
                      "temporal_phase_concentration": abs(resultant) / valid_weight if valid_weight > 0 else np.nan,
                      "valid_phase_snapshots": int(track["phase_valid"][:, j].sum()),
                      "ambiguous_phase_intervals": int(track["phase_interval_ambiguous"][:, j].sum()),
                      "phase_velocity_rms": float(np.sqrt(np.mean(vel[vv] ** 2))) if np.any(vv) else np.nan,
                      "sign_changes_active_snapshots": int(sign_changes)})
    for i, row in enumerate(rows):
        selected_re = float(z[i].real.sum())
        selected_weight = float(np.abs(z[i]).sum())
        row.update({"S_top_groups": selected_re,
                    "top_groups_abs_weight": selected_weight,
                    "top_groups_fraction_lowband_abs_weight": selected_weight / row["triad_abs_weight"] if row["triad_abs_weight"] > 1e-14 else np.nan})
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "snapshot_summary.csv", rows)
    write_csv(output / "ranked_triads.csv", ranks)
    tracks = []
    for i, time in enumerate(times):
        for j, gi in enumerate(selected):
            tracks.append({"time": float(time), "rank": j + 1, "group_index": int(gi),
                           "z_real": float(z[i, j].real), "z_imag": float(z[i, j].imag),
                           **{name: (bool(value[i, j]) if value.dtype.kind == "b" else float(value[i, j]))
                              for name, value in track.items() if value.ndim == 2}})
    write_csv(output / "tracked_triads.csv", tracks)
    np.savez_compressed(output / "tracked_triads.npz", times=times, z=z, group_indices=selected,
                        wavevectors=table.modes[table.mode_indices[selected]], signs=table.signs[selected],
                        coefficients=table.coefficients[selected], **track)
    S_full = np.array([r["S_full"] for r in rows])
    gap = np.array([r["S_full_minus_low"] for r in rows])
    denom = float(integrate(np.abs(S_full), times))
    metadata = {**table.metadata(), "source_snapshots": str(snapshot_path),
                "source_sha256": hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
                "run_parameters": run_parameters, "source_metadata": source_metadata,
                "snapshot_count": len(times), "top_count": len(selected),
                "full_field_cubic_quadrature_certified": "K" in run_parameters and states.shape[-3] > 3 * run_parameters["K"],
                "ranking": "descending time-integrated abs(z), trapezoidal rule over saved snapshots",
                "tracked_lowband_weight_fraction": float(integrated_weights[selected].sum()) / total_integrated_weight if total_integrated_weight else None,
                "phase_relative_amplitude_floor": phase_relative_floor,
                "phase_absolute_amplitude_floor": global_phase_floor,
                "phase_velocity": "gradient of unwrapped arg(z) on contiguous active segments with >=3 samples; split at masked zeros, near-zero straight chords, or phase steps >=pi/2; mask derivatives bracketing ambiguous intervals",
                "phase_sampling_caveat": "Saved cadence may miss rotations >pi per interval even without a flag. Near-zero chords and phase steps >=pi/2 are ambiguity flags, not proof of zeros. Phase derivative changes sign under conjugate representative, whereas stretching does not.",
                "temporal_phase_concentration": "abs(integral z dt)/integral abs(z) dt on active snapshots; 1 means constant phase, including stable negative alignment",
                "S_low_over_full_warning": "Signed diagnostic ratio, not a bounded coverage fraction; undefined near S_full=0. E/Z low fractions are true positive spectral coverage measures.",
                "max_triad_closure_error": max(abs(r["triad_closure_error"]) for r in rows),
                "max_helical_H_error": max(abs(r["H_helical_error"]) for r in rows),
                "max_helical_Z_error": max(abs(r["Z_helical_error"]) for r in rows),
                "max_reconstruction_error": max(r["helical_reconstruction_max_error"] for r in rows),
                "integrated_absolute_full_minus_low_over_integrated_absolute_full": float(integrate(np.abs(gap), times)) / denom if denom > 1e-14 else None,
                "minimum_lowband_E_fraction": min(r["E_low_fraction"] for r in rows),
                "minimum_lowband_Z_fraction": min(r["Z_low_fraction"] for r in rows),
                "code_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__), Path(__file__).with_name("helical.py"))}}
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return metadata, rows, ranks


def compare_cadence(coarse_directory, fine_directory, output_directory):
    """Compare common top-ranked groups from two analyses of the same trajectory.

    Reproduce the bundled check with:
      compare_cadence('results/triads_k3/n32_phi0_dt0p005',
                      'results/cadence_triads_k3/n32_phi0_dt0p005',
                      'results/cadence_triads_k3')
    """
    coarse_directory, fine_directory = Path(coarse_directory), Path(fine_directory)
    with (coarse_directory / "ranked_triads.csv").open() as f:
        coarse_rows = {int(r["group_index"]): r for r in csv.DictReader(f)}
    with (fine_directory / "ranked_triads.csv").open() as f:
        fine_rows = {int(r["group_index"]): r for r in csv.DictReader(f)}
    common = sorted(coarse_rows.keys() & fine_rows.keys())
    rows = []
    for gi in common:
        a, b = coarse_rows[gi], fine_rows[gi]
        rows.append({"group_index": gi, "coarse_rank": int(a["rank"]), "fine_rank": int(b["rank"]),
                     "coarse_concentration": float(a["temporal_phase_concentration"]),
                     "fine_concentration": float(b["temporal_phase_concentration"]),
                     "coarse_cos": float(a["weighted_cos_phase"]), "fine_cos": float(b["weighted_cos_phase"]),
                     "concentration_difference": float(b["temporal_phase_concentration"]) - float(a["temporal_phase_concentration"]),
                     "cos_difference": float(b["weighted_cos_phase"]) - float(a["weighted_cos_phase"])})
    with np.load(coarse_directory / "tracked_triads.npz") as data:
        a = {k: data[k] for k in data.files}
    with np.load(fine_directory / "tracked_triads.npz") as data:
        b = {k: data[k] for k in data.files}
    matching_time_indices = []
    for t in a["times"]:
        match = np.flatnonzero(np.isclose(b["times"], t, rtol=0, atol=1e-11))
        if len(match) != 1:
            raise ValueError("every coarse time must match exactly one fine time")
        matching_time_indices.append(match[0])
    phase_errors, term_errors = [], []
    for gi in common:
        ia = list(a["group_indices"]).index(gi)
        ib = list(b["group_indices"]).index(gi)
        if not np.array_equal(a["wavevectors"][ia], b["wavevectors"][ib]) or not np.array_equal(a["signs"][ia], b["signs"][ib]):
            raise ValueError("group indices do not refer to the same polarized triads")
        za, zb = a["z"][:, ia], b["z"][matching_time_indices, ib]
        valid = a["phase_valid"][:, ia] & b["phase_valid"][matching_time_indices, ib]
        phase_errors.append(float(np.max(np.abs(np.angle(za[valid] * zb[valid].conj())), initial=0)))
        term_errors.append(float(np.max(np.abs(za-zb), initial=0)))
    increments = np.abs(np.angle(b["z"][1:] * b["z"][:-1].conj()))
    valid_edges = b["phase_valid"][1:] & b["phase_valid"][:-1]
    resolved_edges = valid_edges & ~b["phase_interval_ambiguous"][1:]
    ambiguous = []
    for i, j in np.argwhere(b["phase_interval_ambiguous"]):
        ambiguous.append({"rank": int(j+1), "group_index": int(b["group_indices"][j]),
                          "time_start": float(b["times"][i-1]), "time_end": float(b["times"][i]),
                          "amplitude_start": float(abs(b["z"][i-1,j])), "amplitude_end": float(abs(b["z"][i,j])),
                          "group_peak_amplitude": float(abs(b["z"][:,j]).max())})
    summary = {"run": coarse_directory.name,
               "coarse_cadence": float(np.median(np.diff(a["times"]))),
               "fine_cadence": float(np.median(np.diff(b["times"]))),
               "coarse_count": len(a["times"]), "fine_count": len(b["times"]),
               "top_group_overlap": len(common),
               "max_abs_temporal_concentration_change": max((abs(r["concentration_difference"]) for r in rows), default=None),
               "max_abs_weighted_cos_change": max((abs(r["cos_difference"]) for r in rows), default=None),
               "min_coarse_concentration": min((r["coarse_concentration"] for r in rows), default=None),
               "min_fine_concentration": min((r["fine_concentration"] for r in rows), default=None),
               "max_wrapped_phase_difference_at_common_times": max(phase_errors, default=None),
               "max_complex_term_difference_at_common_times": max(term_errors, default=None),
               "max_valid_fine_phase_increment_radians": float(np.max(increments[valid_edges], initial=0)),
               "max_unflagged_fine_phase_increment_radians": float(np.max(increments[resolved_edges], initial=0)),
               "ambiguous_fine_phase_intervals": len(ambiguous), "ambiguous_intervals": ambiguous,
               "caveat": "Only the common selected groups and supplied trajectory are compared. High weighted phase concentration does not imply favorable stretching alignment or absence of weak sign reversals."}
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    write_csv(output_directory / "cadence_comparison.csv", rows)
    (output_directory / "cadence_comparison.json").write_text(json.dumps(summary, indent=2)+"\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="*", default=["results/runs"], help="snapshot npz, run directory, or runs root")
    parser.add_argument("--diagnostic-k", type=int, default=3)
    parser.add_argument("--top", type=int, default=20)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--phase-relative-floor", type=float, default=1e-6)
    args = parser.parse_args()
    if args.top < 1 or args.phase_relative_floor < 0:
        parser.error("--top must be positive and --phase-relative-floor nonnegative")
    table = TriadTable(args.diagnostic_k)
    paths = []
    for inp in args.inputs:
        path = Path(inp)
        paths.extend([path] if path.is_file() else sorted(path.rglob("snapshots.npz")))
    if not paths:
        parser.error("no snapshots.npz found")
    root = args.output or Path("results") / f"triads_k{args.diagnostic_k}"
    summaries = []
    for path in sorted(set(paths)):
        metadata, rows, ranks = analyze_run(path, root / path.parent.name, table, args.top, args.phase_relative_floor)
        summary = {"run": path.parent.name, **metadata["run_parameters"],
                   "diagnostic_K": table.K, "max_triad_closure_error": metadata["max_triad_closure_error"],
                   "min_E_low_fraction": metadata["minimum_lowband_E_fraction"],
                   "min_Z_low_fraction": metadata["minimum_lowband_Z_fraction"],
                   "integrated_signed_gap_L1_relative": metadata["integrated_absolute_full_minus_low_over_integrated_absolute_full"],
                   "top_groups_lowband_integrated_weight_fraction": metadata["tracked_lowband_weight_fraction"],
                   "alignment_initial": rows[0]["phase_alignment"], "alignment_final": rows[-1]["phase_alignment"],
                   "S_full_final": rows[-1]["S_full"], "S_low_final": rows[-1]["S_low_triads"]}
        summaries.append(summary)
        print(json.dumps(summary), flush=True)
    write_csv(root / "runs_summary.csv", summaries)


if __name__ == "__main__":
    main()
