"""Synthetic-only tests; no Phase 3 production outcomes are loaded."""
import csv
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from phase2 import predict as phase2
from phase3 import predict


class InitialOnlyRecord(dict):
    def __getitem__(self, key):
        if key in ("Z_final", "S_final", "delta_Z", "target", "split", "index", "case_id"):
            raise AssertionError(f"Feature construction touched non-initial field {key}")
        return super().__getitem__(key)


class LockedTestRecord(dict):
    def __getitem__(self, key):
        if key in predict.TARGET_FIELDS:
            raise AssertionError(f"Fitting touched held-out target {key}")
        return super().__getitem__(key)


def fixture(n=128):
    rng = np.random.default_rng(18091)
    records = []
    for j, profile in enumerate(predict.PROFILES):
        for index in range(n):
            s, q, v, ddot = rng.normal(size=4)
            row = {"case_id": f"{profile}_{index:03d}", "profile": profile, "index": index,
                   "split": "train" if index < 96 else "test", "N": 24, "nu": 1/28, "dt": .005, "T": .5,
                   "E": 1., "Z": 2. + j, "D": 8. + j, "H": 0., "S": s, "Q": q, "V": v, "Ddot": ddot,
                   "Zddot": q + (v-ddot)/28, "Sdot": q + v/28}
            row["delta_Z"] = -.2 + .1*s + .04*q + .01*v + .001*rng.normal()
            row["Z_final"] = row["Z"] + row["delta_Z"]
            row["S_final"] = rng.normal()
            records.append(row)
    return records


def write_frozen_fixture(directory, records):
    directory = Path(directory)
    initial = [{k: v for k, v in row.items() if k not in predict.TARGET_FIELDS} for row in records]
    predict.write_csv(directory / "initial_features.csv", initial)
    predict.write_csv(directory / "features.csv", records)
    (directory / "CONFIG.json").write_text('{"synthetic_fixture":true}\n')
    (directory / "PLAN.md").write_bytes(Path(predict.__file__).with_name("PLAN.md").read_bytes())
    (directory / "PROBE_GATE_CLARIFICATION.md").write_bytes(Path(predict.__file__).with_name("PROBE_GATE_CLARIFICATION.md").read_bytes())
    cases = []
    for row in records:
        path = f"{row['case_id']}.input"
        (directory / path).write_text(row["case_id"])
        cases.append({"case_id": row["case_id"], "profile": row["profile"], "index": row["index"],
                      "input_path": path, "input_sha256": predict.sha256(directory / path)})
    manifest = {"plan_sha256": predict.PLAN_SHA256, "probe_gate_clarification_sha256": predict.CLARIFICATION_SHA256,
                "config_sha256": predict.sha256(directory / "CONFIG.json"),
                "count": 256, "prepared_before_integration": True,
                "initial_features_sha256": predict.sha256(directory / "initial_features.csv"), "cases": cases}
    predict.write_json(directory / "input_manifest.json", manifest)
    comparisons = [{"branch": branch, "case_id": f"{profile}_{i:03d}", "delta_Z_difference": float((i+1)*1e-9)}
                   for branch in ("probe_n32", "probe_dt_half") for profile in predict.PROFILES for i in (0, 1, 32, 33)]
    predict.write_json(directory / "convergence.json", {"comparisons": comparisons})
    return directory / "features.csv"


class PredictionTests(unittest.TestCase):
    def test_audited_phase2_functions_reused_unchanged(self):
        for name in ("Standardizer", "RidgeModel", "fit_ridge", "choose_alpha", "paired_stratified_bootstrap"):
            self.assertIs(getattr(predict, name), getattr(phase2, name))
        self.assertEqual(predict.ALPHAS, (1e-4, .01, .1, 1., 10., 100.))

    def test_disjoint_balanced_nested_splits(self):
        records = fixture()
        train, test, folds = predict.validate_records(records)
        self.assertEqual(train.sum(), 192)
        self.assertEqual(test.sum(), 64)
        self.assertFalse(np.any(train & test))
        previous = np.zeros(len(records), bool)
        labels = np.array([r["profile"] for r in records])
        for n, mask in predict.learning_curve_masks(records).items():
            self.assertEqual(mask.sum(), n)
            self.assertTrue(np.all(~previous | mask))
            self.assertFalse(np.any(mask & test))
            for name in predict.PROFILES:
                for fold in range(4):
                    self.assertEqual(np.sum(mask & (labels == name) & (folds == fold)), n // 8)
            previous = mask

    def test_initial_only_allowlist_and_future_noninterference(self):
        rows = fixture(8)
        initial = predict.build_features(rows)
        altered = predict.build_features([InitialOnlyRecord(r, delta_Z=np.nan, Z_final=1e100, S_final=-1e99) for r in rows])
        for name in predict.MODEL_NAMES:
            np.testing.assert_array_equal(initial.designs[name], altered.designs[name])
        self.assertEqual(initial.designs["baseline"].shape[1], 6)
        self.assertEqual(initial.designs["viscous"].shape[1], 8)
        self.assertEqual(initial.designs["quartic"].shape[1], 9)
        self.assertEqual(initial.designs["curvature"].shape[1], 9)

    def test_exact_feature_units_and_equal_information(self):
        rows = fixture(8)
        features = predict.build_features(rows)
        first = rows[0]
        np.testing.assert_allclose(features.designs["baseline"][0], [first["S"], first["S"]**2, first["S"]**3, 0., 0., 0.])
        np.testing.assert_allclose(features.designs["viscous"][0, -2:], [first["nu"]*first["V"], first["nu"]*first["Ddot"]])
        q, c = features.designs["quartic"], features.designs["curvature"]
        np.testing.assert_allclose(c[:, -1], q[:, -1] + q[:, -3] - q[:, -2], rtol=1e-14, atol=1e-14)
        transform = np.eye(9)
        transform[6,8], transform[7,8] = 1, -1
        np.testing.assert_allclose(q @ transform, c, rtol=1e-14, atol=1e-14)
        self.assertEqual(np.linalg.matrix_rank(q), np.linalg.matrix_rank(c))

    def test_fitting_never_reads_test_targets(self):
        rows = fixture()
        guarded = [LockedTestRecord(row) if row["index"] >= 96 else row for row in rows]
        _, _, folds = predict.validate_records(guarded)
        features = predict.build_features(guarded)
        models, tuning, predictions = predict.fit_learning_curves(guarded, features, folds)
        self.assertEqual(len(models), 3)
        for n in predict.TRAINING_SIZES:
            for name in predict.MODEL_NAMES:
                self.assertEqual(models[n][name].n_fit, n)
                self.assertEqual(predictions[n][name].shape, (256,))
                self.assertEqual(len(tuning[n][name]["cv_grid"]), 6)

    def test_test_target_changes_do_not_change_fits_or_predictions(self):
        rows = fixture()
        _, _, folds = predict.validate_records(rows)
        features = predict.build_features(rows)
        models, tuning, predictions = predict.fit_learning_curves(rows, features, folds)
        altered = [dict(r) for r in rows]
        for row in altered:
            if row["index"] >= 96:
                row.update(Z_final=np.nan, delta_Z=np.nan, S_final=1e100)
        other_models, other_tuning, other_predictions = predict.fit_learning_curves(altered, predict.build_features(altered), folds)
        self.assertEqual(tuning, other_tuning)
        for n in predict.TRAINING_SIZES:
            for name in predict.MODEL_NAMES:
                np.testing.assert_array_equal(predictions[n][name], other_predictions[n][name])
                np.testing.assert_array_equal(models[n][name].coef, other_models[n][name].coef)

    def test_fit_local_standardization_in_cv(self):
        rows = fixture(8)
        features = predict.build_features(rows)
        x, p = features.designs["quartic"], features.intercepts
        y = np.sin(np.arange(len(x)))
        folds = np.tile(np.arange(8)%4, 2)
        seen = []
        original = predict.Standardizer.fit
        def observe(values):
            seen.append(values.copy())
            return original(values)
        with patch.object(predict.Standardizer, "fit", side_effect=observe):
            predict.choose_alpha(x,y,p,folds,alphas=(.1,1.))
        self.assertEqual(len(seen), 8)
        for i, values in enumerate(seen):
            np.testing.assert_array_equal(values, x[folds != i%4])

    def test_ridge_constant_and_rank_deficient(self):
        p = np.repeat(np.eye(2), 8, axis=0)
        x0 = np.arange(16.)
        x = np.column_stack((np.ones(16), x0, 2*x0, np.zeros(16)))
        y = 2*x0 + p @ np.array([100., -200.])
        model = predict.fit_ridge(x,y,p,.0001)
        self.assertEqual(model.centered_design_rank, 1)
        self.assertTrue(np.isfinite(model.predict(x,p)).all())
        self.assertLess(np.max(abs(model.predict(x,p)-y)), .001)

    def test_ridge_matches_independent_augmented_least_squares(self):
        features = predict.build_features(fixture(8))
        x,p = features.designs["quartic"], features.intercepts
        y = np.cos(np.arange(len(x)))
        model = predict.fit_ridge(x,y,p,.1)
        xs = model.scaler.transform(x)
        a = np.block([[p,xs],[np.zeros((x.shape[1],p.shape[1])), np.sqrt(.1)*np.eye(x.shape[1])]])
        b = np.concatenate((y, np.zeros(x.shape[1])))
        beta = np.linalg.lstsq(a,b,rcond=None)[0]
        np.testing.assert_allclose(model.predict(x,p), np.column_stack((p,xs))@beta, rtol=1e-10, atol=1e-10)

    def test_cv_ties_choose_first_alpha_deterministically(self):
        features = predict.build_features(fixture(8))
        y = np.zeros(16)
        result = predict.choose_alpha(features.designs["quartic"],y,features.intercepts,np.tile(np.arange(8)%4,2))
        self.assertEqual(result[0], predict.ALPHAS[0])
        self.assertEqual(result, predict.choose_alpha(features.designs["quartic"],y,features.intercepts,np.tile(np.arange(8)%4,2)))

    def test_stratified_paired_bootstrap(self):
        y, base, added = np.zeros(8), np.arange(8.), np.ones(8)
        labels = np.array(["flat"]*4 + ["kminus2"]*4)
        result, samples = predict.paired_stratified_bootstrap(y,base,added,labels,20,predict.BOOTSTRAP_SEED)
        rng = np.random.default_rng(predict.BOOTSTRAP_SEED)
        a = rng.choice(np.arange(4), size=(20,4), replace=True)
        b = rng.choice(np.arange(4,8), size=(20,4), replace=True)
        delta = base**2-added**2
        np.testing.assert_array_equal(samples, (delta[a].sum(axis=1)+delta[b].sum(axis=1))/8)
        self.assertEqual(result["seed"], 2026101804)

    def test_invalid_split_identity_and_duplicate_cases_rejected(self):
        for key,value in (("split","test"),("Zddot",1e6),("Sdot",1e6),("T",.6)):
            rows = fixture()
            rows[0][key] = value
            with self.assertRaises(ValueError):
                predict.validate_records(rows)
        rows = fixture()
        rows[1]["case_id"] = rows[0]["case_id"]
        with self.assertRaises(ValueError):
            predict.validate_records(rows)

    def test_numerical_sensitivity_bound_for_frozen_predictions(self):
        y = np.array([1.,2.,3.,4.])
        base, added = y+.2, y-.1
        test = np.ones(4,dtype=bool)
        result = predict.numerical_sensitivity(None,{"viscous":base,"quartic":added},test)
        epsilon = .01
        changes = np.array([.01,-.01,.005,-.002])
        gain = lambda values: np.mean((values-base)**2-(values-added)**2)
        self.assertLessEqual(abs(gain(y+changes)-gain(y)), result["uniform_target_error_sensitivity_factor"]*epsilon)
        self.assertFalse(result["certified_continuum_or_uniform_target_bound"])

    def test_frozen_plan_hash(self):
        self.assertEqual(predict.sha256(Path(predict.__file__).with_name("PLAN.md")), predict.PLAN_SHA256)
        self.assertEqual(predict.sha256(Path(predict.__file__).with_name("PROBE_GATE_CLARIFICATION.md")), predict.CLARIFICATION_SHA256)

    def test_reader_defers_target_parsing(self):
        with tempfile.TemporaryDirectory() as temp:
            rows = fixture()
            for row in rows:
                if row["index"] >= 96:
                    row.update(Z_final="locked-unparsed", delta_Z="locked-unparsed", S_final="locked-unparsed")
            path = Path(temp)/"rows.csv"
            predict.write_csv(path, rows)
            loaded = predict.read_records(path)
            self.assertEqual(loaded[96]["Z_final"], "locked-unparsed")
            train, _, folds = predict.validate_records(loaded)
            y = predict.extract_targets(loaded,train)
            self.assertTrue(np.isfinite(y).all())
            predict.fit_learning_curves(loaded,predict.build_features(loaded),folds)

    def test_manifest_rejects_changed_initial_fields_and_input(self):
        rows = fixture()
        with tempfile.TemporaryDirectory() as temp:
            source = write_frozen_fixture(temp, rows)
            loaded = predict.read_records(source)
            predict.verify_frozen_inputs(source, loaded)
            loaded[0]["Q"] += 1.
            with self.assertRaises(ValueError):
                predict.verify_frozen_inputs(source, loaded)
            (Path(temp)/"flat_000.input").write_text("changed")
            with self.assertRaises(ValueError):
                predict.verify_frozen_inputs(source, predict.read_records(source))

    def test_all_fits_saved_before_heldout_extraction_and_complete_output(self):
        rows = fixture()
        with tempfile.TemporaryDirectory() as temp:
            source = write_frozen_fixture(temp, rows)
            output = Path(temp)/"out"
            original = predict.extract_targets
            seen = []
            def observed(records, mask):
                if any(use and row["index"] >= 96 for row, use in zip(records, mask)):
                    self.assertTrue((output/"fit_lock.json").is_file())
                    self.assertEqual(len(json.loads((output/"models.json").read_text())), 3)
                    seen.append("heldout")
                return original(records, mask)
            with patch.object(predict,"extract_targets",side_effect=observed):
                result = predict.run_analysis(source,output,n_bootstrap=20)
            self.assertEqual(seen,["heldout"])
            self.assertEqual(result["counts"]["test"],64)
            self.assertEqual(result["primary_comparison"]["paired_bootstrap"]["n_resamples"],20)
            self.assertEqual(result["numerical_sensitivity"]["probe_status"],"available")
            self.assertTrue(result["practical_gate"]["passed"])
            self.assertEqual(json.loads((output/"summary.json").read_text()),result)
            with (output/"predictions.csv").open() as handle:
                predicted = list(csv.DictReader(handle))
            self.assertEqual(len(predicted),768)
            self.assertEqual(sum(row["split"]=="test" for row in predicted),192)
            self.assertTrue((output/"PREDICTION_REPORT.md").is_file())
            with self.assertRaises(FileExistsError):
                predict.run_analysis(source,output,n_bootstrap=20)


if __name__ == "__main__":
    unittest.main()
