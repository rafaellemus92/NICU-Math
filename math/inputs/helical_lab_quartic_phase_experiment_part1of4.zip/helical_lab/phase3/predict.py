"""Frozen Phase 3 prediction protocol; no Phase 2 code or results are modified.

Run from the lab root with ``python -m phase3.predict`` after the initial-input
manifest, protocol, production trajectories, and numerical probes are complete.
The audited Phase 2 ridge implementation is imported unchanged. All twelve
learning-curve fits are locked before held-out targets are extracted.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import time
from typing import Sequence

import numpy as np

from phase2.predict import (ALPHAS, Standardizer, RidgeModel, fit_ridge,
                            choose_alpha, grouped_metrics, improvements,
                            paired_stratified_bootstrap, write_csv)

ROOT = Path(__file__).resolve().parents[1]
PLAN_SHA256 = "946befe5a61314194c1b38ab0f81d9542b3d0d47b16ef08b3244047b4f16db9c"
CLARIFICATION_SHA256 = "539b4fcc730692e8c32ae6f84f30092f14965239fd9055c310a3d4f6242e360f"
BOOTSTRAP_SEED = 2026101804
TRAINING_SIZES = (64, 128, 192)
PROFILES = ("flat", "kminus2")
MODEL_NAMES = ("baseline", "viscous", "quartic", "curvature")
INITIAL_FEATURE_FIELDS = ("S", "Q", "V", "Ddot", "Zddot", "nu")
TARGET_FIELDS = frozenset(("Z_final", "S_final", "delta_Z", "target"))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


@dataclass
class Features:
    profiles: tuple[str, ...]
    intercepts: np.ndarray
    designs: dict[str, np.ndarray]
    names: dict[str, tuple[str, ...]]


def build_features(records: Sequence[dict], profiles=PROFILES) -> Features:
    """Explicit initial-only allowlist; never read identity, split, or targets."""
    if not records:
        raise ValueError("No records")
    profiles = tuple(profiles)
    if len(set(profiles)) != len(profiles):
        raise ValueError("Duplicated profiles")
    p = np.array([[float(r["profile"] == name) for name in profiles] for r in records])
    if not np.all(p.sum(axis=1) == 1):
        raise ValueError("Unknown profile")
    values = {name: np.array([float(r[name]) for r in records]) for name in INITIAL_FEATURE_FIELDS}
    s = values["S"]
    baseline = np.column_stack([p[:, j] * s**d for j in range(len(profiles)) for d in (1, 2, 3)])
    viscous = np.column_stack((baseline, values["nu"] * values["V"], values["nu"] * values["Ddot"]))
    designs = {"baseline": baseline, "viscous": viscous,
               "quartic": np.column_stack((viscous, values["Q"])),
               "curvature": np.column_stack((viscous, values["Zddot"]))}
    names = {"baseline": tuple(f"profile={name}:S^{d}" for name in profiles for d in (1, 2, 3))}
    names["viscous"] = names["baseline"] + ("nu*V", "nu*Ddot")
    names["quartic"] = names["viscous"] + ("Q",)
    names["curvature"] = names["viscous"] + ("Zddot",)
    if any(not np.isfinite(x).all() for x in designs.values()):
        raise ValueError("Nonfinite initial features")
    return Features(profiles, p, designs, names)


def fixed_split(records):
    identifiers = [(r["profile"], int(r["index"])) for r in records]
    if len(set(identifiers)) != len(identifiers) or any(i < 0 for _, i in identifiers):
        raise ValueError("Case identifiers must be unique with nonnegative indices")
    train = np.array([i < 96 for _, i in identifiers], dtype=bool)
    test = ~train
    folds = np.array([i % 4 for _, i in identifiers], dtype=int)
    for r, is_train in zip(records, train):
        expected = "train" if is_train else "test"
        if "split" in r and r["split"] != expected:
            raise ValueError(f"Stored split disagrees for {r['profile']}/{r['index']}")
    if not train.any() or not test.any():
        raise ValueError("Both training and held-out cases required")
    return train, test, folds


def learning_curve_masks(records):
    indices = np.array([int(r["index"]) for r in records])
    return {n: indices < n // len(PROFILES) for n in TRAINING_SIZES}


def read_records(path):
    with Path(path).open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        for key, value in tuple(row.items()):
            # Preserve raw target text until the explicitly selected extraction.
            # Initial-data validation and all training fits never parse test targets.
            if key not in ("case_id", "profile", "split") and key not in TARGET_FIELDS:
                row[key] = float(value)
        value = row["index"]
        if value != int(value):
            raise ValueError("Noninteger case index")
        row["index"] = int(value)
    return rows


def validate_records(records):
    """Check design/initial identities without extracting outcomes."""
    if tuple(sorted({r["profile"] for r in records})) != PROFILES:
        raise ValueError(f"Expected profiles {PROFILES}")
    if len({r["case_id"] for r in records}) != len(records):
        raise ValueError("Duplicate case_id")
    for profile in PROFILES:
        subset = [r for r in records if r["profile"] == profile]
        if sorted(r["index"] for r in subset) != list(range(128)):
            raise ValueError(f"Expected indices 0..127 exactly once for {profile}")
        for field in ("E", "Z", "D", "H"):
            values = np.array([r[field] for r in subset])
            if not np.isfinite(values).all() or not np.allclose(values, values[0], rtol=1e-10, atol=1e-10):
                raise ValueError(f"{field} must be finite and constant within {profile}")
    for row in records:
        for field, value in (("N", 24), ("nu", 1/28), ("dt", .005), ("T", .5), ("E", 1.), ("H", 0.)):
            if not np.isclose(row[field], value, rtol=1e-10, atol=1e-10):
                raise ValueError(f"Unexpected {field} for {row['case_id']}")
        expected = row["Q"] + row["nu"] * row["V"] - row["nu"] * row["Ddot"]
        if not np.isclose(row["Zddot"], expected, rtol=1e-10, atol=1e-10):
            raise ValueError(f"Initial Zddot identity failed for {row['case_id']}")
        if "Sdot" in row and not np.isclose(row["Sdot"], row["Q"] + row["nu"] * row["V"], rtol=1e-10, atol=1e-10):
            raise ValueError(f"Initial Sdot identity failed for {row['case_id']}")
    train, test, folds = fixed_split(records)
    masks = learning_curve_masks(records)
    for n, mask in masks.items():
        if mask.sum() != n or np.any(mask & test):
            raise ValueError("Learning-curve split mismatch")
        for profile in PROFILES:
            group = np.array([r["profile"] == profile for r in records])
            for fold in range(4):
                if np.count_nonzero(mask & group & (folds == fold)) != n // 8:
                    raise ValueError("Learning-curve fold imbalance")
    return train, test, folds


def verify_frozen_inputs(input_path, records, plan_path=None):
    """Verify the prospective plan and all initial data before model fitting."""
    input_path = Path(input_path)
    directory = input_path.parent
    plan_path = Path(plan_path) if plan_path is not None else Path(__file__).with_name("PLAN.md")
    if PLAN_SHA256 == "PENDING_PROTOCOL_FREEZE" or sha256(plan_path) != PLAN_SHA256:
        raise ValueError("Prospective PLAN.md is not frozen or changed")
    clarification_path = plan_path.with_name("PROBE_GATE_CLARIFICATION.md")
    if sha256(clarification_path) != CLARIFICATION_SHA256:
        raise ValueError("Prospective numerical-gate clarification changed")
    manifest_path = directory / "input_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest["plan_sha256"] != PLAN_SHA256 or manifest.get("count") != 256 or manifest.get("prepared_before_integration") is not True:
        raise ValueError("Initial-input manifest does not verify frozen prospective preparation")
    if manifest.get("probe_gate_clarification_sha256") != CLARIFICATION_SHA256:
        raise ValueError("Initial manifest does not verify prospective gate clarification")
    initial_path = directory / "initial_features.csv"
    if sha256(initial_path) != manifest["initial_features_sha256"]:
        raise ValueError("Initial features changed after freeze")
    initial_rows = read_records(initial_path)
    if any(TARGET_FIELDS.intersection(row) for row in initial_rows):
        raise ValueError("Initial feature freeze contains future outcomes")
    initial_map = {r["case_id"]: r for r in initial_rows}
    if len(initial_map) != 256 or set(initial_map) != {r["case_id"] for r in records}:
        raise ValueError("Initial and production case identities differ")
    for row in records:
        initial = initial_map[row["case_id"]]
        for key, value in initial.items():
            if key not in row or row[key] != value:
                raise ValueError(f"Frozen initial field changed: {row['case_id']}:{key}")
    cases = manifest["cases"]
    if len(cases) != 256 or {r["case_id"] for r in cases} != set(initial_map):
        raise ValueError("Manifest case identity mismatch")
    for row in cases:
        expected = initial_map[row["case_id"]]
        if row["profile"] != expected["profile"] or int(row["index"]) != expected["index"]:
            raise ValueError("Manifest profile/index mismatch")
        if sha256(directory / row["input_path"]) != row["input_sha256"]:
            raise ValueError(f"Frozen Fourier input changed: {row['case_id']}")
    config_path = directory / "CONFIG.json"
    if sha256(config_path) != manifest["config_sha256"]:
        raise ValueError("Configuration changed after input freeze")
    return {"plan_sha256": PLAN_SHA256, "probe_gate_clarification_sha256": CLARIFICATION_SHA256,
            "input_manifest_sha256": sha256(manifest_path),
            "initial_features_sha256": sha256(initial_path), "input_sha256": sha256(input_path),
            "config_sha256": sha256(config_path), "input_manifest": str(manifest_path),
            "plan": str(plan_path), "input": str(input_path)}


def extract_targets(records, mask):
    """Only visit selected rows; fitting calls pass training masks exclusively."""
    selected = [row for row, use in zip(records, mask) if use]
    y = np.array([float(row["Z_final"]) - row["Z"] for row in selected])
    if not np.isfinite(y).all():
        raise ValueError("Nonfinite finite-horizon target")
    for row, value in zip(selected, y):
        if "delta_Z" in row and not np.isclose(float(row["delta_Z"]), value, rtol=1e-11, atol=1e-11):
            raise ValueError("Stored delta_Z disagrees with Z_final minus Z")
    return y


def fit_learning_curves(records, features, folds):
    """Fit all predeclared models without reading any held-out target."""
    models, tuning, predictions = {}, {}, {}
    masks = learning_curve_masks(records)
    for n, mask in masks.items():
        y = extract_targets(records, mask)
        models[n], tuning[n], predictions[n] = {}, {}, {}
        for name in MODEL_NAMES:
            x = features.designs[name]
            alpha, cv = choose_alpha(x[mask], y, features.intercepts[mask], folds[mask])
            model = fit_ridge(x[mask], y, features.intercepts[mask], alpha)
            models[n][name] = model
            tuning[n][name] = {"alpha": alpha, "selected_cv_mse": next(v["mse"] for v in cv if v["alpha"] == alpha),
                               "cv_grid": cv,
                               "constant_training_columns": np.flatnonzero(np.ptp(x[mask], axis=0) == 0).tolist(),
                               "centered_design_rank": model.centered_design_rank,
                               "n_penalized_features": int(x.shape[1])}
            predictions[n][name] = model.predict(x, features.intercepts)
    return models, tuning, predictions


def numerical_sensitivity(convergence_path, primary_predictions, test):
    """Report empirical probe differences separately from bootstrap uncertainty.

    For a genuinely uniform target error bound epsilon and frozen predictions,
    |change in paired MSE gain| <= 2 mean(|p_quartic-p_viscous|) epsilon.
    A finite set of grid/time probes does not prove such a uniform error bound.
    """
    factor = float(2 * np.mean(np.abs(primary_predictions["quartic"][test] - primary_predictions["viscous"][test])))
    result = {"bootstrap_includes_discretization_error": False,
              "uniform_target_error_sensitivity_factor": factor,
              "conditional_bound_formula": "abs(change in viscous-minus-quartic MSE gain) <= 2*mean(abs(pred_quartic-pred_viscous))*epsilon, IF every test target error is bounded by epsilon and predictions are frozen",
              "certified_continuum_or_uniform_target_bound": False,
              "interpretation": "Probe differences are empirical comparisons on predeclared cases, not bounds on all test cases or the continuum. The sensitivity calculation fixes fitted predictions and does not include numerical changes in training targets, features, or refitted coefficients."}
    if convergence_path is None or not Path(convergence_path).is_file():
        result["probe_status"] = "not_available"
        return result
    probe = json.loads(Path(convergence_path).read_text())
    comparisons = probe.get("comparisons", [])
    if not comparisons:
        raise ValueError("Convergence file has no comparisons")
    branches = sorted({r["branch"] for r in comparisons})
    result.update(probe_status="available", convergence_sha256=sha256(convergence_path), convergence_file=str(convergence_path), branches={})
    for branch in branches:
        selected = [r for r in comparisons if r["branch"] == branch]
        values = np.array([r["delta_Z_difference"] for r in selected], dtype=float)
        if not np.isfinite(values).all():
            raise ValueError("Nonfinite numerical probe differences")
        epsilon = float(np.max(np.abs(values)))
        result["branches"][branch] = {"n_probe_cases": len(selected), "max_abs_delta_Z_difference": epsilon,
                                      "rms_delta_Z_difference": float(np.sqrt(np.mean(values**2))),
                                      "empirical_gain_sensitivity_scale": factor * epsilon,
                                      "is_certified_bound": False,
                                      "case_ids": [r["case_id"] for r in selected]}
    return result


def practical_gate(summary):
    """Evaluate the frozen resource-allocation criteria; authorize nothing."""
    primary = summary["learning_curves"]["192"]
    comparison = primary["comparisons"]["viscous_minus_quartic"]
    relative = comparison["pooled"]["relative_mse_improvement"]
    rmse_reduction = comparison["pooled"]["delta_rmse"]
    numerical = summary["numerical_sensitivity"]
    available = numerical["probe_status"] == "available"
    rms = max(value["rms_delta_Z_difference"] for value in numerical["branches"].values()) if available else None
    checks = {"pooled_mse_reduction_at_least_10_percent": relative is not None and relative >= .1,
              "nonnegative_mse_reduction_each_profile": all(comparison[p]["delta_mse"] >= 0 for p in PROFILES),
              "probe_rms_below_10_percent_of_primary_rmse_reduction": rms is not None and rmse_reduction > 0 and rms < .1 * rmse_reduction}
    return {"criteria": checks, "passed": all(checks.values()), "numerical_probes_available": available,
            "primary_relative_mse_reduction": relative, "primary_rmse_reduction": rmse_reduction,
            "maximum_branch_rms_delta_Z_discrepancy": rms,
            "numerical_rms_threshold": .1 * rmse_reduction,
            "interpretation": "Predeclared resource-allocation screen, not a statistical guarantee or authorization for a new cohort or paid compute. The largest branch RMS is used so both numerical comparisons must pass."}


def make_report(summary):
    lines = ["# Phase 3 held-out finite-horizon prediction", "",
             "The prospective protocol and initial inputs were frozen before integration. All twelve learning-curve models were fitted and saved before held-out targets were extracted. The primary target is delta_Z at T=0.5; the exact Sdot identity is not a prediction endpoint.", "",
             "## Models and test protocol", "",
             "M0/baseline: separate unpenalized profile intercepts and profile-specific S,S²,S³. Viscous: M0 plus nu*V and nu*Ddot, with full-NS Ddot. Quartic: viscous plus Q. Curvature: viscous plus Zddot. Euler and second-order Taylor are fixed references.", "",
             "The 64,128,192 training-case sets are nested, balanced across profiles, and share one final 64-case test set. The 192-case viscous-versus-quartic comparison is primary; smaller learning-curve fits and every other comparison are descriptive. There was no test-based model, feature, grid, or stopping choice.", "",
             "Quartic and curvature have exactly the same information and linear span because Zddot=Q+nu*V−nu*Ddot. Standardized ridge is not invariant to this coordinate change: their differences reflect penalty parameterization, not additional physical information. The primary comparison adds one penalized column; it is not an equal-parameter-count comparison.", ""]
    for size, data in summary["learning_curves"].items():
        lines += [f"## Training size {size}", "", "| Model | Group | n | MAE | RMSE | MSE | alpha |", "|---|---|---:|---:|---:|---:|---:|"]
        for name, model in data["models"].items():
            for group, value in model["test_metrics"].items():
                alpha = f"{model['alpha']:.6g}" if "alpha" in model else "fixed"
                lines.append(f"| {name} | {group} | {value['n']} | {value['mae']:.9g} | {value['rmse']:.9g} | {value['mse']:.9g} | {alpha} |")
        lines += ["", "Training-only selected CV MSE and centered design rank:", ""]
        for name in MODEL_NAMES:
            model = data["models"][name]
            lines.append(f"- {name}: CV MSE {model['selected_cv_mse']:.9g}; rank {model['centered_design_rank']}/{model['n_penalized_features']}; constant columns {model['constant_training_columns']}.")
        lines += ["", "Viscous-minus-quartic relative held-out improvements (positive is better):", ""]
        for group, value in data["comparisons"]["viscous_minus_quartic"].items():
            formatted = "; ".join(f"{metric.upper()} {100 * value[f'relative_{metric}_improvement']:.4f}%" if value[f"relative_{metric}_improvement"] is not None else f"{metric.upper()} undefined (zero baseline)" for metric in ("mae", "rmse", "mse"))
            lines.append(f"- {group}: {formatted}.")
        lines.append("")
    boot = summary["primary_comparison"]["paired_bootstrap"]
    low, high = boot["percentile_95_ci"]
    delta = boot["delta_mse_baseline_minus_augmented"]
    lines += ["## Primary paired uncertainty", "",
              f"Viscous-minus-quartic test MSE: {delta:.9g}; profile-stratified paired percentile 95% interval [{low:.9g}, {high:.9g}], from {boot['n_resamples']} bootstrap resamples. Fraction above zero: {boot['fraction_bootstrap_delta_above_zero']:.4f}; this is not a p-value.", "",
              "The interval resamples independent held-out phase realizations conditional on the fitted models and this synthetic distribution. It omits training-set variability, numerical discretization uncertainty, and distribution shift. No additional model comparison has a confirmatory interval.", "",
              "## Numerical checks and limits", ""]
    numerical = summary["numerical_sensitivity"]
    if numerical["probe_status"] == "available":
        for branch, value in numerical["branches"].items():
            lines.append(f"- {branch}: {value['n_probe_cases']} cases; maximum absolute delta_Z difference {value['max_abs_delta_Z_difference']:.9g}; corresponding empirical frozen-prediction gain-sensitivity scale {value['empirical_gain_sensitivity_scale']:.9g}.")
    else:
        lines.append("Numerical probe results were unavailable at prediction-report creation; no discretization accuracy claim is made.")
    gate = summary["practical_gate"]
    lines += ["", numerical["conditional_bound_formula"] + ".", "", numerical["interpretation"], "",
              "## Predeclared practical gate", "",
              f"Gate {'passed' if gate['passed'] else 'did not pass'}; numerical probes {'available' if gate['numerical_probes_available'] else 'not available'}. This does not authorize any replication or paid compute.", ""]
    lines += [f"- {name}: {value}." for name, value in gate["criteria"].items()]
    lines += ["", gate["interpretation"], "",
              "## Reproducibility and conclusion", "",
              "The quartic model " + ("reduces" if delta > 0 else "does not reduce") + " primary pooled held-out MSE. " + ("The conditional paired interval lies above zero." if low > 0 else "The conditional paired interval lies below zero." if high < 0 else "The conditional paired interval includes zero."), "",
              "This is a finite two-profile random-phase experiment at one horizon and viscosity. A gain does not establish an information-theoretically minimal closure, universal predictive sufficiency, coercivity, a priori control, or Navier–Stokes global regularity. The total scalar Q is tested here; no quartet-resolved decomposition is tested.", "",
              "Saved artifacts: all case-level targets/predictions at every training size; fitted parameters and train-only standardizers; every alpha/fold CV score; the primary bootstrap draws; a pre-evaluation fit-lock manifest; input/code hashes and exact identity/rank diagnostics. Phase 2 is imported unchanged.", "",
              f"Protocol SHA256: {summary['provenance']['plan_sha256']}",
              f"Initial manifest SHA256: {summary['provenance']['input_manifest_sha256']}",
              f"Production input SHA256: {summary['provenance']['input_sha256']}", ""]
    return "\n".join(lines)


def run_analysis(input_path, output_dir, *, convergence_path=None, n_bootstrap=2000, plan_path=None):
    started = time.perf_counter()
    started_utc = datetime.now(timezone.utc).isoformat()
    input_path, output_dir = Path(input_path), Path(output_dir)
    if (output_dir / "summary.json").exists() or (output_dir / "fit_lock.json").exists():
        raise FileExistsError("Prediction outputs already exist; preserve the locked evaluation and use a separate directory for a labeled exact reproduction")
    records = read_records(input_path)
    train, test, folds = validate_records(records)
    provenance = verify_frozen_inputs(input_path, records, plan_path)
    features = build_features(records)
    labels = np.array([r["profile"] for r in records])
    provenance.update(predict_py_sha256=sha256(__file__), phase2_predict_py_sha256=sha256(ROOT / "phase2/predict.py"),
                      numpy_version=np.__version__, python_version=platform.python_version(), machine=platform.platform(),
                      alphas=list(ALPHAS), training_sizes=list(TRAINING_SIZES),
                      cv="Four profile-stratified folds, index modulo four; fit-local standardization", test_tuning=False,
                      split="Within each profile indices 0..95 train, 96..127 held out; nested fits use indices 0..31,0..63,0..95")
    models, tuning, predictions = fit_learning_curves(records, features, folds)
    output_dir.mkdir(parents=True, exist_ok=True)
    serialized = {str(n): {name: model.to_dict(features.names[name], features.profiles) for name, model in group.items()} for n, group in models.items()}
    write_json(output_dir / "models.json", serialized)
    write_json(output_dir / "cv_results.json", tuning)
    cv_rows = [{"training_size": n, "model": name, "alpha": cv["alpha"], "pooled_oof_mse": cv["mse"], "fold": fold, "fold_mse": mse}
               for n, group in tuning.items() for name, model in group.items() for cv in model["cv_grid"] for fold, mse in enumerate(cv["fold_mse"])]
    write_csv(output_dir / "cv_scores.csv", cv_rows)
    fit_lock = {"all_predeclared_fits_completed_before_heldout_target_extraction": True,
                "fit_locked_utc": datetime.now(timezone.utc).isoformat(),
                "n_fits": len(TRAINING_SIZES) * len(MODEL_NAMES), "training_sizes": list(TRAINING_SIZES),
                "models_sha256": sha256(output_dir / "models.json"), "cv_results_sha256": sha256(output_dir / "cv_results.json"),
                "provenance": provenance}
    write_json(output_dir / "fit_lock.json", fit_lock)
    # This is the first extraction of any held-out target. No fit/tuning below.
    test_evaluation_started_utc = datetime.now(timezone.utc).isoformat()
    y = extract_targets(records, np.ones(len(records), dtype=bool))
    euler = np.array([r["T"] * (r["S"] - r["nu"] * r["D"]) for r in records])
    taylor2 = euler + np.array([.5 * r["T"]**2 * r["Zddot"] for r in records])
    summary = {"schema_version": 1, "target": "Z(T)-Z(0)", "horizon": .5,
               "counts": {"total": len(records), "train": int(train.sum()), "test": int(test.sum()),
                          "by_profile": {profile: {"total": int(np.sum(labels == profile)), "train": int(np.sum(train & (labels == profile))), "test": int(np.sum(test & (labels == profile)))} for profile in PROFILES}},
               "provenance": provenance, "fit_lock_sha256": sha256(output_dir / "fit_lock.json"),
               "test_evaluation_started_utc": test_evaluation_started_utc, "learning_curves": {},
               "initial_identity_checks": {"max_abs_Zddot_minus_Q_nuV_minus_nuDdot": float(max(abs(r["Zddot"] - r["Q"] - r["nu"]*r["V"] + r["nu"]*r["Ddot"]) for r in records)),
                                           "quartic_curvature_equal_information": True,
                                           "interpretation": "Curvature and quartic designs have the same linear span; standardized ridge penalties can differ under the invertible coordinate change."}}
    prediction_rows = []
    for n, mask in learning_curve_masks(records).items():
        group = {"status": "primary_training_size" if n == 192 else "descriptive_learning_curve", "models": {}, "comparisons": {}}
        for name in MODEL_NAMES:
            group["models"][name] = {**tuning[n][name], "test_metrics": grouped_metrics(y[test], predictions[n][name][test], labels[test]),
                                     "train_metrics_in_sample": grouped_metrics(y[mask], predictions[n][name][mask], labels[mask])}
        for name, pred, formula in (("euler_fixed", euler, "T*(S-nu*D)"), ("taylor2_fixed", taylor2, "T*(S-nu*D)+0.5*T^2*Zddot")):
            group["models"][name] = {"formula": formula, "test_metrics": grouped_metrics(y[test], pred[test], labels[test])}
        for base, added in (("viscous", "quartic"), ("baseline", "viscous"), ("baseline", "quartic"), ("viscous", "curvature"), ("curvature", "quartic")):
            group["comparisons"][f"{base}_minus_{added}"] = improvements(group["models"][base]["test_metrics"], group["models"][added]["test_metrics"])
        summary["learning_curves"][str(n)] = group
        for i, record in enumerate(records):
            prediction_rows.append({"training_size": n, "case_id": record["case_id"], "profile": record["profile"], "index": record["index"],
                                    "split": "train" if train[i] else "test", "used_for_fit": int(mask[i]), "cv_fold": int(folds[i]),
                                    "delta_Z_true": float(y[i]), **{name: float(predictions[n][name][i]) for name in MODEL_NAMES},
                                    "euler_fixed": float(euler[i]), "taylor2_fixed": float(taylor2[i])})
    boot, samples = paired_stratified_bootstrap(y[test], predictions[192]["viscous"][test], predictions[192]["quartic"][test], labels[test], n_bootstrap, BOOTSTRAP_SEED)
    summary["primary_comparison"] = {"training_size": 192, "baseline": "viscous", "augmented": "quartic", "paired_bootstrap": boot,
                                      "interpretation": "Only confirmatory model comparison in this protocol; conditional fitted-model bootstrap, not a p-value or continuum uncertainty interval."}
    convergence_path = convergence_path if convergence_path is not None else input_path.parent / "convergence.json"
    summary["numerical_sensitivity"] = numerical_sensitivity(convergence_path, predictions[192], test)
    summary["practical_gate"] = practical_gate(summary)
    summary["runtime_seconds"] = time.perf_counter() - started
    write_csv(output_dir / "predictions.csv", prediction_rows)
    write_csv(output_dir / "bootstrap.csv", [{"resample": i, "primary_delta_mse_viscous_minus_quartic": float(value)} for i, value in enumerate(samples)])
    write_json(output_dir / "summary.json", summary)
    (output_dir / "PREDICTION_REPORT.md").write_text(make_report(summary))
    write_json(output_dir / "timing.json", {"elapsed_seconds": time.perf_counter() - started,
               "started_utc": started_utc, "completed_utc": datetime.now(timezone.utc).isoformat(),
               "scope": "Prediction input/provenance validation, all twelve cross-validated ridge fits, fixed references, all held-out evaluations, primary paired bootstrap, numerical-probe summary, and prediction artifact writes; excludes trajectory generation and numerical probes themselves."})
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "results/phase3/ensemble/features.csv")
    parser.add_argument("--output", type=Path, default=ROOT / "results/phase3/prediction")
    parser.add_argument("--convergence", type=Path)
    args = parser.parse_args()
    result = run_analysis(args.input, args.output, convergence_path=args.convergence)
    print(json.dumps(result["primary_comparison"], indent=2))
    print(f"Saved complete prospective evaluation to {args.output}")


if __name__ == "__main__":
    main()
