"""Independent phase-3 checks. Run: python phase3/review_phase3.py -v.

The finite Fourier advection, Leray projection, Parseval products, and physical
stretching below do not use production physics helpers. No new held-out target
is read by the feature or synthetic statistical checks. Saved-outcome checks
are gated on a frozen analysis and separately recorded test release.
"""
from __future__ import annotations

import copy
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from phase3 import features

WITNESS_K = ((1, 0, 0), (1, 1, 0), (0, 1, 1), (2, 2, 1))
WITNESS_Q = ((0, 1, -1), (-1, 1, 0), (-1, -1, 1), (-2, 1, 2))


def witness(sign):
    result = {}
    for j, (k, q) in enumerate(zip(WITNESS_K, WITNESS_Q)):
        value = np.asarray(q, complex) * (sign if j == 3 else 1) / 2
        result[k] = value
        result[tuple(-v for v in k)] = value.conj()
    return result


def random_field(seed):
    """Independent sparse transverse field; no production polarization basis."""
    rng = np.random.default_rng(seed)
    modes = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
             (1, 0, 1), (0, 1, 1), (1, -1, 0), (1, 1, 1),
             (2, 1, 0), (2, 0, 1), (0, 2, 1))
    field = {}
    for k in modes:
        kk = np.asarray(k)
        value = rng.normal(size=3) + 1j*rng.normal(size=3)
        value -= kk * np.dot(kk, value) / np.dot(kk, kk)
        field[k], field[tuple(-v for v in k)] = value, value.conj()
    norm = np.sqrt(sum(np.vdot(v, v).real for v in field.values()) / 2)
    return {k: v/norm for k, v in field.items()}


def to_rfft(field, N=24):
    full = np.zeros((3, N, N, N), complex)
    for k, v in field.items():
        full[:, k[0] % N, k[1] % N, k[2] % N] = v
    return full[..., :N//2+1].copy()


def fourier_advect(a, b, project=False):
    """Full finite convolution, optionally -P[(a.grad)b], never truncated."""
    result = {}
    for p, ap in a.items():
        for q, bq in b.items():
            k = tuple(p[j]+q[j] for j in range(3))
            term = 1j * np.dot(ap, q) * bq
            result[k] = result.get(k, np.zeros(3, complex)) + term
    if project:
        for k, v in result.items():
            k2 = sum(t*t for t in k)
            result[k] = -(v - np.asarray(k)*np.dot(k, v)/k2) if k2 else -v
    return {k: v for k, v in result.items() if np.any(v != 0)}


def add_fields(*fields):
    result = {}
    for field in fields:
        for k, v in field.items():
            result[k] = result.get(k, np.zeros(3, complex)) + v
    return result


def laplacian(field):
    return {k: -sum(t*t for t in k)*v for k, v in field.items()}


def curl(field):
    return {k: 1j*np.cross(k, v) for k, v in field.items()}


def inner(a, b):
    value = sum(np.vdot(v, b.get(k, np.zeros(3, complex))) for k, v in a.items())
    if abs(np.imag(value)) > 1e-10:
        raise AssertionError("Real-field Parseval inner product became complex")
    return float(np.real(value))


def fresh_stretching(uh):
    N = uh.shape[1]
    wave = np.fft.fftfreq(N, d=1/N)
    k = np.array(np.meshgrid(wave, wave, np.arange(N//2+1), indexing="ij"))
    gradient = np.array([np.fft.irfftn(1j*k[j]*uh*N**3, s=(N,)*3,
                                      axes=(-3, -2, -1)) for j in range(3)])
    omega = np.array([gradient[1, 2]-gradient[2, 1],
                      gradient[2, 0]-gradient[0, 2],
                      gradient[0, 1]-gradient[1, 0]])
    return float(np.einsum("ixyz,jxyz,jixyz->", omega, omega, gradient) / N**3)


def fresh_directional(uh, vh):
    """Polarization identity for a cubic, not production's three slot sums."""
    h = .125
    return (fresh_stretching(uh+h*vh)-fresh_stretching(uh-h*vh))/(2*h) - h*h*fresh_stretching(vh)


def independent_jet(a, nu):
    nonlinear = fourier_advect(a, a, project=True)
    lap = laplacian(a)
    velocity_t = add_fields(nonlinear, {k: nu*v for k, v in lap.items()})
    velocity_tt = add_fields(fourier_advect(velocity_t, a, project=True),
                            fourier_advect(a, velocity_t, project=True),
                            {k: nu*v for k, v in laplacian(velocity_t).items()})
    u, n, ell = to_rfft(a), to_rfft(nonlinear), to_rfft(lap)
    w = curl(a)
    dn = -2*inner(curl(nonlinear), laplacian(w))
    dl = -2*inner(curl(lap), laplacian(w))
    return dict(Q=fresh_directional(u, n), V=fresh_directional(u, ell),
                Ddot_N=dn, Ddot_L=dl,
                Zddot=inner(curl(velocity_t), curl(velocity_t)) + inner(w, curl(velocity_tt)))


class IndependentQuarticReview(unittest.TestCase):
    def test_centered_derivatives_converge_at_predeclared_increments(self):
        # The final increment is predeclared before any production target.
        steps = (2e-3, 1e-3, 5e-4)
        for seed in (72039, 62811):
            field = random_field(seed)
            uh = to_rfft(field)
            n = to_rfft(fourier_advect(field, field, project=True))
            ell = to_rfft(laplacian(field))
            actual = features.initial_features(uh)
            for key, direction in (("Q", n), ("V", ell)):
                errors = [abs((fresh_stretching(uh+h*direction)-fresh_stretching(uh-h*direction))/(2*h)-actual[key]) for h in steps]
                self.assertLess(errors[1], .27*errors[0])
                self.assertLess(errors[2], .27*errors[1])
                self.assertLess(errors[-1]/abs(actual[key]), 1e-6)
            N = uh.shape[1]
            wave = np.fft.fftfreq(N, d=1/N)
            k = np.array(np.meshgrid(wave, wave, np.arange(N//2+1), indexing="ij"))
            k4 = np.sum(k*k, axis=0)**2
            weight = np.ones(N//2+1); weight[1:-1] = 2
            def dissipation(a):
                return float(np.sum(weight*k4*np.sum(abs(a)**2, axis=0)))
            for key, direction in (("Ddot_N", n), ("Ddot_L", ell)):
                errors = [abs((dissipation(uh+h*direction)-dissipation(uh-h*direction))/(2*h)-actual[key]) for h in steps]
                # D is quadratic: centered derivatives are exact algebraically.
                self.assertLess(max(errors)/abs(actual[key]), 1e-9)
            nu = 1/28
            velocity_t = n+nu*ell
            def zprime(a):
                return fresh_stretching(a)-nu*dissipation(a)
            errors = [abs((zprime(uh+h*velocity_t)-zprime(uh-h*velocity_t))/(2*h)-actual["Zddot"]) for h in steps]
            self.assertLess(errors[-1], .08*errors[0])
            self.assertLess(errors[-1]/abs(actual["Zddot"]), 1e-6)

    def test_full_advective_fourier_jet_matches_production(self):
        for seed in (72039, 62811):
            field = random_field(seed)
            for nu in (0., 1/28, .19):
                expected = independent_jet(field, nu)
                actual = features.initial_features(to_rfft(field), nu)
                for key, value in expected.items():
                    self.assertAlmostEqual(actual[key], value, delta=3e-11, msg=(seed, nu, key))

    def test_nonlinear_support_retains_every_generated_mode(self):
        from solver import NS
        field = random_field(92101)
        nonlinear = fourier_advect(field, field, project=True)
        self.assertLessEqual(max(max(abs(i) for i in k) for k in nonlinear), 4)
        for N in (16, 24, 32):
            solver = NS(N, 0.)
            self.assertGreaterEqual(solver.g.K, 4)
            np.testing.assert_allclose(solver.nonlin(to_rfft(field, N)),
                                       to_rfft(nonlinear, N), atol=7e-16, rtol=0)
        # N=12 would truncate generated K=4 modes, even though cubic input fits.
        with self.assertRaises(ValueError):
            features.initial_features(to_rfft(field, 12))

    def test_exact_literal_witness_same_grid_not_only_solver_derivative(self):
        values = []
        full_support = set(WITNESS_K) | {tuple(-x for x in k) for k in WITNESS_K}
        self.assertFalse(any(tuple(-x-y for x, y in zip(p, q)) in full_support
                             for p in full_support for q in full_support))
        for sign, qvalue in ((1, Fraction(1207, 28)), (-1, Fraction(5035, 84))):
            field = witness(sign)
            np.testing.assert_array_equal(abs(to_rfft(field))**2, abs(to_rfft(witness(-sign)))**2)
            self.assertAlmostEqual(fresh_stretching(to_rfft(field)), 0., delta=2e-12)
            for N in (16, 24, 32):
                for nu in (0., 1/28, .2):
                    actual = features.initial_features(to_rfft(field, N), nu)
                    self.assertAlmostEqual(actual["Q"], float(qvalue), delta=3e-11)
                    self.assertAlmostEqual(actual["V"], 0., delta=3e-11)
                    self.assertAlmostEqual(actual["Ddot_N"], 0., delta=3e-11)
                    self.assertAlmostEqual(actual["Ddot_L"], -6603., delta=3e-11)
                    self.assertAlmostEqual(actual["Zddot"], float(qvalue)+6603*nu**2, delta=3e-11)
            values.append(features.initial_features(to_rfft(field))["Q"])
        self.assertAlmostEqual(values[0]-values[1], -101/6, delta=3e-11)

    def test_quartic_cubic_and_quadratic_homogeneity_and_translation(self):
        field = random_field(50103)
        uh = to_rfft(field)
        base = features.initial_features(uh)
        for scale in (-1.7, -.5, .5, 1.7):
            actual = features.initial_features(scale*uh)
            for key, degree in (("Q", 4), ("V", 3), ("Ddot_N", 3), ("Ddot_L", 2)):
                self.assertAlmostEqual(actual[key], scale**degree*base[key], delta=5e-11)
        shift = np.array([.193, -.728, .529])
        translated = {k: v*np.exp(1j*np.dot(k, shift)) for k, v in field.items()}
        other = features.initial_features(to_rfft(translated))
        for key in base:
            self.assertAlmostEqual(base[key], other[key], delta=3e-11, msg=key)

    def test_zddot_is_exact_linear_reparameterization_given_viscous_features(self):
        rows = [features.initial_features(to_rfft(random_field(seed))) for seed in range(10, 30)]
        nu = 1/28
        q = np.array([r["Q"] for r in rows])
        v = nu*np.array([r["V"] for r in rows])
        d = nu*np.array([r["Ddot"] for r in rows])
        z = np.array([r["Zddot"] for r in rows])
        np.testing.assert_allclose(z, q+v-d, atol=3e-15, rtol=0)
        self.assertEqual(np.linalg.matrix_rank(np.column_stack((q, v, d, z))),
                         np.linalg.matrix_rank(np.column_stack((q, v, d))))


def independent_ridge_fit(x, y, p, alpha, evaluation_x=None, evaluation_p=None):
    """Augmented least squares, independent of production normal equations."""
    mean, scale = x.mean(axis=0), x.std(axis=0)
    scale[scale == 0] = 1
    z = (x-mean)/scale
    design = np.column_stack((p, z))
    penalty = np.column_stack((np.zeros((x.shape[1], p.shape[1])),
                               np.sqrt(alpha)*np.eye(x.shape[1])))
    beta = np.linalg.lstsq(np.vstack((design, penalty)),
                           np.concatenate((y, np.zeros(x.shape[1]))), rcond=None)[0]
    if evaluation_x is None:
        evaluation_x, evaluation_p = x, p
    return np.column_stack((evaluation_p, (evaluation_x-mean)/scale)) @ beta


def synthetic_records():
    rng = np.random.default_rng(19047)
    records = []
    for p, profile in enumerate(("flat", "kminus2")):
        for index in range(128):
            s, q, v, d = rng.normal(size=4)
            z, nu = 3.+p, 1/28
            target = .3*s+.02*q+.1*rng.normal()+p
            records.append(dict(case_id=f"{profile}_{index:03d}", profile=profile,
                                index=index, split="train" if index < 96 else "test",
                                E=1., Z=z, D=12.+p, H=0., N=24, nu=nu, dt=.005, T=.5,
                                S=s, Q=q, V=v, Ddot=d, Zddot=q+nu*v-nu*d,
                                Z_final=z+target, delta_Z=target))
    return records


class IndependentPredictionReview(unittest.TestCase):
    def test_nested_balanced_masks_and_initial_only_allowlist(self):
        from phase3 import predict
        records = synthetic_records()
        train, test, folds = predict.validate_records(records)
        self.assertEqual((train.sum(), test.sum()), (192, 64))
        self.assertFalse(np.any(train & test))
        masks = predict.learning_curve_masks(records)
        self.assertFalse(np.any(masks[64] & ~masks[128]))
        self.assertFalse(np.any(masks[128] & ~masks[192]))
        for n, mask in masks.items():
            self.assertEqual(mask.sum(), n)
            self.assertFalse(np.any(mask & test))
            for profile in predict.PROFILES:
                group = np.array([r["profile"] == profile for r in records])
                for fold in range(4):
                    self.assertEqual(np.sum(mask & group & (folds == fold)), n//8)
        before = predict.build_features(records)
        corrupted = copy.deepcopy(records)
        for r in corrupted:
            r.update(Z_final=float("nan"), delta_Z=float("inf"), S_final=-1e100,
                     future_scalar=1e99, nplus0=1e50, nhigh1=-1e50)
        after = predict.build_features(corrupted)
        self.assertEqual({k: x.shape[1] for k, x in before.designs.items()},
                         dict(baseline=6, viscous=8, quartic=9, curvature=9))
        for name in before.designs:
            np.testing.assert_array_equal(before.designs[name], after.designs[name])
        np.testing.assert_array_equal(before.intercepts, after.intercepts)

    def test_all_twelve_fits_ignore_test_targets_and_match_independent_cv(self):
        from phase3 import predict
        class LockedRow(dict):
            def __getitem__(self, key):
                if key in ("Z_final", "delta_Z", "S_final", "target"):
                    raise AssertionError("Locked held-out target was accessed during fitting")
                return super().__getitem__(key)
        rows = synthetic_records()
        protected = [LockedRow(r) if r["index"] >= 96 else r for r in rows]
        _, _, folds = predict.validate_records(protected)
        design = predict.build_features(protected)
        models, tuning, predictions = predict.fit_learning_curves(protected, design, folds)
        for n, mask in predict.learning_curve_masks(rows).items():
            y = np.array([r["Z_final"]-r["Z"] for r, use in zip(rows, mask) if use])
            p = design.intercepts[mask]
            f = folds[mask]
            for name, x_all in design.designs.items():
                x = x_all[mask]
                expected_scores = []
                for alpha in (1e-4, .01, .1, 1., 10., 100.):
                    oof = np.zeros(len(y))
                    for fold in range(4):
                        valid = f == fold
                        oof[valid] = independent_ridge_fit(x[~valid], y[~valid], p[~valid], alpha, x[valid], p[valid])
                    expected_scores.append(float(np.mean((oof-y)**2)))
                np.testing.assert_allclose(expected_scores, [r["mse"] for r in tuning[n][name]["cv_grid"]], atol=2e-12, rtol=0)
                alpha = (1e-4, .01, .1, 1., 10., 100.)[int(np.argmin(expected_scores))]
                self.assertEqual(models[n][name].alpha, alpha)
                expected = independent_ridge_fit(x, y, p, alpha, x_all, design.intercepts)
                np.testing.assert_allclose(expected, predictions[n][name], atol=2e-12, rtol=0)
                np.testing.assert_array_equal(models[n][name].scaler.mean, x.mean(axis=0))
                np.testing.assert_array_equal(models[n][name].scaler.scale, x.std(axis=0))

    def test_ridge_with_exact_dependencies_and_constant_columns(self):
        from phase3 import predict
        rng = np.random.default_rng(7103)
        x = rng.normal(size=(64, 9)); x[:, 5] = 4.; x[:, 6] = 0.
        x[:, 7] = x[:, 0]+x[:, 1]; x[:, 8] = x[:, 0]
        y = rng.normal(size=64)
        p = np.repeat(np.eye(2), 32, axis=0)
        for alpha in (1e-4, .01, .1, 1., 10., 100.):
            model = predict.fit_ridge(x, y, p, alpha)
            np.testing.assert_allclose(model.predict(x, p), independent_ridge_fit(x, y, p, alpha), atol=3e-11, rtol=0)
            self.assertEqual(model.scaler.scale[5], 1.)
            self.assertEqual(model.scaler.scale[6], 1.)
            self.assertLess(model.centered_design_rank, x.shape[1])

    def test_bootstrap_pairs_errors_and_keeps_profile_sizes(self):
        from phase3 import predict
        y = np.arange(64.)
        a, b = y+np.linspace(-2, 3, 64), y+np.linspace(1, -1, 64)
        labels = np.array(["flat"]*32+["kminus2"]*32)
        actual, samples = predict.paired_stratified_bootstrap(y, a, b, labels, 2000, 2026101804)
        rng = np.random.default_rng(2026101804)
        first = rng.integers(0, 32, size=(2000, 32))
        second = rng.integers(32, 64, size=(2000, 32))
        delta = (y-a)**2-(y-b)**2
        expected = (delta[first].sum(axis=1)+delta[second].sum(axis=1))/64
        np.testing.assert_array_equal(samples, expected)
        np.testing.assert_array_equal(actual["percentile_95_ci"], np.percentile(expected, [2.5, 97.5]))


class IndependentInputsReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = ROOT/"results/phase3/ensemble"
        if not (cls.directory/"input_manifest.json").exists():
            raise unittest.SkipTest("Initial input freeze not available")
        cls.manifest = json.loads((cls.directory/"input_manifest.json").read_text())
        cls.config = json.loads((cls.directory/"CONFIG.json").read_text())

    def test_all_256_saved_initial_inputs_rebuild_and_preserve_component_powers(self):
        from phase2.ensemble import initial_condition
        m, cfg = self.manifest, self.config
        self.assertEqual(m["count"], 256)
        self.assertEqual(sum(r["split"] == "train" for r in m["cases"]), 192)
        self.assertEqual(cfg["seed"], 2026101803)
        self.assertEqual(cfg["polarization_seed"], 20261016)
        old_cfg = json.loads((ROOT/"results/phase2/ensemble/CONFIG.json").read_text())
        self.assertEqual(cfg["canonical_modes"], old_cfg["canonical_modes"])
        self.assertNotEqual(cfg["seed"], old_cfg["seed"])
        with np.load(self.directory/"phase_draws.npz") as data:
            theta, delta = data["theta"], data["delta"]
        np.testing.assert_array_equal(theta, np.random.Generator(np.random.PCG64(2026101803)).uniform(0, 2*np.pi, (2, 128, 11)))
        np.testing.assert_array_equal(delta, np.random.Generator(np.random.PCG64(20261016)).uniform(0, 2*np.pi, 11))
        refs = {}
        for r in m["cases"]:
            path = self.directory/r["input_path"]
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), r["input_sha256"])
            self.assertEqual(r["split"], "train" if r["index"] < 96 else "test")
            with np.load(path) as data:
                uh = data["uh"]
                expected = initial_condition(24, r["profile"], theta[r["profile_index"], r["index"]], delta, cfg["canonical_modes"])
                np.testing.assert_array_equal(uh, expected)
                if r["profile"] not in refs:
                    refs[r["profile"]] = uh.copy()
                np.testing.assert_allclose(abs(uh)**2, abs(refs[r["profile"]])**2, atol=3e-16, rtol=0)

    def test_frozen_sources_initial_table_and_addendum_provenance(self):
        from phase3.ensemble import SOURCE_PATHS
        sources = dict(SOURCE_PATHS)
        sources.update(plan_sha256=ROOT/"phase3/PLAN.md",
                       probe_gate_clarification_sha256=ROOT/"phase3/PROBE_GATE_CLARIFICATION.md",
                       config_sha256=self.directory/"CONFIG.json",
                       initial_features_sha256=self.directory/"initial_features.csv",
                       phase_draws_sha256=self.directory/"phase_draws.npz")
        for key, path in sources.items():
            self.assertEqual(self.manifest[key], hashlib.sha256(path.read_bytes()).hexdigest(), key)
        self.assertTrue(self.manifest["prepared_before_integration"])
        self.assertTrue(self.manifest["initial_features_only"])
        with (self.directory/"initial_features.csv").open() as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 256)
        self.assertFalse(set(rows[0]) & {"delta_Z", "Z_final", "S_final", "target"})
        prior = json.loads((self.directory/"input_manifest.pre_addendum.json").read_text())
        for key in ("initial_features_sha256", "phase_draws_sha256", "plan_sha256", "cases"):
            self.assertEqual(self.manifest[key], prior[key])
        if (self.directory/"production_start.json").exists():
            start = json.loads((self.directory/"production_start.json").read_text())
            self.assertLess(self.manifest["prepared_utc"], start["started_utc"])
            self.assertLess(self.manifest["metadata_amendment"]["utc"], start["started_utc"])
            self.assertEqual(start["input_manifest_sha256"], hashlib.sha256((self.directory/"input_manifest.json").read_bytes()).hexdigest())


def independent_z(uh):
    N = uh.shape[1]
    wave = np.fft.fftfreq(N, d=1/N)
    k = np.array(np.meshgrid(wave, wave, np.arange(N//2+1), indexing="ij"))
    weights = np.ones(N//2+1); weights[1:-1] = 2
    return float(.5*np.sum(weights*np.sum(k*k, axis=0)*np.sum(abs(uh)**2, axis=0)))


def independent_field_l2(coarse, fine):
    def full(a):
        N = a.shape[1]
        return np.fft.fftn(np.fft.irfftn(a, s=(N,)*3, axes=(-3, -2, -1)), axes=(-3, -2, -1))
    a, b = full(coarse), full(fine)
    embedded = np.zeros_like(b)
    ids = np.fft.fftfreq(a.shape[1], d=1/a.shape[1]).astype(int) % b.shape[1]
    for component in range(3):
        embedded[component][np.ix_(ids, ids, ids)] = a[component]
    return float(np.sqrt(np.sum(abs(embedded-b)**2)))


class IndependentReleasedOutcomesReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = ROOT/"results/phase3/prediction"
        cls.ensemble = ROOT/"results/phase3/ensemble"
        if not (cls.directory/"summary.json").exists():
            raise unittest.SkipTest("The frozen one-time held-out evaluation has not been released")
        # Establish the declared release and immutable fit artifacts FIRST.
        cls.lock = json.loads((cls.directory/"fit_lock.json").read_text())
        if cls.lock.get("n_fits") != 12 or not cls.lock.get("all_predeclared_fits_completed_before_heldout_target_extraction"):
            raise AssertionError("Held-out release does not certify all twelve prior fits")
        for key, filename in (("models_sha256", "models.json"), ("cv_results_sha256", "cv_results.json")):
            if cls.lock[key] != hashlib.sha256((cls.directory/filename).read_bytes()).hexdigest():
                raise AssertionError("A fit artifact changed after the lock")
        cls.summary = json.loads((cls.directory/"summary.json").read_text())
        if cls.lock["fit_locked_utc"] >= cls.summary["test_evaluation_started_utc"]:
            raise AssertionError("Test release did not follow the fit lock")
        # Only after the release checks, inspect saved targets and predictions.
        from phase3 import predict
        cls.records = predict.read_records(cls.ensemble/"features.csv")
        cls.models = json.loads((cls.directory/"models.json").read_text())
        cls.convergence = json.loads((cls.ensemble/"convergence.json").read_text())
        with (cls.directory/"predictions.csv").open() as f:
            cls.saved = list(csv.DictReader(f))
        cls.labels = np.array([r["profile"] for r in cls.records])
        cls.indices = np.array([int(r["index"]) for r in cls.records])
        cls.test = cls.indices >= 96
        cls.p = np.column_stack((cls.labels == "flat", cls.labels == "kminus2")).astype(float)
        cls.y = np.array([float(r["Z_final"])-r["Z"] for r in cls.records])
        s = np.array([r["S"] for r in cls.records])
        base = np.column_stack([cls.p[:, j]*s**d for j in range(2) for d in (1, 2, 3)])
        viscous = np.column_stack((base, np.array([r["nu"]*r["V"] for r in cls.records]), np.array([r["nu"]*r["Ddot"] for r in cls.records])))
        cls.designs = dict(baseline=base, viscous=viscous,
                          quartic=np.column_stack((viscous, [r["Q"] for r in cls.records])),
                          curvature=np.column_stack((viscous, [r["Zddot"] for r in cls.records])))

    def test_release_and_all_saved_source_hashes(self):
        from phase3.ensemble import SOURCE_PATHS
        provenance = self.summary["provenance"]
        sources = dict(plan_sha256=ROOT/"phase3/PLAN.md",
                       probe_gate_clarification_sha256=ROOT/"phase3/PROBE_GATE_CLARIFICATION.md",
                       input_manifest_sha256=self.ensemble/"input_manifest.json",
                       initial_features_sha256=self.ensemble/"initial_features.csv",
                       input_sha256=self.ensemble/"features.csv",
                       config_sha256=self.ensemble/"CONFIG.json",
                       predict_py_sha256=ROOT/"phase3/predict.py",
                       phase2_predict_py_sha256=ROOT/"phase2/predict.py")
        for key, path in sources.items():
            self.assertEqual(provenance[key], hashlib.sha256(path.read_bytes()).hexdigest(), key)
        self.assertEqual(provenance, self.lock["provenance"])
        self.assertEqual(self.summary["fit_lock_sha256"], hashlib.sha256((self.directory/"fit_lock.json").read_bytes()).hexdigest())
        start = json.loads((self.ensemble/"production_start.json").read_text())
        for key, path in SOURCE_PATHS.items():
            self.assertEqual(start[key], hashlib.sha256(path.read_bytes()).hexdigest(), key)
        self.assertEqual(self.summary["counts"]["train"], 192)
        self.assertEqual(self.summary["counts"]["test"], 64)

    def test_all_256_targets_match_complete_saved_endpoint_fields(self):
        start = json.loads((self.ensemble/"production_start.json").read_text())
        for r in self.records:
            directory = self.ensemble/"main"/r["case_id"]
            result = json.loads((directory/"result.json").read_text())
            for key in ("solver_sha256", "feature_code_sha256", "ensemble_code_sha256", "input_manifest_sha256", "plan_sha256", "probe_gate_clarification_sha256"):
                self.assertEqual(result[key], start[key], (r["case_id"], key))
            for name, digest in result["artifact_sha256"].items():
                self.assertEqual(digest, hashlib.sha256((directory/name).read_bytes()).hexdigest())
            with np.load(directory/"snapshots.npz") as data:
                u0, u1 = data["uh"]
                np.testing.assert_array_equal(data["times"], [0, .5])
            with np.load(directory/"input.npz") as data:
                np.testing.assert_array_equal(u0, data["uh"])
            z0, z1 = independent_z(u0), independent_z(u1)
            self.assertAlmostEqual(z0, r["Z"], delta=2e-13)
            self.assertAlmostEqual(z1, float(r["Z_final"]), delta=2e-13)
            self.assertAlmostEqual(z1-z0, float(r["delta_Z"]), delta=3e-13)
            self.assertAlmostEqual(fresh_stretching(u1), float(r["S_final"]), delta=3e-12)

    def test_all_12_saved_fits_cv_metrics_and_ranks_match_independent_fits(self):
        self.assertEqual(len(self.saved), 3*256)
        for n in (64, 128, 192):
            mask = self.indices < n//2
            folds = self.indices[mask] % 4
            p, y = self.p[mask], self.y[mask]
            rows = [r for r in self.saved if int(r["training_size"]) == n]
            self.assertEqual([r["case_id"] for r in rows], [r["case_id"] for r in self.records])
            output = self.summary["learning_curves"][str(n)]["models"]
            for name, xall in self.designs.items():
                x = xall[mask]
                scores = []
                for alpha in (1e-4, .01, .1, 1., 10., 100.):
                    oof = np.zeros(n)
                    for fold in range(4):
                        valid = folds == fold
                        oof[valid] = independent_ridge_fit(x[~valid], y[~valid], p[~valid], alpha, x[valid], p[valid])
                    scores.append(float(np.mean((y-oof)**2)))
                np.testing.assert_allclose(scores, [r["mse"] for r in output[name]["cv_grid"]], atol=3e-12, rtol=0)
                alpha = (1e-4, .01, .1, 1., 10., 100.)[int(np.argmin(scores))]
                self.assertEqual(output[name]["alpha"], alpha)
                prediction = independent_ridge_fit(x, y, p, alpha, xall, self.p)
                saved_prediction = np.array([float(r[name]) for r in rows])
                np.testing.assert_allclose(prediction, saved_prediction, atol=4e-12, rtol=0)
                model = self.models[str(n)][name]
                np.testing.assert_array_equal(model["training_feature_mean"], x.mean(0))
                np.testing.assert_array_equal(model["training_feature_scale"], x.std(0))
                z = (x-x.mean(0))/x.std(0)
                z -= p@(p.T@z/p.sum(0)[:, None])
                self.assertEqual(output[name]["centered_design_rank"], np.linalg.matrix_rank(z))
            for name in ("baseline", "viscous", "quartic", "curvature", "euler_fixed", "taylor2_fixed"):
                prediction = np.array([float(r[name]) for r in rows])
                if name in ("euler_fixed", "taylor2_fixed"):
                    expected = np.array([r["T"]*(r["S"]-r["nu"]*r["D"]) for r in self.records])
                    if name == "taylor2_fixed":
                        expected += np.array([.5*r["T"]**2*r["Zddot"] for r in self.records])
                    np.testing.assert_array_equal(expected, prediction)
                for group in ("pooled", "flat", "kminus2"):
                    use = self.test & ((self.labels == group) if group != "pooled" else True)
                    error = prediction[use]-self.y[use]
                    metrics = output[name]["test_metrics"][group]
                    self.assertEqual(metrics["n"], use.sum())
                    for key, value in (("mse", np.mean(error**2)), ("rmse", np.sqrt(np.mean(error**2))), ("mae", np.mean(abs(error)))):
                        self.assertAlmostEqual(metrics[key], value, delta=2e-14)

    def test_all_2000_saved_paired_bootstrap_draws(self):
        rows = [r for r in self.saved if int(r["training_size"]) == 192 and r["split"] == "test"]
        self.assertEqual(len(rows), 64)
        y = np.array([float(r["delta_Z_true"]) for r in rows])
        a = np.array([float(r["viscous"]) for r in rows])
        b = np.array([float(r["quartic"]) for r in rows])
        delta = (y-a)**2-(y-b)**2
        rng = np.random.default_rng(2026101804)
        first = rng.integers(0, 32, size=(2000, 32))
        second = rng.integers(32, 64, size=(2000, 32))
        samples = (delta[first].sum(axis=1)+delta[second].sum(axis=1))/64
        with (self.directory/"bootstrap.csv").open() as f:
            saved = list(csv.DictReader(f))
        self.assertEqual(len(saved), 2000)
        np.testing.assert_array_equal(samples, [float(r["primary_delta_mse_viscous_minus_quartic"]) for r in saved])
        boot = self.summary["primary_comparison"]["paired_bootstrap"]
        self.assertEqual(boot["delta_mse_baseline_minus_augmented"], delta.mean())
        np.testing.assert_array_equal(boot["percentile_95_ci"], np.percentile(samples, [2.5, 97.5]))
        self.assertEqual(boot["fraction_bootstrap_delta_above_zero"], float(np.mean(samples > 0)))

    def test_all_predeclared_numerical_probes_and_conservative_gate(self):
        comparisons = self.convergence["comparisons"]
        expected = {(p, i, b) for p in ("flat", "kminus2") for i in (0, 1, 32, 33)
                    for b in ("probe_n32", "probe_dt_half")}
        self.assertEqual({(r["profile"], r["index"], r["branch"]) for r in comparisons}, expected)
        self.assertEqual(len(comparisons), 16)
        for r in comparisons:
            with np.load(self.ensemble/"main"/r["case_id"]/"snapshots.npz") as z:
                coarse = z["uh"]
            with np.load(self.ensemble/r["branch"]/r["case_id"]/"snapshots.npz") as z:
                fine = z["uh"]
                self.assertEqual(float(z["dt"]), .005 if r["branch"] == "probe_n32" else .0025)
            self.assertLess(independent_field_l2(coarse[0], fine[0]), 1e-14)
            self.assertAlmostEqual(independent_field_l2(coarse[1], fine[1]), r["final_velocity_l2"], delta=2e-13)
            dz = (independent_z(fine[1])-independent_z(fine[0]))-(independent_z(coarse[1])-independent_z(coarse[0]))
            self.assertAlmostEqual(dz, r["delta_Z_difference"], delta=3e-13)
            self.assertLess(r["max_initial_feature_abs_difference"], 1e-10)
        rms = {b: float(np.sqrt(np.mean([r["delta_Z_difference"]**2 for r in comparisons if r["branch"] == b]))) for b in ("probe_n32", "probe_dt_half")}
        output = self.summary["learning_curves"]["192"]["models"]
        mv, mq = output["viscous"]["test_metrics"], output["quartic"]["test_metrics"]
        gain = mv["pooled"]["rmse"]-mq["pooled"]["rmse"]
        relative = 1-mq["pooled"]["mse"]/mv["pooled"]["mse"]
        gate = relative >= .1 and all(mv[p]["mse"] >= mq[p]["mse"] for p in ("flat", "kminus2")) and gain > 0 and max(rms.values()) < .1*gain
        saved = self.summary["practical_gate"]
        self.assertEqual(saved["passed"], gate)
        self.assertEqual(saved["maximum_branch_rms_delta_Z_discrepancy"], max(rms.values()))
        self.assertEqual(saved["numerical_rms_threshold"], .1*gain)


if __name__ == "__main__":
    unittest.main()
