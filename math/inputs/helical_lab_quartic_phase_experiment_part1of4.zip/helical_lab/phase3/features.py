"""Initial PDE-jet features, exact up to roundoff on the stated finite support.

S(u)=<omega_i omega_j partial_j u_i>, B(u,u)=-P[(u.grad)u].
Q=DS(u)[B(u,u)] is quartic; V=DS(u)[Delta u] is cubic.
D=<|grad omega|^2>, Ddot_N=DD(u)[B(u,u)], Ddot_L=DD(u)[Delta u].
Z''=Q+nu*V-nu*(Ddot_N+nu*Ddot_L).

This implementation deliberately accepts only mean-zero, real, solenoidal
initial fields of componentwise bandwidth K<=2. All B modes (K<=4) must be
retained by the unchanged solver, and N>4*K makes quartic zero-mode quadrature
alias-free. It is NOT a general full-evolved-band quartic diagnostic.
"""
from __future__ import annotations
from functools import lru_cache
import numpy as np
from solver import NS
from phase2.full_band import FullBandDiagnostics

MAX_INITIAL_K = 2


@lru_cache(maxsize=4)
def _geometry(N):
    return NS(N, 0), FullBandDiagnostics(N)


def validate_initial(uh):
    uh = np.asarray(uh)
    if uh.ndim != 4:
        raise ValueError('Expected a (3,N,N,N//2+1) spectrum')
    N = uh.shape[1]
    solver, validator = _geometry(N)
    metadata = validator.validate(uh)
    K = metadata['active_componentwise_K']
    if K > MAX_INITIAL_K:
        raise ValueError(f'Initial PDE features support only K <= {MAX_INITIAL_K}; got {K}')
    if N <= 4*K or solver.g.K < 2*K:
        raise ValueError('Need N > 4*K and solver retained K >= 2*K to retain every B mode')
    amplitude = np.max(np.abs(uh), initial=0.)
    if metadata['mean_velocity_norm'] > 256*np.finfo(float).eps*amplitude:
        raise ValueError('Initial PDE features require a mean-zero field')
    return solver, metadata


def _curl_and_gradient(g, uh):
    omega = g.inv(g.curl_h(uh))
    # gradient[j,i,...] = partial_j u_i
    gradient = g.inv(1j*g.kvec[:, None]*uh[None])
    return omega, gradient


def _contract(a, b, gradient):
    return float(np.einsum('ixyz,jxyz,jixyz->', a, b, gradient, optimize=False)/a[0].size)


def stretching(uh):
    """Physical cubic quadrature for finite-difference validation (N>3*K)."""
    N = uh.shape[1]
    solver, validator = _geometry(N)
    validator.validate(uh)
    omega, gradient = _curl_and_gradient(solver.g, uh)
    return _contract(omega, omega, gradient)


def stretching_directional(uh, vh):
    """Analytic DS(u)[v] in its three physical slots.

    Caller owns support checks for the direction. For initial_features the
    largest sum-band is 2*K+K+K=4*K, explicitly checked before evaluation.
    """
    if np.shape(uh) != np.shape(vh):
        raise ValueError('The state and direction must share a grid')
    g = _geometry(uh.shape[1])[0].g
    omega, gradient = _curl_and_gradient(g, uh)
    eta, gradient_v = _curl_and_gradient(g, vh)
    slots = (_contract(eta, omega, gradient),
             _contract(omega, eta, gradient),
             _contract(omega, omega, gradient_v))
    return float(sum(slots))


def dissipation_directional(uh, vh):
    g = _geometry(uh.shape[1])[0].g
    return 2*g.inner(g.curl_h(vh), g.k2*g.curl_h(uh))


def initial_features(uh, nu=1/28):
    """Return initial-only Q, V and the complete enstrophy second derivative."""
    if not np.isfinite(nu) or nu < 0:
        raise ValueError('Viscosity must be finite and nonnegative')
    solver, metadata = validate_initial(uh)
    g = solver.g
    n, lap = solver.nonlin(uh), -g.k2*uh
    Q = stretching_directional(uh, n)
    V = stretching_directional(uh, lap)
    dn, dl = dissipation_directional(uh, n), dissipation_directional(uh, lap)
    ddot = dn + nu*dl
    viscous = nu*V-nu*ddot
    return dict(Q=Q, V=V, Ddot_N=dn, Ddot_L=dl, Ddot_inviscid=dn, W=-dl/2, Ddot=ddot,
                Sdot=Q+nu*V, Zddot=Q+viscous, Zpp=Q+viscous, Zddot_viscous=viscous)


def zddot_rhs(uh, nu=1/28):
    """Independent second derivative through the differentiated rotational RHS.

    Used for validation only, never substituted for the analytic feature.
    """
    solver, _ = validate_initial(uh)
    g = solver.g
    v = solver.nonlin(uh)-nu*g.k2*uh
    u, w = g.inv(uh), g.inv(g.curl_h(uh))
    vp, wp = g.inv(v), g.inv(g.curl_h(v))
    cross = lambda a,b: np.cross(a,b,axisa=0,axisb=0,axisc=0)
    acceleration = g.proj(g.fwd(cross(vp,w)+cross(u,wp)))-nu*g.k2*v
    return g.inner(g.curl_h(v),g.curl_h(v))+g.inner(g.curl_h(uh),g.curl_h(acceleration))
