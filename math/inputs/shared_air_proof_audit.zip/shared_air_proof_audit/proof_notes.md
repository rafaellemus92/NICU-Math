# Shared Air: mathematical audit and proofs

## Scope and provenance

This document analyzes the equations in the user-supplied **Shared Air Model.md**. The linked public artifact did not load during the audit. The Markdown supplies model equations and descriptions, but not the executable simulator. Consequently, this audit does **not** reproduce its simulated sessions, numerical integration, uncertainty bands, or recovery plots.

The uploaded source distinguishes “Perceived,” “Physical,” and “Alike” mechanisms. Its equations are in extracted lines 196–205. It explicitly states that its cells are phase oscillators rather than ion-channel models (line 221), and that its parameters were not fitted to patients (lines 216–218). These limitations remain in force.

The water-exchange equations below come from the preceding conversation, **not** from Shared Air. The general feedback theorem and the aggregate-state counterexamples are mathematical developments in this audit. They are not presented as claims made by the uploaded source. No claim of literature novelty is made.

## 1. The strongest result: a unique finite recovery-optimal gain

### 1.1 Exact reduction being analyzed

The source has infant state A_i, maternal state A_m, and response state C. To analyze a specified equilibrium, set:

- external input U = 0 and noise = 0;
- baseline A_0 = 0 and steadiness = 1;
- gain g >= 0;
- initially retain the source's delay tau >= 0.

The origin is then an equilibrium. The cubic terms have zero derivative there. The response-capacity function is cap(y) = 1/(1+(y/0.8)^2), so cap(0)=1 and cap'(0)=0.

Writing x=A_i, y=A_m, z=C, the exact local linearization is

\[
\dot x=-x/30-z+(g/25)y(t-\tau),
\]
\[
\dot y=-y/20+(g/10)x(t-\tau),
\]
\[
\dot z=-z/4+(3g/40)x(t-\tau).
\]

This is a linearization at a deliberately selected baseline. It is **not** the full nonlinear noisy source model, nor necessarily its default operating equilibrium.

### 1.2 Characteristic equation, with delay retained

Substitute (x,y,z)=(X,Y,Z) exp(st). The determinant is

\[
D(s,g,\tau)=(s+1/30)(s+1/20)(s+1/4)
 +\frac{3g}{40}(s+1/20)e^{-s\tau}
 -\frac{g^2}{250}(s+1/4)e^{-2s\tau}.
\]

The negative response loop enters at order g. The positive x-to-y-to-x loop enters at order g^2. The latter carries two delays. This is an algebraic distinction between two feedback paths, not a physiological inference.

### 1.3 A theorem for a larger class of networks

Consider the zero-delay linear system

\[
\dot x=-a x-z+rgy,\qquad
\dot y=-b y+qgx,\qquad
\dot z=-d z+hgx,
\]

where r,q,h>0, 0<a<b, and d >= 3b-2a. Define c=rq>0. These are sufficient conditions, not necessary ones.

Its characteristic polynomial is

\[
P(s,g)=(s+a)(s+b)(s+d)+hg(s+b)-cg^2(s+d).
\]

For g>=0, define the spectral recovery rate

\[
\rho(g)=-\max\{\Re s:P(s,g)=0\}.
\]

A positive rho means asymptotic linear decay; a negative rho means instability. It is not the finite-threshold recovery statistic used in Test 4 of the source.

**Theorem.** The spectral recovery rate has a unique global maximum at a finite positive gain. Let s_* be the unique root in (-b,-a) of

\[
H(s)=(s+a)(s+d)^2+\frac{h^2}{4c}(s+b)=0.
\]

Then

\[
g_* = \frac{h}{2c}\frac{s_*+b}{s_*+d},
\qquad \rho(g_*)=-s_*.
\]

Moreover, the zero equilibrium is exponentially stable exactly for 0<=g<g_c, where

\[
g_c=\frac{hb+\sqrt{h^2b^2+4cabd^2}}{2cd}.
\]

At g=g_c there is a zero characteristic root. Linear analysis alone does not classify the nonlinear system at that boundary.

### 1.4 Proof of the theorem

**Step A: identify the dominant root.** For g>0,

\[
P(-b,g)=-cg^2(d-b)<0,
\]

and P(s,g) tends to positive infinity as real s tends to infinity. On s>=-b,

\[
P_{ss}(s,g)=6s+2(a+b+d)>0,
\]

because d>=3b-2a and b>a. Thus P is strictly convex there. Starting negative, it crosses zero exactly once on (-b,infinity), at a simple root s(g).

Any other real root is <=-b. If the two other roots form a complex pair, their real part is

\[
\frac{-a-b-d-s(g)}{2}<s(g),
\]

since a+d>2b and s(g)>-b. Therefore s(g) is the dominant root. At g=0, the dominant root is -a, consistent with the continuous limit.

**Step B: complete the square in gain.** Set

\[
G(s)=\frac{h}{2c}\frac{s+b}{s+d}.
\]

Direct expansion gives the identity

\[
P(s,g)=\frac{s+b}{s+d}H(s)-c(s+d)(g-G(s))^2.
\]

For the dominant root s(g)>-b, all the displayed prefactors are positive. Hence P(s(g),g)=0 implies H(s(g))>=0.

**Step C: show that H has a unique lower envelope.**

\[
H(-b)=(a-b)(d-b)^2<0,
\]

whereas

\[
H(-a)=\frac{h^2}{4c}(b-a)>0.
\]

Also, for s>-b,

\[
H'(s)=(s+d)(3s+d+2a)+\frac{h^2}{4c}>0,
\]

using d>=3b-2a. Thus H has a unique root s_* in (-b,-a), and H(s(g))>=0 implies s(g)>=s_*.

Equality is attained exactly when g=G(s_*)=g_*>0. At that gain P(s_*,g_*)=0, so the unique dominant root is s_*. Therefore rho(g)<=-s_*, with equality only at g_*. This proves global optimality and uniqueness, rather than inferring them from a numerical sweep.

**Step D: stability range.** At s=0,

\[
P(0,g)=abd+hbg-cdg^2.
\]

The unique positive zero of this expression is g_c above. For 0<g<g_c, P(-b,g)<0 and P(0,g)>0, so the dominant root lies in (-b,0). For g>g_c it is positive. At g=0 the three eigenvalues are -a,-b,-d. This proves the stated stability interval.

### 1.5 Application to Shared Air's coefficients

Here

\[
a=1/30,\quad b=1/20,\quad d=1/4,
\quad r=1/25,\quad q=1/10,\quad h=3/40.
\]

The sufficient condition d>=3b-2a is satisfied. At zero delay,

\[
P(s,g)=s^3+\frac13s^2+
\left(\frac9{400}+\frac{3g}{40}-\frac{g^2}{250}\right)s
+\frac1{2400}+\frac{3g}{800}-\frac{g^2}{1000}.
\]

The optimizer is specified exactly by

\[
(s_*+1/30)(s_*+1/4)^2+\frac{45}{128}(s_*+1/20)=0,
\]

\[
g_* =\frac{75}{8}\frac{s_*+1/20}{s_*+1/4}.
\]

Numerical evaluation gives

\[
s_*\approx-0.048270920643982,
\qquad g_*\approx0.080355886292728.
\]

The static instability threshold is

\[
g_c=\frac{15}{8}+\frac{\sqrt{2265}}{24}
\approx3.858000672381799.
\]

The initial improvement can also be proved by implicit differentiation:

\[
s'(0)=-\frac{h}{d-a}=-\frac9{26},
\qquad \rho'(0)=\frac9{26}>0.
\]

These numerical values inherit the source's illustrative coefficients. They are not biological parameter estimates. They do not prove the shape of its nonlinear, delayed, noisy Test 4 output. In particular, the source sweeps responsiveness from 0 to 3; the static instability threshold above lies beyond that sweep.

### 1.6 A delay-independent instability statement

In the original linearized delay equation, D(0,g,tau)=P(0,g), independent of tau. For g>g_c it is negative. For real s tending to infinity, D(s,g,tau) tends to positive infinity, for every finite tau>=0. The intermediate value theorem therefore supplies a positive real characteristic root.

Thus g>g_c makes this chosen equilibrium unstable for **every** delay tau>=0. Delay may introduce additional instabilities below this bound; the zero-delay optimum and full stability interval must not be transferred unchanged to tau>0.

This also shows why one cannot attribute a nonmonotonic gain response to delay alone in the full source system: it contains a g^2 positive-feedback path, saturation, and cubic terms as well.

## 2. Cellular aggregation: identical measured synchrony, different derivatives

The source's mean-field cell coupling has the form

\[
\dot\theta_j=\omega+K\operatorname{Im}(Z_1e^{-i\theta_j})
\]

when all natural frequencies are identical and constant and external forcing is removed. These are explicit simplifying restrictions of the source model. Define

\[
Z_1=\frac1m\sum_j e^{i\theta_j},\qquad
Z_2=\frac1m\sum_j e^{2i\theta_j}.
\]

Differentiation, without approximation, gives

\[
\dot Z_1=i\omega Z_1+\frac K2(Z_1-\overline{Z_1}Z_2).
\]

Therefore even the full complex first moment Z_1 is generally not a closed state variable. Its derivative depends on Z_2. The reported coherence R=|Z_1| contains still less information.

### Exact counterexample

Work in the rotating frame, so omega=0. Compare two sets of four phases:

- A: (0,0,pi/2,-pi/2).
- B: (0,0,0,pi).

Both have Z_1=1/2 and R=1/2. But Z_2=0 in A and Z_2=1 in B. Consequently,

\[
\dot R_A=K/4,\qquad \dot R_B=0.
\]

Repeating each four-cell configuration six times gives **24 cells**, matching the source's pacemaker population size, with unchanged moments and derivatives.

The antipodal configuration B is a special state, not a claim of robustness to perturbations. A single valid state pair is sufficient to disprove autonomous closure in R or Z_1.

With the source's common forcing term -epsilon P(t) sin(theta_j), the exact first-moment identity gains

\[
\frac{\epsilon P(t)}2(1-Z_2).
\]

With unequal natural frequencies, i omega Z_1 becomes i times the average of omega_j exp(i theta_j), adding another unresolved moment. Neither extension restores generic closure.

## 3. Connection to the previous water-compartment model

### 3.1 Closed passive model

Let n_i,n_E,K_i,W all be positive constants. Individual water volumes v_i and extracellular volume V_E obey

\[
V_E=W-\sum_i v_i>0,
\qquad
\dot v_i=K_i\left(\frac{n_i}{v_i}-\frac{n_E}{V_E}\right).
\]

The assumptions are a closed total-water reservoir, fixed effective osmoles, fixed positive transport coefficients, and no hydrostatic forcing. The equations are not contained in Shared Air; they come from the earlier discussion.

Define

\[
F(v)=-\sum_i n_i\log(v_i/V_{ref})-n_E\log(V_E/V_{ref}),
\]

where V_ref>0. Then

\[
\frac{\partial F}{\partial v_i}=-\frac{n_i}{v_i}+\frac{n_E}{V_E},
\qquad
\dot v=-\operatorname{diag}(K_i)\nabla F,
\]

and

\[
\dot F=-\sum_i K_i\left(\frac{n_i}{v_i}-\frac{n_E}{V_E}\right)^2\le0.
\]

The Hessian is

\[
\nabla^2 F=\operatorname{diag}(n_i/v_i^2)
+\frac{n_E}{V_E^2}{\boldsymbol 1}{\boldsymbol 1}^{T},
\]

which is positive definite. As any compartment approaches zero, F tends to positive infinity. The trajectory stays in a compact interior sublevel set, exists for all positive time, and converges to the unique equilibrium

\[
v_i^*=W\frac{n_i}{n_E+\sum_jn_j},
\qquad
V_E^*=W\frac{n_E}{n_E+\sum_jn_j}.
\]

One direct quantitative argument is to use the squared distance

\[
E=\frac12(v-v^*)^T\operatorname{diag}(K_i)^{-1}(v-v^*).
\]

Since every v_i<W, the Hessian is bounded below by m I, with m=min_i(n_i)/W^2. Thus

\[
\dot E\le-2mK_{min}E.
\]

This supplies a conservative exponential convergence bound. There can be no nonconstant periodic orbit in this autonomous closed passive model. A forced system is a different problem.

### 3.2 Exact aggregate-state counterexample

Take two cells with n_1=n_2=K_1=K_2=1, n_E=2, V_E=2. Configuration A has v=(1,1), and B has v=(1/2,3/2). Both have total intracellular water 2, extracellular water 2, total water 4, and the same osmole totals. Yet

\[
\dot V_I^A=0,
\qquad
\dot V_I^B=(2-1)+(2/3-1)=2/3.
\]

This and the oscillator counterexample have the same structural lesson: an aggregate observation need not determine its own derivative.

### 3.3 General closure criterion

For a smooth system dot z=F(z) and observation y=h(z), an exact autonomous reduced law dot y=f(y) requires

\[
Dh(z)F(z)
\]

to be identical on each set of microscopic states having the same h(z). If that constancy holds, it defines f on the image of h; appropriate regularity is additionally needed for a well-posed reduced differential equation.

The counterexamples violate this necessary condition. Hidden state variables, history, or additional moments must be retained; they cannot be recovered from the one aggregate number without further assumptions.

## 4. Audit of the source's 2:1 locking formula

The source uses

\[
P(\psi)=e^{2(\cos\psi-1)}-\text{mean}.
\]

Its cosine coefficient at harmonic 2 is

\[
a_2=2e^{-2}I_2(2)\approx0.186478066609467,
\]

so the reported rounded value 0.19 is consistent. The checker verifies it both by a convergent series and by independent numerical quadrature.

Freeze the driving phase at psi=Omega t and reduce the responding population to a single phase:

\[
\dot\theta=\omega-\epsilon P(\Omega t)\sin\theta.
\]

Writing phi=theta-2Omega t and assuming weak forcing with near-resonant detuning gives the first-order averaged equation

\[
\dot\phi=(\omega-2\Omega)-\frac{\epsilon a_2}{2}\sin\phi.
\]

A stable equilibrium in this averaged equation requires

\[
|\omega-2\Omega|<\epsilon a_2/2.
\]

This is **not an exact criterion for the complete heterogeneous, modulated, noisy population model**. It is an exact locking condition for the displayed averaged equation, whose relation to the original dynamics is asymptotic under the stated assumptions.

The Markdown does not give the implementation of its locking index. For a 2:1 relationship sampled at responding-oscillator beats, the first circular moment of the driving phase can vanish: equal populations at driving phases 0 and pi have first moment zero, despite perfect locking. The second harmonic moment is one. The correct index must match the intended resonance, or the phase difference theta-2 psi can be analyzed directly. This is an implementation question to check, not a proven defect in unavailable code.

## 5. Counterexample to causal interpretation of correlation subtraction

The source describes subtracting infant–other-parent correlation from infant–mother correlation as removing the shared room contribution. That is not a general mathematical identity.

Let U,e_1,e_2,e_3 be independent, zero-mean, unit-variance variables. Define

\[
X=U+e_1,\qquad M=U+e_2,\qquad O=U+3e_3.
\]

There are no direct interaction terms among X,M,O. Nevertheless,

\[
\operatorname{Corr}(X,M)=1/2,
\qquad
\operatorname{Corr}(X,O)=1/\sqrt{20},
\]

and their difference is approximately 0.2763932>0. Differing noise alone suffices; different common-input filters provide further possibilities. Therefore the difference is a descriptive contrast, not automatically an identified direct-coupling effect.

The checker verifies this by enumerating the complete distribution of four independent +/-1 variables, without sampling noise.

## 6. What follows, and what remains open in this audit

**Established here:** a unique recovery-optimal positive gain for a specified class of zero-delay linear feedback systems; its specialization to the source's coefficients; a delay-independent high-gain instability bound for the chosen linearization; exact failures of aggregate-state closure in water and phase populations; global convergence of the stated passive water model; and the first-order interpretation of the source's locking inequality.

**Not established here:** an optimum for the full nonlinear noisy delayed model, a stable nonlinear limit cycle after destabilization, an actual biological coupling mechanism, a water-to-pacemaker constitutive law, the numerical validity of the original simulator, or originality relative to all prior mathematical literature.

A focused next mathematical task is to extend the recovery-optimum theorem to positive delay while keeping both feedback pathways and specifying a nonzero equilibrium. A separate task is to identify additional moment variables or bounds that make the water and phase reductions predictive. Connecting water volumes to natural oscillator frequencies would require an additional, independently justified model relation; neither the source nor the preceding passive-exchange model supplies it.

## 7. Reproduction and external mathematical context

Run `python verify_shared_air.py --output audit_results.json` with Python 3.10+; only the standard library is required. Exact fraction checks are used where applicable. Other checks evaluate proven formulas numerically and do not replace their derivations.

External context, distinct from source-derived claims and the proofs above:

- Yoichiro Mori, *Mathematical Properties of Pump-Leak Models of Cell Volume Control and Electrolyte Balance*, Journal of Mathematical Biology 65 (2012), 875–918; preprint https://arxiv.org/abs/1104.4097. Free-energy and stability methods in a more complete cell-volume setting.
- Hiroya Nakao, *Phase reduction approach to synchronisation of nonlinear oscillators*, Contemporary Physics 57 (2016), 188–214; preprint https://arxiv.org/abs/1704.03293. Weak-perturbation phase reduction, periodic locking, and common-input synchronization.

The methods used here belong to established dynamical-systems mathematics. The results are useful deductions from explicitly specified equations; their novelty is not certified.
