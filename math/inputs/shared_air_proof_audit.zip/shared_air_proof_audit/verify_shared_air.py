#!/usr/bin/env python3
"""Independent mathematical checks for the uploaded Shared Air model.

Python 3.10+, standard library only. No patient data or original simulator needed.

Run:
    python verify_shared_air.py
    python verify_shared_air.py --output audit_results.json

The proofs and assumptions are in proof_notes.md. The tests check identities,
examples, and numerical evaluations; floating-point tests do not replace proofs.
This script does NOT validate the original interactive simulator or its experiments.
"""
from __future__ import annotations

import argparse
import cmath
from fractions import Fraction as F
import itertools
import json
import math
from pathlib import Path
from typing import Callable, Sequence

A, B, D = F(1, 30), F(1, 20), F(1, 4)
R, Q, H = F(1, 25), F(1, 10), F(3, 40)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def close(actual: complex | float, expected: complex | float,
          label: str, tolerance: float = 1e-11) -> None:
    require(abs(actual - expected) <= tolerance * max(1.0, abs(expected)),
            f"{label}: {actual!r} != {expected!r}")


def bisect(f: Callable[[float], float], low: float, high: float,
           iterations: int = 90) -> float:
    fl, fh = f(low), f(high)
    if fl == 0.0:
        return low
    if fh == 0.0:
        return high
    require(fl * fh < 0, "Bisection requires a sign-changing bracket.")
    for _ in range(iterations):
        middle = (low + high) / 2
        if middle == low or middle == high:
            break
        fm = f(middle)
        if fm == 0:
            return middle
        if fl * fm < 0:
            high = middle
        else:
            low, fl = middle, fm
    return (low + high) / 2


def determinant3(m: Sequence[Sequence[F]]) -> F:
    return (m[0][0] * (m[1][1]*m[2][2] - m[1][2]*m[2][1])
            - m[0][1] * (m[1][0]*m[2][2] - m[1][2]*m[2][0])
            + m[0][2] * (m[1][0]*m[2][1] - m[1][1]*m[2][0]))


def characteristic_exact(s: F, gain: F, delay_factor: F = F(1)) -> F:
    return ((s+A)*(s+B)*(s+D)
            + H*gain*(s+B)*delay_factor
            - R*Q*gain**2*(s+D)*delay_factor**2)


def polynomial(s: float, gain: float) -> float:
    return (((s + 1/3)*s + (9/400 + 3*gain/40 - gain**2/250))*s
            + 1/2400 + 3*gain/800 - gain**2/1000)


def envelope(s: float) -> float:
    return (s + 1/30)*(s + 1/4)**2 + 45/128*(s + 1/20)


def dominant_root(gain: float) -> float:
    """Unique root > -1/20; its dominance is proved in the notes."""
    if gain < 0:
        raise ValueError("Gain must be nonnegative.")
    if gain == 0:
        return -1/30
    high = 1.0
    while polynomial(high, gain) <= 0:
        high *= 2
    return bisect(lambda s: polynomial(s, gain), -1/20, high)


def water_checks() -> dict:
    # Fixed n1=n2=1, extracellular nE=2 and VE=2, K1=K2=1.
    flux_a = sum(F(1)/v-F(1) for v in (F(1), F(1)))
    volumes_b = (F(1, 2), F(3, 2))
    flux_b = sum(F(1)/v-F(1) for v in volumes_b)
    require(flux_a == 0 and flux_b == F(2, 3), "Water counterexample")
    # Previous response's weighted reciprocal identity, exact arithmetic.
    weights, ratios = (F(1,2), F(1,2)), volumes_b
    mean = sum(w*r for w, r in zip(weights, ratios))
    jensen_gap = sum(w/r for w,r in zip(weights, ratios)) - 1/mean
    identity_rhs = sum(w*(r-mean)**2/(r*mean**2)
                       for w,r in zip(weights, ratios))
    require(jensen_gap == identity_rhs == F(1,3), "Aggregation identity")
    # Energy derivative = gradient dot flux = minus sum of squared gradients.
    gradients = [F(1)-1/v for v in volumes_b]
    velocities = [-g for g in gradients]
    energy_dot = sum(g*v for g,v in zip(gradients, velocities))
    require(energy_dot == -sum(g*g for g in gradients), "Dissipation identity")
    return {"status": "PASS", "configuration_A_total_flux": str(flux_a),
            "configuration_B_total_flux": str(flux_b),
            "weighted_reciprocal_gap": str(jensen_gap),
            "energy_derivative_B": str(energy_dot)}


def phase_checks() -> dict:
    results = {}
    # Six repetitions give the source model's population size of 24.
    populations = {"A": [0,0,math.pi/2,-math.pi/2]*6,
                   "B": [0,0,0,math.pi]*6}
    for name, angles in populations.items():
        n = len(angles)
        z1 = sum(cmath.exp(1j*t) for t in angles)/n
        z2 = sum(cmath.exp(2j*t) for t in angles)/n
        theta_dot = [(z1*cmath.exp(-1j*t)).imag for t in angles]
        dz_direct = sum(1j*cmath.exp(1j*t)*v
                        for t,v in zip(angles,theta_dot))/n
        dz_moment = (z1-z1.conjugate()*z2)/2
        coherence_dot = (z1.conjugate()*dz_direct).real/abs(z1)
        close(z1, 0.5, f"{name} first moment")
        close(dz_direct, dz_moment, f"{name} moment identity")
        close(coherence_dot, 0.25 if name == 'A' else 0,
              f"{name} coherence derivative")
        results[name] = {"cells": n, "z1_real": z1.real,
                         "z2_real": z2.real,
                         "coherence_derivative_for_K_1": coherence_dot}
    return {"status": "PASS", "assumptions":
            "Identical constant frequencies, rotating frame, no external forcing.",
            "populations": results}


def linear_feedback_checks() -> dict:
    exact_checks = 0
    for s,g,e in itertools.product((F(-1,10),F(0),F(2,3)),
                                    (F(0),F(1,10),F(1),F(4)),
                                    (F(1),F(1,3))):
        matrix = [[s+A, -R*g*e, F(1)],
                  [-Q*g*e, s+B, F(0)],
                  [-H*g*e, F(0), s+D]]
        require(determinant3(matrix) == characteristic_exact(s,g,e),
                "Characteristic determinant mismatch")
        exact_checks += 1
    # Exact completion of the square (finite spot checks, proof in notes).
    for s,g in itertools.product((F(-1,25),F(0),F(1)),
                                (F(0),F(1,10),F(1))):
        hs = (s+A)*(s+D)**2 + F(45,128)*(s+B)
        g_s = F(75,8)*(s+B)/(s+D)
        rhs = (s+B)/(s+D)*hs - F(1,250)*(s+D)*(g-g_s)**2
        require(characteristic_exact(s,g) == rhs, "Square identity mismatch")
    s_star = bisect(envelope, -1/20, -1/30)
    g_star = 75/8*(s_star+1/20)/(s_star+1/4)
    g_critical = 15/8 + math.sqrt(2265)/24
    close(polynomial(s_star,g_star), 0, "Optimal characteristic root")
    close((3/40-g_star/125)*s_star + 3/800-g_star/500, 0,
          "Stationarity in gain")
    close(dominant_root(g_star), s_star, "Optimal root dominance")
    close(polynomial(0,g_critical), 0, "Static threshold")
    table = [{"gain": g, "dominant_root": dominant_root(g),
              "spectral_decay_rate": -dominant_root(g)}
             for g in (0,0.02,g_star,0.1,1,3,g_critical,4)]
    for row in table:
        require(row['dominant_root'] >= s_star-1e-10,
                "Sample violates proved optimality")
    # A positive real root for gain 4 at several delays. Not an exhaustive DDE spectrum.
    delayed = []
    for delay in (0,1.5,10):
        def f(s: float) -> float:
            return ((s+1/30)*(s+1/20)*(s+1/4)
                    + 3/40*4*(s+1/20)*math.exp(-s*delay)
                    - 1/250*16*(s+1/4)*math.exp(-2*s*delay))
        rt = bisect(f,0,1)
        require(rt > 0, "Expected positive characteristic root")
        delayed.append({"gain":4,"delay":delay,"positive_real_root":rt})
    return {"status":"PASS", "assumptions":
            "Zero baseline A0=0, U=0, noise=0, steadiness=1; local linearization. "
            "Optimizer and complete stability classification require delay=0.",
            "exact_determinant_spot_checks": exact_checks,
            "optimal_gain":g_star, "optimal_dominant_root":s_star,
            "optimal_spectral_decay_rate":-s_star,
            "zero_delay_stability_threshold":g_critical,
            "initial_decay_rate_derivative":str(F(9,26)),
            "spectral_rate_table":table,
            "delayed_positive_root_examples":delayed}


def harmonic_checks() -> dict:
    # I_2(2)=sum_{k>=0} 1/(k!(k+2)!).
    term = total = 0.5
    for k in range(200):
        term /= (k+1)*(k+3)
        total += term
        if term < 1e-18:
            break
    a2_series = 2*math.exp(-2)*total
    # Independent Simpson integration of the Fourier coefficient.
    n = 20000
    step = 2*math.pi/n
    def f(t: float) -> float:
        return math.exp(2*(math.cos(t)-1))*math.cos(2*t)
    integral = f(0)+f(2*math.pi)
    integral += sum((4 if j%2 else 2)*f(j*step) for j in range(1,n))
    a2_quadrature = integral*step/(3*math.pi)
    close(a2_series,a2_quadrature,"Second harmonic",1e-10)
    phases = [0,math.pi]*20
    first_index = abs(sum(cmath.exp(1j*p) for p in phases)/len(phases))
    second_index = abs(sum(cmath.exp(2j*p) for p in phases)/len(phases))
    close(first_index,0,"Two-to-one first moment cancellation")
    close(second_index,1,"Two-to-one appropriate harmonic index")
    return {"status":"PASS", "a2_series":a2_series,
            "a2_independent_quadrature":a2_quadrature,
            "averaged_locking_half_width_per_epsilon":a2_series/2,
            "caveat":"Locking boundary is first-order weak-forcing averaging, "
                     "not an exact threshold for the full time-varying model.",
            "perfect_2_to_1_first_harmonic_index":first_index,
            "perfect_2_to_1_second_harmonic_index":second_index}


def correlation_checks() -> dict:
    # Four independent Rademacher variables, enumerate their entire probability space.
    samples = [(u+e1,u+e2,u+3*e3)
               for u,e1,e2,e3 in itertools.product((-1,1),repeat=4)]
    ex2 = sum(x*x for x,m,o in samples)/16
    em2 = sum(m*m for x,m,o in samples)/16
    eo2 = sum(o*o for x,m,o in samples)/16
    exm = sum(x*m for x,m,o in samples)/16
    exo = sum(x*o for x,m,o in samples)/16
    corr_xm, corr_xo = exm/math.sqrt(ex2*em2), exo/math.sqrt(ex2*eo2)
    close(corr_xm,0.5,"No-coupling first correlation")
    close(corr_xo,1/math.sqrt(20),"No-coupling control correlation")
    require(corr_xm-corr_xo>0,"Correlation subtraction counterexample")
    return {"status":"PASS", "direct_coupling":False,
            "correlation_X_M":corr_xm,"correlation_X_O":corr_xo,
            "difference_without_direct_coupling":corr_xm-corr_xo}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=None)
    args = parser.parse_args()
    report = {"scope":"Independent checks of written equations, not original simulator.",
              "water":water_checks(),"phase_population":phase_checks(),
              "feedback":linear_feedback_checks(),"harmonic":harmonic_checks(),
              "shared_input_counterexample":correlation_checks()}
    text = json.dumps(report,indent=2,allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text+'\n',encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
