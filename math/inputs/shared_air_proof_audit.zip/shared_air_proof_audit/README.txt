SHARED AIR — INDEPENDENT PROOF AUDIT

Files:
  proof_notes.md       Full proofs, assumptions, and limits.
  verify_shared_air.py Standard-library-only Python checker (Python 3.10+).
  audit_results.json  Output from the checker executed during this audit.

Run:
  python verify_shared_air.py --output audit_results.json

This is an audit of the equations in Shared Air Model.md, not a reproduction
of the unavailable interactive simulator. No patient data, parameter fitting,
or clinical validation is included. The zero-delay linearization must not be
confused with the full nonlinear stochastic delayed model.

The principal result is a unique finite maximum of a defined spectral recovery
rate, proved for a class of three-state feedback systems and evaluated for the
source's illustrative coefficients. Proofs also analyze passive water dynamics,
hidden phase-distribution information, and two inferential limitations.
