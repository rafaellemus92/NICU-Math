#!/usr/bin/env python3
"""Exact initial-time identities for a periodic 3D Navier--Stokes example.

Python 3.10+; standard library only. No grid, timestepping, or floating-point
arithmetic is used. Sparse Fourier polynomials are multiplied exactly, and the
constant coefficient is the normalized spatial integral on [0, 2*pi]^3.

This is an algebraic verification, not a global-regularity or blowup proof.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from typing import Dict, Tuple

@dataclass(frozen=True)
class QComplex:
    real: F = F(0)
    imag: F = F(0)

    def __add__(self, other: QComplex) -> QComplex:
        return QComplex(self.real + other.real, self.imag + other.imag)

    def __mul__(self, other: QComplex) -> QComplex:
        return QComplex(self.real*other.real - self.imag*other.imag,
                        self.real*other.imag + self.imag*other.real)

    def conjugate(self) -> QComplex:
        return QComplex(self.real, -self.imag)

    def is_zero(self) -> bool:
        return not self.real and not self.imag

Mode = Tuple[int, int, int]
Polynomial = Dict[Mode, QComplex]
ZERO = QComplex()
ORIGIN: Mode = (0, 0, 0)

def clean(p: Polynomial) -> Polynomial:
    return {k: a for k, a in p.items() if not a.is_zero()}

def add(*polynomials: Polynomial) -> Polynomial:
    out: Polynomial = {}
    for p in polynomials:
        for k, a in p.items():
            out[k] = out.get(k, ZERO) + a
    return clean(out)

def scale(p: Polynomial, a: F) -> Polynomial:
    return clean({k: v*QComplex(F(a)) for k, v in p.items()})

def multiply(p: Polynomial, q: Polynomial) -> Polynomial:
    out: Polynomial = {}
    for k, a in p.items():
        for l, b in q.items():
            m: Mode = tuple(k[j] + l[j] for j in range(3))  # type: ignore
            out[m] = out.get(m, ZERO) + a*b
    return clean(out)

def derivative(p: Polynomial, j: int) -> Polynomial:
    if j not in (0, 1, 2):
        raise ValueError('Coordinate index must be 0, 1, or 2.')
    return clean({k: a*QComplex(F(0), F(k[j])) for k, a in p.items()})

def sine(k: Mode) -> Polynomial:
    return {k: QComplex(F(0), F(-1, 2)),
            tuple(-v for v in k): QComplex(F(0), F(1, 2))}

def cosine(k: Mode) -> Polynomial:
    return {k: QComplex(F(1, 2)),
            tuple(-v for v in k): QComplex(F(1, 2))}

def average(p: Polynomial) -> F:
    a = p.get(ORIGIN, ZERO)
    if a.imag:
        raise ArithmeticError('Expected a real spatial average.')
    return a.real

def curl(v: Tuple[Polynomial, ...]) -> Tuple[Polynomial, ...]:
    return (add(derivative(v[2], 1), scale(derivative(v[1], 2), F(-1))),
            add(derivative(v[0], 2), scale(derivative(v[2], 0), F(-1))),
            add(derivative(v[1], 0), scale(derivative(v[0], 1), F(-1))))

def quantities(u: Tuple[Polynomial, ...]) -> Tuple[F, F, F, F, F]:
    div = add(*(derivative(u[j], j) for j in range(3)))
    assert not div, 'Velocity is not divergence free.'
    for p in u:
        for k, a in p.items():
            assert p.get(tuple(-v for v in k), ZERO) == a.conjugate()
    w = curl(u)
    E = sum((average(multiply(p,p)) for p in u), F(0))/2
    Z = sum((average(multiply(p,p)) for p in w), F(0))/2
    diss = sum((average(multiply(derivative(p,j), derivative(p,j)))
                for p in w for j in range(3)), F(0))
    stretch = sum((average(multiply(multiply(w[i], derivative(u[i],j)), w[j]))
                   for i in range(3) for j in range(3)), F(0))
    energy_diss = sum((average(multiply(derivative(p,j), derivative(p,j)))
                       for p in u for j in range(3)), F(0))
    return E, Z, diss, stretch, energy_diss

def main() -> None:
    u = (sine((0,1,0)), sine((0,0,1)),
         add(cosine((1,0,0)), scale(cosine((1,1,0)), F(-1))))
    minus_u = tuple(scale(p, F(-1)) for p in u)
    plus = quantities(u)
    minus = quantities(minus_u)
    assert plus == (F(1), F(5,4), F(7,2), F(1,4), F(5,2))
    assert minus == (F(1), F(5,4), F(7,2), F(-1,4), F(5,2))
    # Equality at each Fourier wave vector, not merely equality of shell sums.
    for k in set().union(*(set(p) for p in u)):
        a = sum((p.get(k,ZERO)*p.get(k,ZERO).conjugate() for p in u), ZERO)
        b = sum((p.get(k,ZERO)*p.get(k,ZERO).conjugate() for p in minus_u), ZERO)
        assert a == b
    nu = F(1,28)
    dz_plus = plus[3] - nu*plus[2]
    dz_minus = minus[3] - nu*minus[2]
    assert dz_plus == F(1,8) and dz_minus == F(-3,8)
    print('PASS: exact divergence zero; velocity fields real and periodic.')
    print('PASS: identical energy at every Fourier wave vector.')
    print('                           +u          -u')
    for label, a, b in zip(('Energy E', 'Enstrophy Z', 'Dissipation D',
                            'Stretching S', 'Integral |grad u|^2'), plus, minus):
        print(f'{label:25s} {str(a):>8s}    {str(b):>8s}')
    print(f'Viscosity nu = {nu}')
    print(f'Enstrophy derivative +u: {dz_plus}; -u: {dz_minus}')
    print('For u_plus/minus = +/- A*u:')
    print('E = A^2; Z = 5 A^2/4; D = 7 A^2/2; S = +/- A^3/4.')
    print('Opposite signs of enstrophy derivatives when A > 14*nu.')
    print('All computations are exact rational Fourier algebra.')
    print('No time evolution, singularity, or global regularity is claimed.')

if __name__ == '__main__':
    main()
