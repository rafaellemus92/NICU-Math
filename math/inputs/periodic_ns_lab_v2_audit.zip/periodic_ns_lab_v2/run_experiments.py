#!/usr/bin/env python3
"""Reproduce baseline, phase sweep, and resolution/time-step audits.

Run --stage all for the full suite; stages permit restarting without background
jobs. All files are local outputs, and no result is silently downloaded.
"""
from __future__ import annotations
import argparse
import csv
import json
import platform
import time
from pathlib import Path
import numpy as np
from ns_solver import PeriodicNS,evolve,write_csv


def run_one(root:Path,label:str,n:int,sign:int=1,phase:float=0,t_end:float=2,
            dt:float=0.01,sample:float=0.02):
    out=root/label; out.mkdir(parents=True,exist_ok=True)
    solver=PeriodicNS(n,1/28)
    initial=solver.initial(sign=sign,phase=phase)
    print(f"RUN {label}: N={n}, sign={sign}, phase={phase:.6f}, t={t_end}, dt<={dt}",flush=True)
    rows,last,shells,meta=evolve(solver,initial,t_end,dt,sample,
                               snapshot_times=tuple(t for t in [0,0.5,1,2] if t<=t_end))
    meta.update({"sign":sign,"phase":phase,"amplitude":1})
    write_csv(out/'diagnostics.csv',rows); write_csv(out/'shell_transfer.csv',shells)
    np.savez_compressed(out/'final_state.npz',u_hat=last)
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    peak=max(rows,key=lambda d:d['enstrophy'])
    summary={"label":label,"n":n,"cutoff":solver.kmax,"sign":sign,"phase":phase,
             "t_end":t_end,"dt":dt,"steps":meta['steps'],"wall_seconds":meta['wall_seconds'],
             "initial_Z":rows[0]['enstrophy'],"initial_dZdt":rows[0]['dzdt'],
             "final_Z":rows[-1]['enstrophy'],"final_E":rows[-1]['energy'],
             "final_dZdt":rows[-1]['dzdt'],"final_S":rows[-1]['stretching'],
             "final_D":rows[-1]['D'],"sampled_peak_Z":peak['enstrophy'],
             "sampled_peak_t":peak['t'],
             "max_divergence_l2":max(r['divergence_l2'] for r in rows),
             "max_energy_balance_defect":max(abs(r['nonlinear_energy_balance']) for r in rows),
             "max_enstrophy_balance_defect":max(r['enstrophy_balance_disagreement'] for r in rows),
             "max_outer_band_Z_fraction":max(r['outer_band_enstrophy_fraction'] for r in rows),
             "max_outer_band_D_fraction":max(r['outer_band_D_fraction'] for r in rows),
             "sampled_energy_nonincreasing":all(b['energy'] <= a['energy']+1e-12 for a,b in zip(rows,rows[1:])),
             "max_grid_vorticity":max(r['vorticity_grid_max'] for r in rows)}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(f"DONE {label}: Z(T)={summary['final_Z']:.10f}, S(T)={summary['final_S']:.8f}, "
          f"tailZ={summary['max_outer_band_Z_fraction']:.2e}, {summary['wall_seconds']:.2f}s",flush=True)
    return summary,last


def coefficient_error(low,high,nlo,nhi):
    """L2 difference after zero-padding low coefficients onto high grid."""
    freq=np.rint(np.fft.fftfreq(nlo)*nlo).astype(int)
    idx=freq % nhi
    embedded=np.zeros_like(high)
    for c in range(3):
        embedded[c][np.ix_(idx,idx,idx)]=low[c]
    return float(np.linalg.norm((embedded-high).ravel())/np.linalg.norm(high.ravel()))


def summarize(root:Path):
    summaries=[json.loads(p.read_text()) for p in sorted(root.glob('*/summary.json'))]
    write_csv(root/'run_summary.csv',summaries)
    by_label={d['label']:d for d in summaries}
    def state(label):
        return np.load(root/label/'final_state.npz')['u_hat']
    conv=[]
    for tag in ['plus','minus','phase_pi3']:
        labels=[l for l in by_label if l.startswith(tag+'_N')]
        labels.sort(key=lambda l:by_label[l]['n'])
        if len(labels)<2: continue
        ref=by_label[labels[-1]]; hi=ref['n']; high=state(ref['label'])
        for label in labels[:-1]:
            row=by_label[label]; n=row['n']
            conv.append({'comparison':'space','case':tag,'n':n,'reference_n':hi,
                         'dt':row['dt'],'reference_dt':ref['dt'],
                         'relative_field_L2':coefficient_error(state(label),high,n,hi),
                         'relative_Z_error':abs(row['final_Z']/ref['final_Z']-1)})
    temporal=sorted((d for l,d in by_label.items() if l.startswith('time_dt')),key=lambda d:-d['dt'])
    if len(temporal)>1:
        ref=temporal[-1]; high=state(ref['label'])
        for row in temporal[:-1]:
            conv.append({'comparison':'time','case':'plus','n':row['n'],'reference_n':ref['n'],
                         'dt':row['dt'],'reference_dt':ref['dt'],
                         'relative_field_L2':float(np.linalg.norm((state(row['label'])-high).ravel())/np.linalg.norm(high.ravel())),
                         'relative_Z_error':abs(row['final_Z']/ref['final_Z']-1)})
    write_csv(root/'convergence.csv',conv)
    s=PeriodicNS(16)
    audit=s.direct_triad_audit(s.initial(),cutoff=2)
    (root/'initial_triad_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    manifest={"python":platform.python_version(),"numpy":np.__version__,"platform":platform.platform(),
              "sum_run_wall_seconds":sum(d['wall_seconds'] for d in summaries),"runs":len(summaries),
              "randomness":"none in production experiments","force":"zero", 
              "continuum_error_bound_proved":False}
    (root/'execution_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2),flush=True)
    return summaries,conv


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path('results'))
    ap.add_argument('--stage',choices=['all','baseline','time','phase','refine','summarize'],default='all')
    ap.add_argument('--grids',type=int,nargs='+',default=[16,24,32,48])
    ap.add_argument('--phase-count',type=int,default=9)
    args=ap.parse_args(); root=args.out; root.mkdir(parents=True,exist_ok=True)
    if args.stage in ['all','baseline']:
        for sign in [1,-1]:
            tag='plus' if sign==1 else 'minus'
            for n in args.grids:
                run_one(root,f'{tag}_N{n}',n=n,sign=sign)
    if args.stage in ['all','time']:
        for dt in [0.02,0.01,0.005,0.0025]:
            run_one(root,f'time_dt{dt:g}',n=24,t_end=1,dt=dt,sample=0.1)
    if args.stage in ['all','phase']:
        for j,phi in enumerate(np.linspace(0,np.pi,args.phase_count)):
            run_one(root,f'phase_{j:02d}',n=24,phase=float(phi))
    if args.stage in ['all','refine']:
        for n in [24,32,48]:
            run_one(root,f'phase_pi3_N{n}',n=n,phase=float(np.pi/3))
    summarize(root)

if __name__=='__main__': main()
