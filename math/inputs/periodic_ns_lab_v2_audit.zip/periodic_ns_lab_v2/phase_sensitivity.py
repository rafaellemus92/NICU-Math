#!/usr/bin/env python3
"""First and second phase variations of the SAME Fourier--Galerkin ODE.

u_t = P(u x curl u) + nu Delta u
w_t = P(w x curl u + u x curl w) + nu Delta w
r_t = P(r x curl u + 2 w x curl w + u x curl r) + nu Delta r

w = partial_phi u, r = partial_phi^2 u. This is not a closure and does not
alter u. The derivatives approximate the continuous-time Galerkin flow,
not differentiation through phase-dependent numerical timestep selection.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
import numpy as np
from ns_solver import PeriodicNS,fft,ifft,cross,write_csv


def initial_variations(solver:PeriodicNS,phase:float):
    x=np.arange(solver.n)*2*np.pi/solver.n
    x,y,z=np.meshgrid(x,x,x,indexing='ij')
    w=np.zeros((3,solver.n,solver.n,solver.n));r=np.zeros_like(w)
    w[2]=np.sin(x+y+phase);r[2]=np.cos(x+y+phase)
    return np.stack((solver.initial(phase=phase),solver.project(fft(w)),solver.project(fft(r))))


def variation_rhs(solver:PeriodicNS,state):
    u,w,r=ifft(state).real
    omega,eta,zeta=ifft(np.stack([solver.curl(a) for a in state])).real
    vals=np.stack((cross(u,omega),cross(w,omega)+cross(u,eta),
                   cross(r,omega)+2*cross(w,eta)+cross(u,zeta)))
    nl=np.stack([solver.project(a) for a in fft(vals)])
    return nl-solver.nu*solver.k2*state


def variation_step(solver:PeriodicNS,state,dt:float):
    k1=variation_rhs(solver,state)
    k2=variation_rhs(solver,state+dt*k1/2)
    k3=variation_rhs(solver,state+dt*k2/2)
    k4=variation_rhs(solver,state+dt*k3)
    out=state+(dt/6)*(k1+2*k2+2*k3+k4)
    out=np.stack([solver.project(a) for a in out])
    if not np.isfinite(out).all():raise FloatingPointError('Nonfinite variation state')
    return out


def objective(solver:PeriodicNS,state):
    omega,eta,zeta=(solver.curl(a) for a in state)
    return dict(Z=float(np.vdot(omega,omega).real/2),
                dZ_dphi=float(np.vdot(omega,eta).real),
                d2Z_dphi2=float(np.vdot(eta,eta).real+np.vdot(omega,zeta).real))


def integrate(n:int,phase:float,end:float=2,dt_max:float=.01,sample:float=.1):
    if any(not np.isfinite(v) or v<=0 for v in [end,dt_max,sample]):
        raise ValueError('end, timestep, and sample must be positive finite')
    solver=PeriodicNS(n,1/28);state=initial_variations(solver,phase)
    times=sorted(set(round(float(t),12) for t in [0,end,*np.arange(0,end,sample)]))
    rows=[];t=0.;steps=0;start=time.perf_counter()
    for target in times:
        while t<target-1e-13:
            adv,diff=solver.dt_limits(state[0])
            dt=min(dt_max,adv,diff,target-t)
            state=variation_step(solver,state,dt);t+=dt;steps+=1
        t=target
        rows.append(dict(t=t,**objective(solver,state)))
    meta=dict(n=n,phase=phase,end=end,dt_max=dt_max,steps=steps,
              wall_seconds=time.perf_counter()-start,continuum_certified=False)
    return rows,state,meta


def optimize(n:int,end:float,out:Path,initial:float=1.0,maxiter:int=8,tol:float=2e-9):
    """Safeguarded local Newton search. A dense sweep is a separate experiment.

    Reports a stationary candidate and its computed curvature, never a
    certified continuum or global optimum. Step is capped at 0.25 radians.
    """
    out.mkdir(parents=True,exist_ok=True);history=[];phase=initial
    for j in range(maxiter):
        rows,state,meta=integrate(n,phase,end)
        row=dict(iteration=j,**meta,**rows[-1]);history.append(row)
        write_csv(out/f'iteration_{j:02d}.csv',rows)
        (out/'history.json').write_text(json.dumps(history,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        g=row['dZ_dphi'];h=row['d2Z_dphi2']
        if abs(g)<tol:
            result=dict(**row,local_stationary_candidate=True,curvature_negative=h<0,
                        global_maximum_certified=False,root_tolerance=tol)
            np.savez_compressed(out/'candidate_state.npz',u_hat=state[0],w_hat=state[1],r_hat=state[2])
            (out/'candidate.json').write_text(json.dumps(result,indent=2)+'\n')
            return result
        if h>=0: raise RuntimeError('Nonnegative curvature; choose another initial point after sweep')
        step=float(np.clip(-g/h,-.25,.25))
        phase=phase+step
        if not 0<phase<np.pi:raise RuntimeError('Newton step left interval (0,pi)')
    raise RuntimeError('No convergence within maxiter; history preserved')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--n',type=int,default=24);ap.add_argument('--end',type=float,default=2)
    ap.add_argument('--phase',type=float,default=1.0)
    ap.add_argument('--dt',type=float,default=.01)
    ap.add_argument('--sample',type=float,default=.1)
    ap.add_argument('--out',type=Path,default=Path('results/optimization_N24_T2'))
    ap.add_argument('--optimize',action='store_true')
    a=ap.parse_args()
    if a.optimize: optimize(a.n,a.end,a.out,a.phase)
    else:
        a.out.mkdir(parents=True,exist_ok=True)
        rows,state,meta=integrate(a.n,a.phase,a.end,a.dt,a.sample)
        write_csv(a.out/'diagnostics.csv',rows)
        (a.out/'summary.json').write_text(json.dumps(dict(**meta,**rows[-1]),indent=2)+'\n')
        print(json.dumps(dict(**meta,**rows[-1]),indent=2))

if __name__=='__main__':main()
