import numpy as np
from ns_solver import PeriodicNS,ifft
from phase_sensitivity import initial_variations,variation_rhs,variation_step,objective,integrate


def test_initial_variations():
    s=PeriodicNS(16);p=.7;h=1e-4
    state=initial_variations(s,p)
    fd=(s.initial(phase=p+h)-s.initial(phase=p-h))/(2*h)
    assert np.max(abs(fd-state[1]))<1e-9
    fd2=(s.initial(phase=p+h)-2*s.initial(phase=p)+s.initial(phase=p-h))/h**2
    assert np.max(abs(fd2-state[2]))<5e-8


def test_derivative_of_rhs():
    s=PeriodicNS(16);state=initial_variations(s,.7);h=1e-4
    rates=variation_rhs(s,state)
    plus=s.rhs(s.initial(phase=.7+h));minus=s.rhs(s.initial(phase=.7-h))
    assert np.max(abs((plus-minus)/(2*h)-rates[1]))<1e-9
    assert np.max(abs((plus-2*s.rhs(state[0])+minus)/h**2-rates[2]))<5e-8


def test_same_base_step():
    s=PeriodicNS(16);state=initial_variations(s,.7)
    for _ in range(5):
        expected=s.step(state[0],.01)
        state=variation_step(s,state,.01)
        assert np.max(abs(expected-state[0]))<2e-15


def test_objective_derivatives():
    s=PeriodicNS(16);p=.7;h=2e-4
    rows,state,_=integrate(16,p,.2)
    plus=integrate(16,p+h,.2)[0][-1]['Z']
    minus=integrate(16,p-h,.2)[0][-1]['Z']
    d=rows[-1]
    assert abs((plus-minus)/(2*h)-d['dZ_dphi'])<1e-8
    assert abs((plus-2*d['Z']+minus)/h**2-d['d2Z_dphi2'])<1e-7


def test_initial_objective_independent_of_phase():
    s=PeriodicNS(16)
    for p in [0,.7,np.pi]:
        d=objective(s,initial_variations(s,p))
        assert abs(d['Z']-1.25)<1e-14
        assert abs(d['dZ_dphi'])<1e-14
        assert abs(d['d2Z_dphi2'])<1e-14


def test_phase_reflection_identity():
    s=PeriodicNS(16);p=.72
    u=ifft(s.initial(phase=p)).real
    # F(x,y,z)=R u(R x + (0,0,pi)), R=diag(-1,-1,1).
    indices=(-np.arange(s.n))%s.n
    zindices=(np.arange(s.n)+s.n//2)%s.n
    transformed=u[:,indices][:,:,indices][:,:,:,zindices].copy()
    transformed[0:2]*=-1
    expected=ifft(s.initial(phase=-p)).real
    assert np.max(abs(expected-transformed))<2e-14


def test_evolved_phase_evenness():
    a=integrate(16,.72,.2)[0][-1]
    b=integrate(16,-.72,.2)[0][-1]
    assert abs(a['Z']-b['Z'])<1e-13
    assert abs(a['dZ_dphi']+b['dZ_dphi'])<1e-13
    assert abs(a['d2Z_dphi2']-b['d2Z_dphi2'])<1e-13
