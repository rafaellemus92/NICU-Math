"""Independent consistency tests. They do not certify the continuum limit."""
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ns_solver import PeriodicNS, fft, ifft, evolve
from exact_initial_check import main as exact_check


def random_field(s, seed=177):
    rng=np.random.default_rng(seed)
    physical=rng.normal(size=(3,s.n,s.n,s.n))
    return s.project(fft(physical))


def test_exact_rational_initial_check():
    exact_check()


def test_projection_and_reality():
    s=PeriodicNS(16)
    a=random_field(s)
    assert np.max(np.abs(s.project(a)-a)) < 1e-15
    assert np.max(np.abs(np.sum(s.k*a,axis=0))) < 1e-15
    assert np.max(np.abs(ifft(a).imag)) < 1e-14


def test_plus_minus_initial():
    s=PeriodicNS(16)
    for sign in [1,-1]:
        a=s.initial(sign=sign)
        d=s.diagnostics(a,physical_audit=True)
        for key,value in {"energy":1,"enstrophy":1.25,"D":3.5,
                          "stretching":sign/4,"dzdt":sign/4-1/8}.items():
            assert abs(d[key]-value) < 1e-13
        assert d["enstrophy_balance_disagreement"] < 1e-13


def test_continuous_phase_formula():
    s=PeriodicNS(16)
    base=np.sum(np.abs(s.initial())**2,axis=0)
    for phi in np.linspace(0,2*np.pi,33):
        a=s.initial(phase=phi)
        d=s.diagnostics(a)
        assert abs(d["stretching"]-np.cos(phi)/4) < 2e-14
        assert np.max(np.abs(np.sum(np.abs(a)**2,axis=0)-base)) < 2e-14


def test_translation_invariant_relative_phase():
    s=PeriodicNS(16)
    phi=0.729
    a=s.initial(phase=phi,shifts=(0.3,0.7,1.4))
    b=s.initial(phase=phi)
    da=s.diagnostics(a); db=s.diagnostics(b)
    for key in ["energy","enstrophy","D","stretching"]:
        assert abs(da[key]-db[key]) < 2e-14


def test_rotational_matches_advective():
    s=PeriodicNS(16)
    a=random_field(s)
    assert np.max(np.abs(s.nonlinear(a)-s.nonlinear_advective(a))) < 2e-15


def test_random_energy_and_enstrophy_balances():
    s=PeriodicNS(16)
    a=random_field(s)
    d=s.diagnostics(a,physical_audit=True)
    assert abs(d["nonlinear_energy_balance"]) < 1e-14
    assert d["enstrophy_balance_disagreement"] < 2e-13
    rhs=s.rhs(a)
    assert abs(np.vdot(a,rhs).real+2*s.nu*d["enstrophy"]) < 1e-14
    assert abs(np.vdot(s.curl(a),s.curl(rhs)).real-d["dzdt"]) < 1e-13


def test_direct_triad_convolution():
    s=PeriodicNS(12)
    a=random_field(s)
    audit=s.direct_triad_audit(a,cutoff=2)
    assert audit["max_direct_fft_difference"] < 1e-14
    assert abs(audit["sum_ordered_triad_stretching"]-audit["fft_lowpass_stretching"]) < 1e-13


def test_beltrami_exact_decay():
    s=PeriodicNS(12,nu=0.25)
    xyz=np.arange(s.n)*2*np.pi/s.n
    x,y,z=np.meshgrid(xyz,xyz,xyz,indexing="ij")
    u=np.stack((np.sin(z)+np.cos(y),np.sin(x)+np.cos(z),np.sin(y)+np.cos(x)))
    a=s.project(fft(u))
    assert np.max(np.abs(s.curl(a)-a)) < 2e-15
    assert np.max(np.abs(s.nonlinear(a))) < 2e-15
    rows,end,_,meta=evolve(s,a,t_end=1,dt_max=0.02,sample_dt=0.2,snapshot_times=())
    assert np.max(np.abs(end-np.exp(-s.nu)*a)) < 1e-12


def test_inviscid_energy_small_step():
    s=PeriodicNS(16,nu=0)
    a=s.initial()
    rows,end,_,_=evolve(s,a,t_end=0.2,dt_max=0.005,sample_dt=0.1,snapshot_times=())
    assert abs(s.diagnostics(end)["energy"]-1) < 5e-12


def test_shell_sums():
    s=PeriodicNS(16)
    a=random_field(s)
    rows=s.shell_rows(a,0)
    d=s.diagnostics(a)
    assert abs(sum(r["energy"] for r in rows)-d["energy"]) < 1e-14
    assert abs(sum(r["enstrophy"] for r in rows)-d["enstrophy"]) < 1e-13
    assert abs(sum(r["stretching_contribution"] for r in rows)-d["stretching"]) < 1e-13
    assert abs(rows[-1]["energy_flux_out"]) < 1e-14


def test_amplitude_scaling():
    s=PeriodicNS(16)
    a=s.initial(amplitude=2.7)
    d=s.diagnostics(a)
    assert abs(d["stretching"]-2.7**3/4) < 1e-13
    assert abs(d["D"]-3.5*2.7**2) < 1e-12


def test_invalid_inputs():
    import pytest
    with pytest.raises(ValueError): PeriodicNS(7)
    with pytest.raises(ValueError): PeriodicNS(16,-1)
    with pytest.raises(ValueError): PeriodicNS(16).initial(amplitude=0)
    with pytest.raises(ValueError): PeriodicNS(16).step(PeriodicNS(16).initial(),-0.1)


def test_exact_entire_phase_family():
    from exact_phase_family import calculate
    result=calculate()
    assert result['high_energy_t2_coefficient']['0']['real']=='7/48'


def test_exact_second_derivatives():
    from exact_dynamics_check import calculate
    assert calculate(1)['Z_second']=='921/784'
    assert calculate(-1)['Z_second']=='1061/784'


def test_short_time_high_mode_generation():
    s=PeriodicNS(16)
    for phi in [0,np.pi/3,np.pi]:
        a=s.initial(phase=phi)
        h=1e-4
        end=s.step(a,h)
        p=np.sum(np.abs(end)**2,axis=0)
        ehi=float(np.sum(p[s.k2>2])/2)
        zhi=float(np.sum((s.k2*p)[s.k2>2])/2)
        assert abs(ehi/h**2-7/48)<3e-5
        assert abs(zhi/h**2-9/16)<1e-4


def test_dynamic_translation_equivalence():
    s=PeriodicNS(16)
    a=s.initial(sign=-1)
    b=s.initial(phase=np.pi)
    for _ in range(10):
        a=s.step(a,.01);b=s.step(b,.01)
    for key in ['energy','enstrophy','D','stretching']:
        assert abs(s.diagnostics(a)[key]-s.diagnostics(b)[key])<5e-13


def test_checkpoint_segment_equivalence():
    s=PeriodicNS(16)
    a=s.initial()
    all_rows,all_end,_,_=evolve(s,a,.2,.01,.02,snapshot_times=())
    _,half,_,_=evolve(s,a,.1,.01,.02,snapshot_times=())
    _,end,_,_=evolve(s,half,.1,.01,.02,snapshot_times=())
    assert np.max(np.abs(end-all_end))<2e-15


def test_taylor_second_derivative():
    s=PeriodicNS(16)
    phi=np.pi/3; a=s.initial(phase=phi); h=2e-4
    z0=s.diagnostics(a)['enstrophy']
    z1=s.diagnostics(s.step(a,h))['enstrophy']
    z2=s.diagnostics(s.step(s.step(a,h),h))['enstrophy']
    zsecond=(z2-2*z1+z0)/h**2
    exact=1.25-2.5*s.nu*np.cos(phi)+11*s.nu**2
    assert abs(zsecond-exact)<2e-3
