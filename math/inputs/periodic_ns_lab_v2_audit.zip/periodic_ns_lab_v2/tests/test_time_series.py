from pathlib import Path
import json
from fractions import Fraction as F
from exact_time_series import calculate
from check_time_series import floating_jet
import numpy as np


def test_sixth_order_phase_harmonic():
    data=calculate(6)
    for row in data['series'][:6]:
        assert all(abs(int(k))<=1 for k in row['laurent_coefficients'])
    coeff=data['series'][6]['laurent_coefficients']
    for k in ['-2','2']:
        assert F(coeff[k]['real'])==F(-6487,3110400)
    for phi in [.17,1.23]:
        numeric=floating_jet(phi)
        for n,row in enumerate(data['series']):
            value=sum(float(F(c['real']))*np.cos(int(j)*phi)
                      for j,c in row['laurent_coefficients'].items())
            assert abs(value-numeric[n])<2e-12
