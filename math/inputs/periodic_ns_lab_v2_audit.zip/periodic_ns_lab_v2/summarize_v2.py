#!/usr/bin/env python3
"""Summarize completed outputs only. Fails if the declared suite is incomplete."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
from ns_solver import write_csv
from run_experiments import coefficient_error

ROOT=Path(__file__).resolve().parent
R=ROOT/'results'

def load(p):return json.loads(p.read_text())

def main():
    sweep=[load(p) for p in sorted(R.glob('sweep_*/summary.json'))]
    ref=[load(p) for p in sorted(R.glob('refine_*/summary.json'))]
    timed=[load(p) for p in sorted((R/'time_refinement').glob('dt*/summary.json'))]
    assert (len(sweep),len(ref),len(timed))==(33,9,3),'Incomplete velocity suite'
    histories=[load(R/f'optimization_N{n}_T2'/'history.json') for n in [24,32]]
    curves=[load(R/f'curvature_N{n}'/'summary.json') for n in [24,32,48]]
    cert=load(R/'viscosity_identity'/'proof_certificate.json');assert cert['result']=='PASS'
    table=[]
    for d in timed:
        f=R/'time_refinement'/d['label']/'state_t2.npz'
        refp=R/'time_refinement'/'dt0.0025'/'state_t2.npz'
        u=np.load(f)['u_hat'];v=np.load(refp)['u_hat']
        table.append(dict(dt=d['dt'],Z=d['final_Z'],relative_field_L2=float(np.linalg.norm(u-v)/np.linalg.norm(v)),
                          relative_Z_difference=abs(d['final_Z']/next(x['final_Z'] for x in timed if x['dt']==.0025)-1)))
    write_csv(R/'temporal_comparison.csv',table)
    fine=sorted((d for d in ref if d['n']==64),key=lambda d:d['phase'])
    with (R/'spatial_comparison.csv').open() as f:comparisons=list(csv.DictReader(f))
    with (R/'curvature_crossing.csv').open() as f:crosses=list(csv.DictReader(f))
    summaries=sweep+ref+timed
    manifest=load(R/'execution_manifest.json')
    manifest.update(completed_velocity_trajectories=len(summaries),
        completed_phase_sweep=33,completed_resolution_refinements=9,completed_time_refinements=3,
        completed_variational_trajectories=sum(map(len,histories))+len(curves),
        tests_passed=27,independent_Taylor_coefficient_checks=21,exact_viscosity_identity_nodes=7,
        max_sampled_divergence=max(d['max_divergence'] for d in summaries),
        max_sampled_enstrophy_balance_defect=max(d['max_balance_defect'] for d in summaries),
        all_velocity_runs_energy_nonincreasing=all(d['energy_nonincreasing'] for d in summaries),
        sum_velocity_wall_seconds=sum(d['wall_seconds'] for d in summaries),
        sum_variation_wall_seconds=sum(d['wall_seconds'] for h in histories for d in h)+sum(d['wall_seconds'] for d in curves),
        all_declared_runs_complete=True)
    (R/'execution_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    lines=['# Executed results — periodic Navier–Stokes phase laboratory v2','',
           '**Fresh execution, not a replay of the saved v1 CSVs.** The original numerical core is unchanged.',
           '', '## Access to Claude sessions', '',
           'Both supplied claude.ai/code/session links returned an access restriction. Their contents were not read, executed, compared, or merged. No result below is attributed to either Claude session.',
           '', '## Completed computation', '',
           f"{manifest['completed_velocity_trajectories']} velocity trajectories: 33 phases at 24³ through t=4; three candidates at 32³, 48³, 64³ through t=4; and three timestep-refinement trajectories at 32³ through t=2.",
           f"{manifest['completed_variational_trajectories']} additional integrations of velocity plus first/second phase sensitivities. 27 tests passed. 21 independent floating/rational Taylor checks passed. Seven exact rational viscosity nodes established the polynomial identity.",
           '', 'All main runs: ν=1/28, no forcing, initial energy E=1 and enstrophy Z=1.25, dimensionless time. Phase is fixed only at initialization; the fields evolve freely.',
           '', '## Selected candidates: 64³ computation', '',
           '| Initial phase (rad) | Initial Z′ | Z(2) | Z(4) | Sampled peak Z | Sampled peak time |',
           '|---:|---:|---:|---:|---:|---:|']
    for d in fine:
        lines.append(f"| {d['phase']:.9f} | {d['initial_dZdt']:.9f} | {d['Z_t2']:.9f} | {d['Z_t4']:.9f} | {d['peak_Z']:.9f} | {d['peak_time']:.2f} |")
    lines+=['', 'The phase near 0.97 wins at t=2 among these candidates, while the phase near 2.16 wins at t=4. All three have negative instantaneous enstrophy derivative at t=4. This establishes an observed transient over the tested interval, not eventual behavior of the continuum PDE.',
            '', '## Local phase optimization', '', '| Grid | Local stationary candidate φ | Z(2) | Computed ∂φZ | Computed ∂²φZ |', '|---:|---:|---:|---:|---:|']
    for n in [24,32]:
        d=load(R/f'optimization_N{n}_T2'/'candidate.json')
        lines.append(f"| {n}³ | {d['phase']:.12f} | {d['Z']:.12f} | {d['dZ_dphi']:.3e} | {d['d2Z_dphi2']:.9f} |")
    lines+=['', 'The Newton calculation finds a local stationary candidate. A 33-point sweep is not a certified global search over the continuum of phases. The 64³ runs test the 24³-selected phase without reoptimizing at 64³. Decimal digits in optimizer output are not guaranteed continuum accuracy.',
            '', '## Change in local optimality of phase zero', '', '| Grid | Negative-curvature time | Positive-curvature time | Linear crossing estimate |', '|---:|---:|---:|---:|']
    for d in crosses:
        lines.append(f"| {d['n']}³ | {float(d['negative_time']):.2f} | {float(d['positive_time']):.2f} | {float(d['linear_interpolated_time']):.9f} |")
    lines+=['', 'Because Z(T,φ) is even in φ, φ=0 is a stationary point. Its computed curvature changes sign between T=1.76 and T=1.77 on all three tested grids. This concerns optimization of a final-time objective, not hydrodynamic instability of a steady solution.',
            '', '## Spatial comparison against 64³', '', '| Phase (rad) | Time | Compared grid | Relative full-field L² difference | Relative Z difference |', '|---:|---:|---:|---:|---:|']
    for d in comparisons:
        lines.append(f"| {float(d['phase']):.6f} | {d['time']} | {d['n']}³ | {float(d['relative_field_L2']):.4e} | {float(d['relative_Z_difference']):.4e} |")
    lines+=['', 'These are differences between approximations, not certified errors against an exact solution. At t=4 the 48³-to-64³ full-field differences remain around 0.03%–0.052%, even though scalar enstrophy differences are much smaller.',
            '', '## Temporal comparison at fixed 32³, selected phase', '', '| Step cap | Z(2) | Relative field difference from dt=0.0025 | Relative Z difference |', '|---:|---:|---:|---:|']
    for d in sorted(table,key=lambda d:-d['dt']):
        lines.append(f"| {d['dt']} | {d['Z']:.12f} | {d['relative_field_L2']:.4e} | {d['relative_Z_difference']:.4e} |")
    lines+=['', '## Exact algebraic result', '',
            'Through time order five, the enstrophy Taylor jet depends on initial phase only through a constant and cos φ. At order six, the first higher harmonic is', '',
            '    −(6487/1555200) t^6 cos(2φ).', '',
            'The coefficient is independent of viscosity. This is proved by the exact recurrence and a degree-six polynomial identity checked at seven distinct rational viscosities. An independent rotational-form FFT recurrence agrees at 21 evaluated coefficients to within 6.7e−16.',
            '', 'This is a local derivative identity. No remainder estimate allows substituting t=2 or t=4 into the truncated Taylor polynomial as a proof of a finite-time outcome.',
            '', '## Remaining proof requirement', '',
            'No estimate uniform in the Fourier cutoff has been established. These results neither prove global regularity nor construct a singularity. They supply reproducible numerical comparisons and exact local identities for a specific initial-data family.',
            '', 'See proof_notes.md for derivations, results/execution_manifest.json for execution provenance, and CLAUDE_HANDOFF.md for an independent audit brief.']
    (ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
