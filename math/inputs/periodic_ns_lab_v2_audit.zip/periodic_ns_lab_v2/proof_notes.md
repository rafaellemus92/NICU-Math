# Phase laboratory v2 — exact results and limits

## Scope

Unforced incompressible Navier–Stokes on the periodic cube [0,2π]^3:

    u_t = P(u × curl u) + ν Δu,
    div u = 0,
    u(x,0;φ) = (sin y, sin z, cos x − cos(x+y+φ)).

P is the Leray (divergence-free) projection. Spatial integrals below are normalized averages. The production runs use ν=1/28. The original numerical core from v1 is unchanged. All Fourier coefficients for the initial family have phase-independent magnitudes.

    E = (1/2)<|u|²>,  Z = (1/2)<|curl u|²>.

A simulation here is a finite-dimensional Fourier–Galerkin approximation, not a certified continuum solution. Residuals of the retained equations do not bound the omitted Fourier tail.

## 1. Exact phase symmetry

Let R=diag(−1,−1,1), b=(0,0,π), and F[u](x)=R u(Rx+b). Then direct substitution into the initial field gives

    F[u_φ(0)] = u_(−φ)(0).

The PDE, the periodic domain, and the cubic Fourier cutoff are invariant under this rotation/translation. Thus uniqueness, while a smooth solution exists (and for the finite Galerkin flow), gives

    Z(T,φ) = Z(T,−φ) = Z(T,φ+2π).

Searching φ in [0,π] therefore loses no objective values within this ONE initial-data family. This is not a reduction of the space of all Navier–Stokes initial data.

In particular ∂_φ Z(T,0)=0 for all such T. A negative ∂²_φ Z(T,0) makes φ=0 a strict local maximum of this objective; a positive value makes it a strict local minimum. Numerical sign changes can be checked by the variational equations below. They are not blowup or stability transitions of the fluid solution itself.

## 2. First and second variations

Let w=∂_φu and r=∂²_φu. Differentiating the same PDE gives

    w_t = P(w × curl u + u × curl w) + νΔw,
    r_t = P(r × curl u + 2w × curl w + u × curl r) + νΔr.

Initial variations:

    w(0) = (0,0,sin(x+y+φ)),
    r(0) = (0,0,cos(x+y+φ)).

Objective derivatives:

    ∂_φZ(T,φ) = <curl u, curl w>,
    ∂²_φZ(T,φ) = <|curl w|²> + <curl u, curl r>.

The code evolves these equations using the same cutoff and RK4 step as the velocity. It never resets phases or feeds the sensitivity back into u. Test cases compare against centered finite differences and verify that the velocity step itself is unchanged.

These are approximations to derivatives of the continuous-time Galerkin solution, not formal derivatives through the numerical adaptive-step controller. Timestep refinement is still required.

## 3. Exact local-in-time Taylor recurrence

Write a finite Taylor jet as

    u(t,φ) = Σ_n U_n(φ)t^n,
    B(a,b) = −P[(a·∇)b].

Coefficient comparison in the PDE yields

    (n+1) U_(n+1) = νΔU_n + Σ_(j=0)^n B(U_j,U_(n−j)).

Then

    [t^n] Z(t,φ) = (1/2) Σ_(j=0)^n <curl U_j, curl U_(n−j)>.

The exact implementation uses rational complex coefficients indexed by spatial frequency and by the independent phase Fourier exponent. The spatial projection does not act on the phase index. There is no spatial Galerkin cutoff in this calculation.

The independent checker instead uses floating FFTs and the rotational nonlinearity. All spatial frequencies needed for U_n satisfy max |k_j|≤n+1 by induction. Through n=6, all coefficients therefore fit a componentwise cutoff of 7. The independent 24³ grid checker includes that entire support.

Both methods reproduce the known first and second time derivatives. They also show that up to and including t^5, the phase dependence of Z is only a constant plus cos φ. At degree six a new harmonic appears:

    [t^6 cos(2φ)] Z = −6487 / 1555200.

This nonzero coefficient is half of neither the objective nor its derivative: the Laurent coefficients of exp(±2iφ) are EACH −6487/3110400, so the cosine coefficient is twice that value.

For fixed ν, define C_6(t;ν) and B_6(t;ν) to be the constant-in-φ and cos φ polynomials listed in the exact output. Then the finite Taylor statement is

    Z(t,φ;ν) = C_6(t;ν) + B_6(t;ν) cos φ
               − (6487/1555200)t^6 cos(2φ) + O(t^7), as t→0.

No useful remainder bound at t=2 or t=4 is supplied. Substituting those times into this truncated series would NOT establish the observed optimum or the phase-transition time.

## 4. Why the new harmonic is independent of viscosity

Induction on the recurrence proves that every coefficient of U_n is a polynomial in ν of degree at most n. Therefore every spatially averaged, phase-Laurent coefficient of [t^n]Z is a polynomial in ν of degree at most n.

The script `exact_viscosity_invariant.py` evaluates the full order-six jet at SEVEN distinct rational viscosity values using exact arithmetic. At each value it checks:

* no phase harmonics beyond 0 and ±1 at time orders 0 through 5;
* at time order 6 the only additional harmonics are ±2;
* both ±2 coefficients equal −6487/3110400.

Once all seven evaluations pass, the degree bound and the elementary polynomial identity theorem prove these assertions for EVERY ν, rather than merely the seven sampled values. The machine-readable certificate and all seven exact jets are stored under `results/viscosity_identity`.

This is an exact algebraic identity of the derivatives at the initial time. It is not a theorem on the global behavior of the solution. No claim of priority in the literature is made.

## 5. Why this is a useful distinction

A function C+B cos φ has isolated maxima only at φ=0 or φ=π, unless B=0 and it is constant. Adding a negative cos(2φ) term can permit interior maxima, depending on all coefficients.

The exact Taylor calculation identifies when this richer phase dependence first occurs for this initial family. It does not prove that the sixth-order term alone explains the numerical optimum at finite time; higher orders and their remainders matter.

## 6. Numerical interpretation and the unsupplied proof step

The code uses strict cubic two-thirds dealiasing, normalized complex Fourier coefficients, Leray projection, and explicit RK4. For collocation size n, retained modes satisfy max_j |k_j|≤floor((n−1)/3).

At each fixed cutoff the unforced Galerkin ODE has an energy bound and cannot develop finite-time blowup in exact continuous time. Consequently, smooth bounded numerical trajectories are expected at fixed resolution and do not prove global smoothness of the PDE. Likewise, rising enstrophy at finite resolution does not prove a singularity.

The missing continuum step remains an estimate controlling the evolving transfers uniformly as the cutoff grows, or a rigorously validated construction with the opposite behavior. Tail fractions, grid comparisons, energy balances, and phase derivatives help identify what to test; none of them alone supplies that estimate.
