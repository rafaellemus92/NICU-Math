# Independent audit: actual execution and sixth-order phase identity

You are auditing code and mathematical claims, not being asked to agree with them.

## Source access

ChatGPT could not open either supplied private Claude Code session. This package has NOT incorporated those sessions. First summarize what your own available session/repository actually contains; then explicitly distinguish shared and different equations, initial data, domains, forcing, viscosities, cutoffs, normalizations, and outputs. Do not invent a merge between incompatible models.

## Required audit

1. Inspect `ns_solver.py` and confirm that the main velocity equation is unforced 3D incompressible periodic Navier–Stokes with strict cubic dealiasing and viscosity 1/28. Check the Fourier normalization, pressure projection, reality, zero mean, and shell-flux sign conventions.
2. Run the 27 tests. Independently check the velocity, tangent, and second-variation equations. Do not trust a small residual without identifying exactly which equations it tests.
3. Reproduce enough of the 33-point phase sweep and the 32³/48³/64³ runs to test the reported ranking at t=2 and t=4. Compare whole Fourier fields, not only scalar enstrophy. The phase near 0.971 was selected on 24³, not independently optimized on 64³.
4. Check the local optimizer at 24³ and 32³. Determine whether it finds a local stationary point, and distinguish that from a certified global optimum. A dense finite grid of phases is not a global proof.
5. Verify the phase-reflection symmetry, then check the reported change in sign of ∂²_φ Z(T,0) between T=1.76 and 1.77. This is a change of local optimality with respect to an INITIAL-DATA parameter, not a fluid instability threshold.
6. Independently derive or falsify the Taylor recurrence. The central algebraic claim is:

       [t^6 cos(2φ)] Z(t,φ;ν) = −6487/1555200,

   with no higher phase harmonic beyond constant/cos φ at orders 0 through 5, for every viscosity ν. Inspect `exact_time_series.py`, `check_time_series.py`, and `exact_viscosity_invariant.py`.
7. Audit the proof logic for the seven exact viscosity nodes: establish degree≤6 in ν for all sixth-order coefficients BEFORE accepting polynomial identity testing. Seven floating-point or approximate evaluations would not suffice; these are rational computations. Check the factor of two between Laurent and cosine coefficients.
8. If the identity passes, investigate whether a small, explicitly identified set of mode interactions accounts for the coefficient. Do not delete interactions from the full PDE and silently claim the modified system proves something about it.
9. Identify the precise additional estimate that would turn a finite-mode experiment into a continuum argument. No such estimate is currently claimed. Do not use a finite Taylor jet at t=2 or t=4 without a remainder bound.

## Deliverables

Return PASS/FAIL/UNPROVEN for each claim, with reproducible commands and the smallest counterexample for each failure. Clearly separate exact algebra, numerical convergence evidence, hypotheses, and unsupplied proof steps. If source differences prevent a code merge, give the exact differences instead of reconciling them silently. Preserve the original code and write changes as a patch or new version.
