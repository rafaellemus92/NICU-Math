#!/usr/bin/env python3
"""Independent floating FFT Taylor recurrence vs saved exact rational jet.

Both methods calculate derivatives at t=0, not a finite-time prediction.
All modes needed through degree 6 fit the chosen componentwise cutoff 7.
The independent method uses rotational form; rational method uses advective
form. They must agree after projection.
"""
from pathlib import Path
import argparse,json
from fractions import Fraction
import numpy as np
from ns_solver import PeriodicNS,cross,fft,ifft


def floating_jet(phase:float,order:int=6):
    s=PeriodicNS(24);U=[s.initial(phase=phase)];out=[]
    for n in range(order+1):
        if n:
            nl=np.zeros_like(U[0])
            for j in range(n):
                product=cross(ifft(U[j]).real,ifft(s.curl(U[n-1-j])).real)
                nl+=s.project(fft(product))
            U.append((nl-s.nu*s.k2*U[n-1])/n)
        value=sum(np.vdot(s.curl(U[j]),s.curl(U[n-j])).real for j in range(n+1))/2
        out.append(float(value))
    return out


def verify(path:Path):
    exact=json.loads(path.read_text());report=[]
    for phi in [.17,1.23,2.56]:
        vals=floating_jet(phi)
        for n,term in enumerate(exact['series']):
            v=sum(float(Fraction(c['real']))*np.cos(int(m)*phi)
                  for m,c in term['laurent_coefficients'].items())
            err=abs(v-vals[n])
            assert err<2e-12,(phi,n,v,vals[n],err)
            report.append(dict(phase=phi,order=n,exact_evaluated=v,independent_fft=vals[n],absolute_error=err))
    return dict(checks=len(report),max_absolute_error=max(d['absolute_error'] for d in report),rows=report)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',type=Path,default=Path('results/exact_time_series.json'))
    ap.add_argument('--out',type=Path,default=Path('results/independent_time_series_check.json'))
    a=ap.parse_args();report=verify(a.input);a.out.write_text(json.dumps(report,indent=2)+'\n')
    print('PASS',report['checks'],'checks; largest coefficient difference',report['max_absolute_error'])

if __name__=='__main__':main()
