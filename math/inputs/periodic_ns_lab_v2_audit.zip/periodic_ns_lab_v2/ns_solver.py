#!/usr/bin/env python3
"""Research prototype: unforced incompressible 3D Navier--Stokes on [0,2*pi]^3.

Fresh NumPy implementation of a standard Fourier--Galerkin pseudospectral
method. Complex128 normalized Fourier coefficients; rotational nonlinearity;
Leray projection; strict componentwise 2/3 dealiasing; classical explicit RK4.
No forcing, model closures, hyperviscosity, or phase resets during evolution.

This is a finite-resolution numerical experiment, NOT an existence, regularity,
or blowup proof. See README.md and proof_notes.md for definitions and limits.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.complex128]
AXES = (-3, -2, -1)


def fft(a: NDArray) -> Array:
    """Coefficients of f(x)=sum_k fhat(k) exp(i k.x), without N^3 factors."""
    return np.fft.fftn(a, axes=AXES, norm="forward")


def ifft(a: Array) -> Array:
    return np.fft.ifftn(a, axes=AXES, norm="forward")


def cross(a: NDArray, b: NDArray) -> NDArray:
    return np.stack((a[1]*b[2]-a[2]*b[1],
                     a[2]*b[0]-a[0]*b[2],
                     a[0]*b[1]-a[1]*b[0]))


class PeriodicNS:
    """Real, zero-mean, solenoidal flow; N^3 collocation nodes.

    Retained modes obey max_j |k_j| <= floor((N-1)/3), equivalently 3K < N.
    This strict inequality prevents quadratic wraparound into retained modes.
    Cutoff is a cube, not a sphere. The corresponding bound is Z<=3K^2 E.
    """
    def __init__(self, n: int = 24, nu: float = 1/28):
        if not isinstance(n, (int, np.integer)) or n < 8 or n % 2:
            raise ValueError("n must be an even integer >= 8.")
        if not np.isfinite(nu) or nu < 0:
            raise ValueError("nu must be finite and nonnegative (0 only for Euler tests).")
        self.n = int(n)
        self.nu = float(nu)
        freq = np.rint(np.fft.fftfreq(n)*n).astype(int)
        self.k = np.array(np.meshgrid(freq, freq, freq, indexing="ij"))
        self.k2 = np.sum(self.k*self.k, axis=0)
        self.kmax = (n-1)//3
        self.mask = np.max(np.abs(self.k), axis=0) <= self.kmax
        self.inv_k2 = np.zeros_like(self.k2, dtype=float)
        np.divide(1.0, self.k2, out=self.inv_k2, where=self.k2 > 0)
        self.k2_retained_max = int(np.max(self.k2[self.mask]))
        self.tail_mask = self.mask & (np.max(np.abs(self.k), axis=0) >= 0.8*self.kmax)

    def project(self, a: Array) -> Array:
        """Leray projection and Galerkin cutoff; enforce the chosen zero mean."""
        dot = np.sum(self.k*a, axis=0)
        out = (a-self.k*(dot*self.inv_k2))*self.mask
        out[:, 0, 0, 0] = 0
        return out

    def curl(self, a: Array) -> Array:
        return 1j*cross(self.k, a)

    def initial(self, phase: float = 0, amplitude: float = 1,
                sign: int = 1, shifts: tuple[float, float, float] = (0,0,0)) -> Array:
        """u=A*(sin(y+a), sin(z+b), cos(x+c)-cos(x+y+d)).

        Here d=phase+a+c; the translation-invariant relative phase is phase.
        sign=-1 reproduces the exact sign-reversed field of the previous audit.
        """
        if not np.isfinite(phase) or not np.isfinite(amplitude) or amplitude <= 0:
            raise ValueError("Finite phase and positive finite amplitude required.")
        if sign not in (-1, 1):
            raise ValueError("sign must be -1 or +1.")
        a, b, c = shifts
        coords = np.arange(self.n)*2*np.pi/self.n
        x,y,z = np.meshgrid(coords,coords,coords,indexing="ij")
        v = np.stack((np.sin(y+a),np.sin(z+b),
                      np.cos(x+c)-np.cos(x+y+phase+a+c)))
        return self.project(fft(sign*amplitude*v))

    def nonlinear(self, uh: Array) -> Array:
        """P_K P[(u x omega)^hat], dealiased by strict cutoff."""
        u = ifft(uh).real
        omega = ifft(self.curl(uh)).real
        return self.project(fft(cross(u,omega)))

    def nonlinear_advective(self, uh: Array) -> Array:
        """Independent formulation for auditing: -P_K P[(u.grad)u]."""
        u = ifft(uh).real
        adv = np.zeros_like(u)
        for j in range(3):
            adv += u[j]*ifft(1j*self.k[j]*uh).real
        return -self.project(fft(adv))

    def rhs(self, uh: Array) -> Array:
        return self.nonlinear(uh)-self.nu*self.k2*uh

    def step(self, uh: Array, dt: float) -> Array:
        """One classical RK4 step; positive dt required."""
        if not np.isfinite(dt) or dt <= 0:
            raise ValueError("dt must be positive and finite.")
        k1 = self.rhs(uh)
        k2 = self.rhs(uh+dt*k1/2)
        k3 = self.rhs(uh+dt*k2/2)
        k4 = self.rhs(uh+dt*k3)
        out = self.project(uh+(dt/6)*(k1+2*k2+2*k3+k4))
        if not np.isfinite(out).all():
            raise FloatingPointError("Nonfinite state. Stop and check resolution/timestep.")
        return out

    def dt_limits(self, uh: Array, cfl: float = 0.35) -> tuple[float, float]:
        """Conservative practical step caps, NOT a rigorous CFL theorem."""
        u = ifft(uh).real
        adv_speed = float(np.max(np.sum(np.abs(u), axis=0)))
        adv = cfl*(2*np.pi/self.n)/max(adv_speed,1e-300)
        diff = 0.5/(self.nu*self.k2_retained_max) if self.nu > 0 else math.inf
        return adv, diff

    def diagnostics(self, uh: Array, *, physical_audit: bool = False) -> dict[str,float]:
        wh = self.curl(uh)
        nl = self.nonlinear(uh)
        speed2 = np.sum(np.abs(uh)**2,axis=0)
        vort2 = np.sum(np.abs(wh)**2,axis=0)
        transfer = np.real(np.sum(uh.conj()*nl,axis=0))
        e = float(np.sum(speed2)/2)
        z = float(np.sum(vort2)/2)
        d = float(np.sum(self.k2*vort2))
        s = float(np.sum(self.k2*transfer))
        omega = ifft(wh).real
        divh = 1j*np.sum(self.k*uh,axis=0)
        real_field = ifft(uh)
        out = {
            "energy":e,"enstrophy":z,"D":d,"stretching":s,
            "dzdt":s-self.nu*d,"dedt":-2*self.nu*z,
            "stretch_to_viscous":s/(self.nu*d) if self.nu*d > 0 else 0.0,
            "divergence_l2":float(np.sqrt(np.sum(np.abs(divh)**2))),
            "imaginary_linf":float(np.max(np.abs(real_field.imag))),
            "nonlinear_energy_balance":float(np.sum(transfer)),
            "vorticity_grid_max":float(np.max(np.sqrt(np.sum(omega**2,axis=0)))),
            "outer_band_enstrophy_fraction":float(np.sum(vort2[self.tail_mask])/(2*z)) if z > 0 else 0.0,
            "outer_band_D_fraction":float(np.sum((self.k2*vort2)[self.tail_mask])/d) if d > 0 else 0.0,
        }
        if physical_audit:
            grad = np.array([ifft(1j*self.k[j]*uh).real for j in range(3)])
            s_physical = float(np.mean(sum(omega[i]*grad[j,i]*omega[j]
                                          for i in range(3) for j in range(3))))
            out["stretching_physical"] = s_physical
            out["enstrophy_balance_disagreement"] = abs(s_physical-s)
            # Strain decomposition in physical space: signed stretching density.
            density = sum(omega[i]*grad[j,i]*omega[j] for i in range(3) for j in range(3))
            out["stretching_positive_part"] = float(np.mean(np.maximum(density,0)))
            out["stretching_negative_part"] = float(np.mean(np.minimum(density,0)))
        return out

    def shell_rows(self, uh: Array, t: float) -> list[dict[str,float]]:
        """Exact sum over integer |k|^2 shells, avoiding a binning ambiguity.

        Flux at shell m = minus net nonlinear energy input to |k|^2<=m.
        All modal products here are diagnostic; no interactions are suppressed.
        """
        nl = self.nonlinear(uh)
        power = np.sum(np.abs(uh)**2,axis=0)
        trans = np.real(np.sum(uh.conj()*nl,axis=0))
        shells = self.k2[self.mask].ravel()
        es = np.bincount(shells,weights=0.5*power[self.mask])
        ts = np.bincount(shells,weights=trans[self.mask])
        rows=[]
        flux=0.0
        for m in np.flatnonzero((es != 0) | (ts != 0)):
            flux-=float(ts[m])
            rows.append({"t":float(t),"k_squared":int(m),"energy":float(es[m]),
                         "enstrophy":float(m*es[m]),"nonlinear_energy_transfer":float(ts[m]),
                         "stretching_contribution":float(m*ts[m]),"energy_flux_out":flux})
        return rows

    def direct_triad_audit(self, uh: Array, cutoff: int = 2) -> dict[str, Any]:
        """Direct ordered Fourier convolution for a LOW-PASS snapshot.

        Evaluates every p+q=k term on |k_j|<=cutoff and compares with FFT
        evaluation of exactly the SAME low-pass field. It is not a claim that
        a low-mode subsystem is closed in the full solution.
        """
        if cutoff < 1 or cutoff > self.kmax:
            raise ValueError("cutoff must be in [1, retained cutoff].")
        retained = np.max(np.abs(self.k),axis=0) <= cutoff
        low = uh*retained
        active = np.argwhere(retained & (np.sum(np.abs(low)**2,axis=0) > 1e-28))
        table = {tuple(int(v) for v in self.k[:,*idx]):low[:,*idx] for idx in active}
        nld = np.zeros_like(uh)
        terms=[]
        for p, up in table.items():
            for q, uq in table.items():
                k=tuple(p[j]+q[j] for j in range(3))
                if max(abs(v) for v in k)>self.kmax or k==(0,0,0):
                    continue
                kv=np.array(k,float)
                value=-1j*np.dot(up,np.array(q))*uq
                value=value-kv*np.dot(kv,value)/np.dot(kv,kv)
                idx=tuple(v % self.n for v in k)
                nld[:,*idx]+=value
                target=low[:,*idx]
                tr=float(np.vdot(target,value).real)
                if abs(tr)>1e-15:
                    terms.append({"p":p,"q":q,"k":k,"energy_transfer":tr,
                                  "stretching_contribution":float(np.dot(kv,kv)*tr)})
        fft_nl=self.nonlinear(low)
        terms.sort(key=lambda d:abs(d["stretching_contribution"]),reverse=True)
        return {"lowpass_cutoff":cutoff,"active_modes":len(table),
                "max_direct_fft_difference":float(np.max(np.abs(nld-fft_nl))),
                "sum_ordered_triad_stretching":sum(d["stretching_contribution"] for d in terms),
                "fft_lowpass_stretching":self.diagnostics(low)["stretching"],
                "ordered_nonzero_terms":terms}


def evolve(solver: PeriodicNS, initial: Array, t_end: float = 2.0,
           dt_max: float = 0.01, sample_dt: float = 0.02,
           snapshot_times: tuple[float,...] = (0,0.5,1,2),
           cfl: float = 0.35) -> tuple[list[dict],Array,list[dict],dict]:
    """Advance to prescribed output times; adapt only downward for step safety.

    Reported vorticity max is a collocation-grid maximum, NOT a certified L-inf
    norm. Tail fractions are diagnostics, NOT rigorous unresolved-tail bounds.
    """
    if any(not np.isfinite(v) or v<=0 for v in (t_end,dt_max,sample_dt,cfl)):
        raise ValueError("t_end, dt_max, sample_dt, cfl must be positive and finite.")
    uh=np.array(initial,copy=True)
    if uh.shape != (3,solver.n,solver.n,solver.n) or not np.isfinite(uh).all():
        raise ValueError("Initial array has invalid shape or nonfinite data.")
    checked=solver.project(uh)
    if np.max(np.abs(checked-uh)) > 1e-10 or np.max(np.abs(ifft(uh).imag))>1e-10:
        raise ValueError("Initial array must already be real, zero-mean, retained and solenoidal.")
    sample_times=list(np.arange(0,t_end+0.5*sample_dt,sample_dt))
    targets=sorted(set(round(float(t),12) for t in [0,t_end,*sample_times,*snapshot_times]
                       if 0<=t<=t_end+1e-12))
    snapset={round(float(t),12) for t in snapshot_times}
    rows=[]; shells=[]; steps=0; t=0.0; min_dt=math.inf; max_dt=0.0
    timer=time.perf_counter()
    for target in targets:
        while t < target-1e-13:
            adv,diff=solver.dt_limits(uh,cfl)
            dt=min(dt_max,adv,diff,target-t)
            uh=solver.step(uh,dt)
            t+=dt; steps+=1; min_dt=min(min_dt,dt); max_dt=max(max_dt,dt)
        t=target
        d=solver.diagnostics(uh,physical_audit=True)
        d["t"]=t
        rows.append(d)
        if round(t,12) in snapset:
            shells.extend(solver.shell_rows(uh,t))
    meta={"n":solver.n,"componentwise_cutoff":solver.kmax,"nu":solver.nu,
          "t_end":t_end,"dt_max_requested":dt_max,"sample_dt":sample_dt,
          "steps":steps,"dt_min_used":min_dt,"dt_max_used":max_dt,
          "wall_seconds":time.perf_counter()-timer,
          "discretization":"complex128 strict componentwise 2/3 Fourier-Galerkin + RK4",
          "force":"identically zero", "continuum_tail_certified":False}
    return rows,uh,shells,meta


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:
        return
    with path.open("w",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n",type=int,default=24)
    ap.add_argument("--nu",type=float,default=1/28)
    ap.add_argument("--phase",type=float,default=0,help="radians")
    ap.add_argument("--sign",type=int,choices=[-1,1],default=1)
    ap.add_argument("--amplitude",type=float,default=1)
    ap.add_argument("--t-end",type=float,default=2)
    ap.add_argument("--dt",type=float,default=0.01)
    ap.add_argument("--sample-dt",type=float,default=0.02)
    ap.add_argument("--out",type=Path,default=Path("results/single_run"))
    args=ap.parse_args()
    solver=PeriodicNS(args.n,args.nu)
    initial=solver.initial(args.phase,args.amplitude,args.sign)
    rows,last,shells,meta=evolve(solver,initial,args.t_end,args.dt,args.sample_dt)
    meta.update({"phase":args.phase,"sign":args.sign,"amplitude":args.amplitude})
    args.out.mkdir(parents=True,exist_ok=True)
    write_csv(args.out/"diagnostics.csv",rows)
    write_csv(args.out/"shell_transfer.csv",shells)
    np.savez_compressed(args.out/"final_state.npz",u_hat=last,n=args.n,nu=args.nu,t=args.t_end)
    (args.out/"metadata.json").write_text(json.dumps(meta,indent=2)+"\n")
    print(json.dumps({"metadata":meta,"initial":rows[0],"final":rows[-1]},indent=2))

if __name__=="__main__":
    main()
