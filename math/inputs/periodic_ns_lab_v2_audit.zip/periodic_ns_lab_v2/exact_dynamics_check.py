#!/usr/bin/env python3
"""Exact rational initial Taylor data; uses the supplied sparse Fourier algebra."""
from fractions import Fraction as F
import json
from exact_initial_check import (QComplex,ZERO,add,scale,multiply,derivative,
                                 sine,cosine,curl,average,quantities)


def project(v):
    out=[{} for _ in range(3)]
    for k in set().union(*(set(p) for p in v)):
        k2=sum(q*q for q in k)
        if k2==0: continue
        values=[p.get(k,ZERO) for p in v]
        dot=sum((a*QComplex(F(j)) for a,j in zip(values,k)),ZERO)
        for i in range(3):
            value=values[i]+dot*QComplex(-F(k[i],k2))
            if not value.is_zero(): out[i][k]=value
    return tuple(out)


def bilinear(u,v):
    return project(tuple(scale(add(*(multiply(u[j],derivative(v[i],j))
                                     for j in range(3))),F(-1)) for i in range(3)))


def viscous(u,nu):
    return tuple({k:a*QComplex(-nu*sum(v*v for v in k)) for k,a in p.items()}
                 for p in u)


def vadd(*vectors):
    return tuple(add(*(v[i] for v in vectors)) for i in range(3))


def inner(u,v):
    return sum((average(multiply(p,q)) for p,q in zip(u,v)),F(0))


def vscale(v,a): return tuple(scale(p,a) for p in v)


def initial():
    return (sine((0,1,0)),sine((0,0,1)),
            add(cosine((1,0,0)),scale(cosine((1,1,0)),F(-1))))


def calculate(sign=1,nu=F(1,28)):
    u=vscale(initial(),F(sign))
    f=vadd(bilinear(u,u),viscous(u,nu))
    g=vadd(bilinear(f,u),bilinear(u,f),viscous(f,nu))
    w=curl(u); wt=curl(f); wtt=curl(g)
    zprime=inner(w,wt)
    zsecond=inner(wt,wt)+inner(w,wtt)
    new_high=tuple({k:a for k,a in p.items() if sum(j*j for j in k)>2} for p in f)
    high_energy_coeff=inner(new_high,new_high)/2
    high_enstrophy_coeff=inner(curl(new_high),curl(new_high))/2
    support=set().union(*(set(p) for p in u))
    new_all=tuple({k:a for k,a in p.items() if k not in support} for p in f)
    new_energy_coeff=inner(new_all,new_all)/2
    new_enstrophy_coeff=inner(curl(new_all),curl(new_all))/2
    return {'sign':str(sign),'Z_prime':str(zprime),'Z_second':str(zsecond),
            'new_high_energy_t2_coefficient':str(high_energy_coeff),
            'new_high_enstrophy_t2_coefficient':str(high_enstrophy_coeff),
            'all_new_modes_energy_t2_coefficient':str(new_energy_coeff),
            'all_new_modes_enstrophy_t2_coefficient':str(new_enstrophy_coeff)}


def main():
    plus=calculate(1); minus=calculate(-1)
    assert plus['Z_prime']=='1/8' and minus['Z_prime']=='-3/8'
    assert plus['new_high_energy_t2_coefficient']==minus['new_high_energy_t2_coefficient']
    print(json.dumps({'plus':plus,'minus':minus},indent=2))

if __name__=='__main__':main()
