#!/usr/bin/env python3
"""Certify a viscosity-polynomial identity by seven exact rational evaluations.

For Taylor order m<=6 every coefficient is a polynomial in viscosity of degree
at most m. Seven distinct exact evaluation points therefore suffice to prove
an identity about those coefficients for every viscosity. This is polynomial
identity testing with a deterministic degree bound, NOT statistical sampling.
"""
from pathlib import Path
from fractions import Fraction as F
import json
from exact_time_series import calculate


def main():
    out=Path('results/viscosity_identity');out.mkdir(parents=True,exist_ok=True)
    nodes=[F(0),F(1,28),F(1,14),F(1,7),F(2,7),F(1,2),F(1)]
    expected=F(-6487,3110400) # coefficient of exp(+/-2 i phi), half cosine coefficient
    reports=[]
    for i,nu in enumerate(nodes):
        data=calculate(6,nu)
        (out/f'node_{i}.json').write_text(json.dumps(data,indent=2)+'\n')
        for entry in data['series']:
            n=entry['time_power'];coeff=entry['laurent_coefficients']
            for k,v in coeff.items():
                k=int(k);a=F(v['real']);b=F(v['imag'])
                assert b==0
                if abs(k)>1:
                    assert n==6 and abs(k)==2 and a==expected,(nu,n,k,a)
            if n==6:
                for k in ('-2','2'):assert F(coeff[k]['real'])==expected
        reports.append(dict(nu=str(nu),pass_check=True))
    result=dict(result='PASS',exact_nodes=reports,degree_bound=6,
                laurent_t6_coefficient=str(expected),cosine_t6_coefficient=str(2*expected),
                statement='For every viscosity, first higher phase harmonic through order 6 is -6487/1555200 t^6 cos(2phi).',
                finite_time_remainder_certified=False)
    (out/'proof_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
