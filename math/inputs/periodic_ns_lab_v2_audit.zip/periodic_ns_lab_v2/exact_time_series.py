#!/usr/bin/env python3
"""Exact finite Taylor jet of the untruncated PDE at t=0.

No Galerkin cutoff. Fractions and Laurent powers in exp(i*phi) are retained.
A finite Taylor jet is NOT a convergence radius or a finite-time approximation
with a proved remainder. It describes derivatives at the initial instant only.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from fractions import Fraction as F
from exact_phase_family import (trig,add,scale,vadd,bilinear,visc,curl,inner,
                                polyadd,polytimes,printable)


def calculate(order:int=3,nu:F=F(1,28)):
    if not 0<=order<=6:raise ValueError('order must be between 0 and 6')
    u=(trig((0,1,0,0),True),trig((0,0,1,0),True),
       add(trig((1,0,0,0)),scale(trig((1,1,0,1)),-1)))
    U=[u];out=[];start=time.perf_counter()
    for n in range(order+1):
        if n:
            # U_n=(nu Delta U_(n-1)+sum_(j=0)^(n-1) B(U_j,U_(n-1-j)))/n
            terms=[visc(U[n-1],nu)]+[bilinear(U[j],U[n-1-j]) for j in range(n)]
            val=vadd(*terms);U.append(tuple(scale(c,F(1,n)) for c in val))
        z=polytimes(polyadd(*(inner(curl(U[j]),curl(U[n-j])) for j in range(n+1))),F(1,2))
        entry={'time_power':n,'laurent_coefficients':printable(z),
               'velocity_coefficients':sum(map(len,U[n])),
               'elapsed_seconds':time.perf_counter()-start}
        assert all(a.imag==0 for a in z.values())
        assert all(z.get(-m)==a for m,a in z.items()),'Phase reflection symmetry failed'
        out.append(entry);print(json.dumps(entry),flush=True)
    return dict(nu=str(nu),coefficient_convention='Z(t,phi)=sum_n sum_j c[n,j]*t^n*exp(i*j*phi)',
                method='exact untruncated Fourier polynomial recurrence',
                finite_time_remainder_certified=False,series=out)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--order',type=int,default=3)
    ap.add_argument('--nu',type=F,default=F(1,28))
    ap.add_argument('--out',type=Path,default=Path('results/exact_time_series.json'))
    a=ap.parse_args();a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(calculate(a.order,a.nu),indent=2)+'\n')

if __name__=='__main__':main()
