# Executed results — periodic Navier–Stokes phase laboratory v2

**Fresh execution, not a replay of the saved v1 CSVs.** The original numerical core is unchanged.

## Access to Claude sessions

Both supplied claude.ai/code/session links returned an access restriction. Their contents were not read, executed, compared, or merged. No result below is attributed to either Claude session.

## Completed computation

45 velocity trajectories: 33 phases at 24³ through t=4; three candidates at 32³, 48³, 64³ through t=4; and three timestep-refinement trajectories at 32³ through t=2.
10 additional integrations of velocity plus first/second phase sensitivities. 27 tests passed. 21 independent floating/rational Taylor checks passed. Seven exact rational viscosity nodes established the polynomial identity.

All main runs: ν=1/28, no forcing, initial energy E=1 and enstrophy Z=1.25, dimensionless time. Phase is fixed only at initialization; the fields evolve freely.

## Selected candidates: 64³ computation

| Initial phase (rad) | Initial Z′ | Z(2) | Z(4) | Sampled peak Z | Sampled peak time |
|---:|---:|---:|---:|---:|---:|
| 0.000000000 | 0.125000000 | 2.229748776 | 1.806838777 | 2.240711313 | 2.20 |
| 0.971073032 | 0.016103519 | 2.255276393 | 1.954808208 | 2.344619472 | 2.55 |
| 2.159844949 | -0.263892558 | 2.128147203 | 2.058295070 | 2.339378222 | 2.90 |

The phase near 0.97 wins at t=2 among these candidates, while the phase near 2.16 wins at t=4. All three have negative instantaneous enstrophy derivative at t=4. This establishes an observed transient over the tested interval, not eventual behavior of the continuum PDE.

## Local phase optimization

| Grid | Local stationary candidate φ | Z(2) | Computed ∂φZ | Computed ∂²φZ |
|---:|---:|---:|---:|---:|
| 24³ | 0.971073031980 | 2.255315710891 | -1.167e-14 | -0.170784509 |
| 32³ | 0.970408763818 | 2.255288141713 | -1.717e-14 | -0.170347874 |

The Newton calculation finds a local stationary candidate. A 33-point sweep is not a certified global search over the continuum of phases. The 64³ runs test the 24³-selected phase without reoptimizing at 64³. Decimal digits in optimizer output are not guaranteed continuum accuracy.

## Change in local optimality of phase zero

| Grid | Negative-curvature time | Positive-curvature time | Linear crossing estimate |
|---:|---:|---:|---:|
| 24³ | 1.76 | 1.77 | 1.764523827 |
| 32³ | 1.76 | 1.77 | 1.764968015 |
| 48³ | 1.76 | 1.77 | 1.764976046 |

Because Z(T,φ) is even in φ, φ=0 is a stationary point. Its computed curvature changes sign between T=1.76 and T=1.77 on all three tested grids. This concerns optimization of a final-time objective, not hydrodynamic instability of a steady solution.

## Spatial comparison against 64³

| Phase (rad) | Time | Compared grid | Relative full-field L² difference | Relative Z difference |
|---:|---:|---:|---:|---:|
| 0.000000 | 2 | 32³ | 2.3666e-03 | 3.4640e-06 |
| 0.000000 | 2 | 48³ | 1.5789e-04 | 4.6168e-08 |
| 0.000000 | 4 | 32³ | 4.2734e-03 | 1.0405e-05 |
| 0.000000 | 4 | 48³ | 4.0827e-04 | 5.2210e-07 |
| 0.971073 | 2 | 32³ | 2.0111e-03 | 5.1927e-06 |
| 0.971073 | 2 | 48³ | 1.3821e-04 | 5.4675e-08 |
| 0.971073 | 4 | 32³ | 4.3010e-03 | 1.4048e-05 |
| 0.971073 | 4 | 48³ | 2.9938e-04 | 4.0555e-07 |
| 2.159845 | 2 | 32³ | 2.1755e-03 | 6.3863e-06 |
| 2.159845 | 2 | 48³ | 1.9226e-04 | 8.3129e-08 |
| 2.159845 | 4 | 32³ | 5.9346e-03 | 6.8017e-05 |
| 2.159845 | 4 | 48³ | 5.1941e-04 | 6.0727e-07 |

These are differences between approximations, not certified errors against an exact solution. At t=4 the 48³-to-64³ full-field differences remain around 0.03%–0.052%, even though scalar enstrophy differences are much smaller.

## Temporal comparison at fixed 32³, selected phase

| Step cap | Z(2) | Relative field difference from dt=0.0025 | Relative Z difference |
|---:|---:|---:|---:|
| 0.01 | 2.255288141713 | 7.8719e-09 | 2.4320e-09 |
| 0.005 | 2.255288136558 | 4.6078e-10 | 1.4599e-10 |
| 0.0025 | 2.255288136229 | 0.0000e+00 | 0.0000e+00 |

## Exact algebraic result

Through time order five, the enstrophy Taylor jet depends on initial phase only through a constant and cos φ. At order six, the first higher harmonic is

    −(6487/1555200) t^6 cos(2φ).

The coefficient is independent of viscosity. This is proved by the exact recurrence and a degree-six polynomial identity checked at seven distinct rational viscosities. An independent rotational-form FFT recurrence agrees at 21 evaluated coefficients to within 6.7e−16.

This is a local derivative identity. No remainder estimate allows substituting t=2 or t=4 into the truncated Taylor polynomial as a proof of a finite-time outcome.

## Remaining proof requirement

No estimate uniform in the Fourier cutoff has been established. These results neither prove global regularity nor construct a singularity. They supply reproducible numerical comparisons and exact local identities for a specific initial-data family.

See proof_notes.md for derivations, results/execution_manifest.json for execution provenance, and CLAUDE_HANDOFF.md for an independent audit brief.
