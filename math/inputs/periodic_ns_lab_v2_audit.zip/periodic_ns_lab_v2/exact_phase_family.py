#!/usr/bin/env python3
"""Exact Fourier algebra in (x,y,z,phi): phi is a parameter, NOT a coordinate.

Spatial derivatives/projection use only the first three indices. Spatial
averaging leaves a Laurent/Fourier polynomial in phi. All coefficients are
rational complex numbers. The assertions prove identities for EVERY phi.
"""
from fractions import Fraction as F
import json
from exact_initial_check import QComplex as C, ZERO


def add(*ps):
    out={}
    for p in ps:
        for k,a in p.items():out[k]=out.get(k,ZERO)+a
    return {k:a for k,a in out.items() if not a.is_zero()}

def scale(p,c):
    c=c if isinstance(c,C) else C(F(c))
    return {k:a*c for k,a in p.items() if not (a*c).is_zero()}

def mul(p,q):
    out={}
    for k,a in p.items():
        for l,b in q.items():
            m=tuple(k[j]+l[j] for j in range(4))
            out[m]=out.get(m,ZERO)+a*b
    return {k:a for k,a in out.items() if not a.is_zero()}

def derivative(p,j):
    assert 0<=j<3, 'No derivative in phi: it is a parameter.'
    return {k:a*C(F(0),F(k[j])) for k,a in p.items() if k[j]}

def trig(k,sine=False):
    neg=tuple(-v for v in k)
    return {k:C(F(0),F(-1,2)),neg:C(F(0),F(1,2))} if sine else {k:C(F(1,2)),neg:C(F(1,2))}

def curl(v):
    return tuple(add(derivative(v[(i+2)%3],(i+1)%3),
                     scale(derivative(v[(i+1)%3],(i+2)%3),-1)) for i in range(3))

def spatial_average(p):
    return {k[3]:a for k,a in p.items() if k[:3]==(0,0,0)}

def inner(u,v):return spatial_average(add(*(mul(a,b) for a,b in zip(u,v))))

def project(v):
    out=[{} for _ in range(3)]
    for k in set().union(*(set(p) for p in v)):
        k2=sum(v*v for v in k[:3])
        if not k2: continue
        val=[p.get(k,ZERO) for p in v]
        dot=sum((a*C(F(j)) for a,j in zip(val,k[:3])),ZERO)
        for i in range(3):
            a=val[i]+dot*C(-F(k[i],k2))
            if not a.is_zero():out[i][k]=a
    return tuple(out)

def bilinear(u,v):
    return project(tuple(scale(add(*(mul(u[j],derivative(v[i],j)) for j in range(3))),-1)
                         for i in range(3)))

def vadd(*vs):return tuple(add(*(v[i] for v in vs)) for i in range(3))

def visc(v,nu):
    return tuple({k:a*C(-nu*sum(j*j for j in k[:3])) for k,a in p.items()}
                 for p in v)

def polyadd(*polys):
    out={}
    for p in polys:
        for k,a in p.items():out[k]=out.get(k,ZERO)+a
    return {k:a for k,a in out.items() if not a.is_zero()}

def polytimes(p,s):return {k:a*C(F(s)) for k,a in p.items()}

def printable(p):
    return {str(k):{'real':str(a.real),'imag':str(a.imag)} for k,a in sorted(p.items())}

def calculate():
    u=(trig((0,1,0,0),True),trig((0,0,1,0),True),
       add(trig((1,0,0,0)),scale(trig((1,1,0,1)),-1)))
    w=curl(u)
    E=polytimes(inner(u,u),F(1,2));Z=polytimes(inner(w,w),F(1,2))
    S=spatial_average(add(*(mul(mul(w[i],derivative(u[i],j)),w[j])
                            for i in range(3) for j in range(3))))
    D=polyadd(*(inner(tuple(derivative(p,j) for p in w),tuple(derivative(p,j) for p in w))
                 for j in range(3)))
    assert E=={0:C(F(1))};assert Z=={0:C(F(5,4))};assert D=={0:C(F(7,2))}
    assert S=={-1:C(F(1,8)),1:C(F(1,8))}
    # Compute the exact polynomial in viscosity for Z''(0).
    f0=bilinear(u,u); f1=visc(u,F(1))
    g0=vadd(bilinear(f0,u),bilinear(u,f0))
    g1=vadd(bilinear(f1,u),bilinear(u,f1),visc(f0,F(1)))
    g2=visc(f1,F(1))
    c0=polyadd(inner(curl(f0),curl(f0)),inner(w,curl(g0)))
    c1=polyadd(polytimes(inner(curl(f0),curl(f1)),2),inner(w,curl(g1)))
    c2=polyadd(inner(curl(f1),curl(f1)),inner(w,curl(g2)))
    assert c0=={0:C(F(5,4))}
    assert c1=={-1:C(F(-5,4)),1:C(F(-5,4))}
    assert c2=={0:C(F(11))}
    nu=F(1,28)
    f=vadd(bilinear(u,u),visc(u,nu))
    g=vadd(bilinear(f,u),bilinear(u,f),visc(f,nu))
    Zsecond=polyadd(inner(curl(f),curl(f)),inner(w,curl(g)))
    high=tuple({k:a for k,a in p.items() if sum(j*j for j in k[:3])>2} for p in f)
    Ehigh=polytimes(inner(high,high),F(1,2))
    Zhigh=polytimes(inner(curl(high),curl(high)),F(1,2))
    assert Ehigh=={0:C(F(7,48))}
    assert Zhigh=={0:C(F(9,16))}
    return {'energy':printable(E),'enstrophy':printable(Z),'D':printable(D),
            'stretching':printable(S),'Z_second_at_nu_1_over_28':printable(Zsecond),
            'high_energy_t2_coefficient':printable(Ehigh),'high_enstrophy_t2_coefficient':printable(Zhigh),
            'Z_second_general_viscosity':'5/4 - (5/2)*nu*cos(phi) + 11*nu^2',
            'convention':'coefficient j multiplies exp(i*j*phi), physical averages normalized'}

def main():
    print(json.dumps(calculate(),indent=2))

if __name__=='__main__':main()
