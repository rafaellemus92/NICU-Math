# Periodic Navier–Stokes phase laboratory v2

## What is included

This package contains executed experiments for a one-parameter, equal-spectrum family of smooth divergence-free initial velocities. It builds on v1 without changing `ns_solver.py`.

* 45 new velocity trajectories: 33-phase sweep, 9 spatial refinements, 3 timestep refinements.
* 10 integrations of first/second phase sensitivity equations.
* 27 passing tests, saved logs, CSV diagnostics, and (in the full archive) Fourier snapshots.
* Exact sixth-order time jets and a viscosity-independent phase-harmonic identity.
* An independent Taylor-coefficient checker using a different nonlinear formulation.

The two supplied Claude Code session URLs were access-restricted. Their contents are not part of this package and were not compared or merged.

Read `RESULTS.md` for completed results and `proof_notes.md` for the mathematical statements and their limits. `CLAUDE_HANDOFF.md` is a strict audit brief.

## Environment

Python 3.11+ is needed. Executed with Python 3.13.5 and NumPy 2.3.5. The original core uses complex128 NumPy Fourier transforms and fourth-order Runge–Kutta integration. The phase optimizer is a small safeguarded Newton implementation, not a neural model or hidden optimizer.

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

The exact rational calculations need only the Python standard library. The independent floating check and simulation need NumPy; plotting needs Matplotlib.

## Exact calculations

```bash
python exact_initial_check.py
python exact_dynamics_check.py
python exact_phase_family.py
python exact_time_series.py --order 6
python check_time_series.py
python exact_viscosity_invariant.py
```

`exact_time_series.py --nu 1/14 --order 6 --out other_viscosity.json` changes the viscosity in the exact initial-time calculation, not in the production velocity runs. The seven-node viscosity script relies on a proved polynomial-degree bound, explained in the proof notes.

## Reproduce the executed velocity runs

These commands write to `reproduced/` to leave the supplied results intact. Use fewer workers to reduce concurrent memory use. Large grids take substantially longer than the 24³ sweep.

```bash
python run_extended.py --stage sweep --out reproduced --count 33 --n 24 --workers 3

python run_extended.py --stage refine --out reproduced --workers 3 \
  --grids 64 48 32 --end 4 \
  --phases 0 0.9710730319801146 2.1598449493429825

python run_extended.py --stage single --out reproduced/time_refinement \
  --n 32 --phase 0.9704087638177281 --end 2 --dt .01 --label dt0.01
python run_extended.py --stage single --out reproduced/time_refinement \
  --n 32 --phase 0.9704087638177281 --end 2 --dt .005 --label dt0.005
python run_extended.py --stage single --out reproduced/time_refinement \
  --n 32 --phase 0.9704087638177281 --end 2 --dt .0025 --label dt0.0025
```

Each case writes diagnostics, shell transfers, metadata, summaries, and Fourier snapshots at t=2 and t=4 when those times are reached. The archive's `results/` directory contains the completed original run of this suite.

## Reproduce phase optimization and curvature measurements

```bash
python phase_sensitivity.py --optimize --n 24 --phase 1.0 \
  --out reproduced/optimization_N24_T2
python phase_sensitivity.py --optimize --n 32 --phase 0.9710730319801146 \
  --out reproduced/optimization_N32_T2

python phase_sensitivity.py --n 24 --phase 0 --end 2.2 --sample .01 \
  --out reproduced/curvature_N24
python phase_sensitivity.py --n 32 --phase 0 --end 2.2 --sample .01 \
  --out reproduced/curvature_N32
python phase_sensitivity.py --n 48 --phase 0 --end 2.2 --sample .01 \
  --out reproduced/curvature_N48
```

The optimizer starts inside the interval identified by the sweep and reports a LOCAL stationary candidate. It does not certify a global maximum over all phases or all initial velocity fields. The sensitivity system differentiates the continuous-time Galerkin equations; it does not differentiate timestep-selection logic.

## Output conventions

Domain: [0,2π]^3. Integrals are normalized spatial averages. The initial family is

    u_φ = (sin y, sin z, cos x − cos(x+y+φ)).

All phases start with E=1, Z=5/4 and identical initial Fourier magnitudes. The phase is never reset after initialization.

The code is unforced and uses ν=1/28. For N³ collocation nodes, retained modes obey max_j|k_j|≤floor((N−1)/3). Thus a 64³ grid retains componentwise indices up to 21, not 64. The cutoff is cubic, not spherical.

`diagnostics.csv` reports energy, enstrophy, stretching, dissipation, divergence, retained-equation balance defects, and fractions of the resolved quantities in the outer retained band. Those fractions are not rigorous estimates of the unresolved tail. A collocation-grid maximum of vorticity is not a certified continuum maximum.

## Full versus audit archive

The full archive includes `.npz` Fourier states, needed for reproducing the saved full-field comparison tables without rerunning the simulations. The smaller audit archive excludes those states but includes code, CSV trajectories, logs, certificates, plots, and analysis. Regenerate states with the commands above before running snapshot-dependent analysis from the smaller archive.

`plot_results_v2.py --show` regenerates the plots from CSVs. The full archive's `summarize_v2.py` summarizes the included completed outputs and checks the expected run counts.

## What is NOT established

No continuum error bound, global regularity theorem, finite-time singularity, validated global phase optimum, or radius of convergence for the time series has been proved. The exact sixth-order coefficient is a local derivative identity, not a reliable t=2 or t=4 Taylor approximation without a remainder bound. No claim of novelty in the literature is made.
