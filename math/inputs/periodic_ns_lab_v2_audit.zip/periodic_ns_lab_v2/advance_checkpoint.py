#!/usr/bin/env python3
"""Advance one case in bounded, resumable chunks (useful under execution limits).

Example:
  python advance_checkpoint.py --n 48 --sign 1 --until 0.5
  python advance_checkpoint.py --n 48 --sign 1 --until 1.0
  python advance_checkpoint.py --n 48 --sign 1 --until 1.5
  python advance_checkpoint.py --n 48 --sign 1 --until 2.0

Writes a summary only when the declared final time has actually been reached.
Checks parameters before reusing a checkpoint; never silently changes a problem.
"""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from ns_solver import PeriodicNS,evolve,write_csv


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--n',type=int,default=48)
    ap.add_argument('--sign',type=int,choices=[-1,1],default=1)
    ap.add_argument('--phase',type=float,default=0)
    ap.add_argument('--until',type=float,required=True)
    ap.add_argument('--final-time',type=float,default=2)
    ap.add_argument('--dt',type=float,default=0.01)
    ap.add_argument('--label',type=str,default=None)
    ap.add_argument('--out',type=Path,default=Path('results'))
    a=ap.parse_args()
    label=a.label or (('plus' if a.sign==1 else 'minus')+f'_N{a.n}')
    folder=a.out/label; folder.mkdir(parents=True,exist_ok=True)
    config={'n':a.n,'nu':1/28,'sign':a.sign,'phase':a.phase,
            'dt':a.dt,'sample_dt':0.02,'final_time':a.final_time}
    checkpoint=folder/'checkpoint.json'
    solver=PeriodicNS(a.n)
    if checkpoint.exists():
        cp=json.loads(checkpoint.read_text())
        if cp['config']!=config: raise ValueError('Checkpoint configuration mismatch.')
        t0=cp['t']; uh=np.load(folder/'checkpoint_state.npz')['u_hat']
        with (folder/'diagnostics.csv').open() as f:
            rows=[{k:float(v) for k,v in d.items()} for d in csv.DictReader(f)]
        with (folder/'shell_transfer.csv').open() as f:
            shells=[{k:float(v) for k,v in d.items()} for d in csv.DictReader(f)]
    else:
        t0=0; uh=solver.initial(phase=a.phase,sign=a.sign); rows=[]; shells=[]
        cp={'config':config,'t':0,'steps':0,'wall_seconds':0,'dt_min_used':1,'dt_max_used':0,'segments':0}
    if not t0<a.until<=a.final_time: raise ValueError('Need old_time < until <= final_time.')
    snaps=tuple(t-t0 for t in [0,0.5,1,2] if t0<=t<=a.until)
    data,uh,sh,meta=evolve(solver,uh,a.until-t0,a.dt,0.02,snapshot_times=snaps)
    for d in data: d['t']=round(d['t']+t0,12)
    for d in sh: d['t']=round(d['t']+t0,12)
    rows.extend(data if not rows else data[1:])
    was_empty = not shells
    shells.extend([d for d in sh if was_empty or d['t']>t0+1e-12])
    segment_seconds=meta['wall_seconds']
    cp['t']=a.until; cp['steps']+=meta['steps']; cp['wall_seconds']+=meta['wall_seconds']; cp['segments']+=1
    cp['dt_min_used']=min(cp['dt_min_used'],meta['dt_min_used']);cp['dt_max_used']=max(cp['dt_max_used'],meta['dt_max_used'])
    write_csv(folder/'diagnostics.csv',rows);write_csv(folder/'shell_transfer.csv',shells)
    np.savez_compressed(folder/'checkpoint_state.npz',u_hat=uh)
    checkpoint.write_text(json.dumps(cp,indent=2)+'\n')
    if abs(a.until-a.final_time)<1e-12:
        np.savez_compressed(folder/'final_state.npz',u_hat=uh)
        meta.update({k:cp[k] for k in ['steps','wall_seconds','dt_min_used','dt_max_used']})
        meta.update({'t_end':a.until,'sign':a.sign,'phase':a.phase,'amplitude':1,'checkpoint_segments':cp['segments']})
        (folder/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
        peak=max(rows,key=lambda d:d['enstrophy'])
        summary={'label':label,'n':a.n,'cutoff':solver.kmax,'sign':a.sign,'phase':a.phase,
             't_end':a.until,'dt':a.dt,'steps':cp['steps'],'wall_seconds':cp['wall_seconds'],
             'initial_Z':rows[0]['enstrophy'],'initial_dZdt':rows[0]['dzdt'],
             'final_Z':rows[-1]['enstrophy'],'final_E':rows[-1]['energy'],
             'final_dZdt':rows[-1]['dzdt'],'final_S':rows[-1]['stretching'],
             'final_D':rows[-1]['D'],'sampled_peak_Z':peak['enstrophy'],'sampled_peak_t':peak['t'],
             'max_divergence_l2':max(r['divergence_l2'] for r in rows),
             'max_energy_balance_defect':max(abs(r['nonlinear_energy_balance']) for r in rows),
             'max_enstrophy_balance_defect':max(r['enstrophy_balance_disagreement'] for r in rows),
             'max_outer_band_Z_fraction':max(r['outer_band_enstrophy_fraction'] for r in rows),
             'max_outer_band_D_fraction':max(r['outer_band_D_fraction'] for r in rows),
             'sampled_energy_nonincreasing':all(b['energy']<=c['energy']+1e-12 for c,b in zip(rows,rows[1:])),
             'max_grid_vorticity':max(r['vorticity_grid_max'] for r in rows)}
        (folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'label':label,'t':a.until,'Z':rows[-1]['enstrophy'],
                      'S':rows[-1]['stretching'],'outer_band_Z':rows[-1]['outer_band_enstrophy_fraction'],
                      'outer_band_D':rows[-1]['outer_band_D_fraction'],
                      'chunk_seconds':segment_seconds,'complete':a.until==a.final_time},indent=2))

if __name__=='__main__':main()
