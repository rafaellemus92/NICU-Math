#!/usr/bin/env python3
"""Plots of completed CSVs. Uses Matplotlib defaults; no prescribed colors."""
from pathlib import Path
import argparse,csv
import numpy as np
import matplotlib.pyplot as plt


def read(path):
    with Path(path).open() as f:
        return [{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]


def plot(root:Path,show:bool=False):
    out=root/'plots';out.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(figsize=(10,5.6))
    for j,label in [(0,r'$\phi=0$'),(1,r'$\phi\approx0.971$'),(2,r'$\phi\approx2.160$')]:
        r=read(root/f'refine_p{j:02d}_N64'/'diagnostics.csv')
        ax.plot([d['t'] for d in r],[d['enstrophy'] for d in r],label=label,linewidth=2)
    ax.set(xlabel='Time (dimensionless)',ylabel='Enstrophy Z(t)',
           title='Equal initial spectra; different times of amplification\nUnforced periodic Navier–Stokes, 64³ grid, ν = 1/28')
    ax.legend(title='Initial relative phase');ax.grid(alpha=.25)
    fig.tight_layout();fig.savefig(out/'enstrophy_64.png',dpi=170);fig.savefig(out/'enstrophy_64.svg')
    if show:plt.show()
    plt.close(fig)

    # Separate figure, not a subplot: exploratory phase sweep.
    with (root/'sweep_summary.csv').open() as f: rows=list(csv.DictReader(f))
    rows.sort(key=lambda r:float(r['phase']))
    fig,ax=plt.subplots(figsize=(10,5.6))
    phi=np.array([float(r['phase'])/np.pi for r in rows])
    for t in [1,2,3,4]:
        values=np.array([float(r[f'Z_t{t}']) for r in rows])
        ax.plot(phi,values/values[0],marker='.',label=f'T = {t}',linewidth=1.8)
    ax.set(xlabel='Initial relative phase / π',ylabel='Z(T, φ) / Z(T, 0)',
           title='The preferred phase changes with the observation time\n33-point exploratory sweep on a 24³ grid')
    ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/'phase_sweep.png',dpi=170)
    plt.close(fig)

    fig,ax=plt.subplots(figsize=(10,5.6))
    for n in [24,32,48]:
        r=read(root/f'curvature_N{n}'/'diagnostics.csv')
        ax.plot([d['t'] for d in r],[d['d2Z_dphi2'] for d in r],label=f'{n}³ grid',linewidth=1.8)
    ax.axhline(0,linestyle='--',linewidth=.8)
    ax.set(xlabel='Observation time T',ylabel='∂²Z(T, φ)/∂φ² at φ = 0',
           title='Phase zero changes from a local maximum to a local minimum\nA final-time objective, not a fluid stability threshold')
    ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/'phase_curvature.png',dpi=170)
    plt.close(fig)
    return out


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--results',type=Path,default=Path(__file__).resolve().parent/'results')
    ap.add_argument('--show',action='store_true');a=ap.parse_args()
    print(plot(a.results,a.show))

if __name__=='__main__':main()
