#!/usr/bin/env python3
"""Fresh experiments; never imports old results. All saved times are physical.

Run a phase sweep first, then select candidates explicitly for refinements.
The original v1 numerical core is unmodified. No phase resets or forcing.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, platform, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np
from ns_solver import PeriodicNS, evolve, write_csv


def run_case(job: dict) -> dict:
    root=Path(job['root']); label=job['label']; out=root/label
    out.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    n=int(job['n']); phase=float(job['phase']); end=float(job.get('end',4))
    dt=float(job.get('dt',.01)); sample=float(job.get('sample',.05))
    solver=PeriodicNS(n,1/28); u=solver.initial(phase=phase)
    rows=[]; shell=[]; segments=[]; t0=0.0
    # Restart from our own states, not a previous run, at t=2,4,... so there
    # are reproducible intermediate Fourier snapshots for comparison.
    ends=sorted(set([float(t) for t in np.arange(2,end,2)]+[end]))
    for t1 in ends:
        data,u,sh,meta=evolve(solver,u,t1-t0,dt,sample,
                            snapshot_times=tuple(float(t) for t in np.arange(0,t1-t0+1e-9,1)))
        for d in data: d['t']=round(d['t']+t0,12)
        for d in sh: d['t']=round(d['t']+t0,12)
        rows.extend(data if not rows else data[1:])
        shell.extend(d for d in sh if t0==0 or d['t']>t0+1e-10)
        segments.append(meta)
        np.savez_compressed(out/f'state_t{t1:g}.npz',u_hat=u,n=n,t=t1,nu=solver.nu,phase=phase)
        t0=t1
    write_csv(out/'diagnostics.csv',rows);write_csv(out/'shell_transfer.csv',shell)
    peak=max(rows,key=lambda d:d['enstrophy'])
    summary=dict(label=label,n=n,componentwise_cutoff=solver.kmax,phase=phase,phase_over_pi=phase/math.pi,
                 end=end,dt=dt,sample=sample,final_Z=rows[-1]['enstrophy'],final_dZdt=rows[-1]['dzdt'],
                 initial_dZdt=rows[0]['dzdt'],peak_Z=peak['enstrophy'],peak_time=peak['t'],
                 final_E=rows[-1]['energy'],steps=sum(s['steps'] for s in segments),
                 max_divergence=max(d['divergence_l2'] for d in rows),
                 max_balance_defect=max(d['enstrophy_balance_disagreement'] for d in rows),
                 max_tail_Z=max(d['outer_band_enstrophy_fraction'] for d in rows),
                 max_tail_D=max(d['outer_band_D_fraction'] for d in rows),
                 energy_nonincreasing=all(b['energy']<=a['energy']+1e-12 for a,b in zip(rows,rows[1:])),
                 wall_seconds=time.perf_counter()-start)
    for t in (1,2,3,4,6,8):
        hit=[r for r in rows if abs(r['t']-t)<1e-10]
        if hit: summary[f'Z_t{t}']=hit[0]['enstrophy']
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (out/'metadata.json').write_text(json.dumps(dict(job=job,segments=segments,
        original_core_sha256=hashlib.sha256(Path(__file__).with_name('ns_solver.py').read_bytes()).hexdigest(),
        force='zero',continuum_error_certified=False),indent=2)+'\n')
    print(json.dumps(summary),flush=True)
    return summary


def execute(jobs:list[dict],workers:int,report:Path):
    results=[]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs={ex.submit(run_case,j):j for j in jobs}
        for f in as_completed(futs):
            results.append(f.result())
    results.sort(key=lambda d:d['label'])
    # All members of a stage share horizons, so consistent CSV columns.
    write_csv(report,results)
    return results


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--stage',choices=['sweep','refine','long','single'],required=True)
    ap.add_argument('--out',type=Path,default=Path('results'))
    ap.add_argument('--workers',type=int,default=3)
    ap.add_argument('--count',type=int,default=33)
    ap.add_argument('--n',type=int,default=24)
    ap.add_argument('--phase',type=float,default=0)
    ap.add_argument('--phases',type=float,nargs='+',default=[0,math.pi/3,math.pi])
    ap.add_argument('--grids',type=int,nargs='+',default=[32,48,64])
    ap.add_argument('--end',type=float,default=None)
    ap.add_argument('--dt',type=float,default=.01)
    ap.add_argument('--label',default='single')
    a=ap.parse_args(); a.out.mkdir(parents=True,exist_ok=True)
    if a.workers<1 or a.count<2: ap.error('positive workers; at least two phase points')
    base=dict(root=str(a.out.resolve()),dt=a.dt,sample=.05)
    if a.stage=='sweep':
        jobs=[dict(base,label=f'sweep_{j:03d}_N{a.n}',n=a.n,phase=float(p),end=a.end or 4)
              for j,p in enumerate(np.linspace(0,math.pi,a.count))]
    elif a.stage in ('refine','long'):
        jobs=[dict(base,label=f'{a.stage}_p{j:02d}_N{n}',n=n,phase=p,end=a.end or (2 if a.stage=='refine' else 8))
              for n in a.grids for j,p in enumerate(a.phases)]
    else:
        jobs=[dict(base,label=a.label,n=a.n,phase=a.phase,end=a.end or 2)]
    execute(jobs,a.workers,a.out/f'{a.stage}_summary.csv')
    print(f'COMPLETED {len(jobs)} fresh trajectories.',flush=True)

if __name__=='__main__':main()
